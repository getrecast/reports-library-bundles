# Saturation Curve Tracker — Recast Reports Library

Per-channel saturation curves with current spend position, % saturated, and headroom estimates. Built on the Recast `compute_spend_response_curves` API.

**Live preview:** [https://research.getrecast.com/report-template-library/saturation-curves/](https://research.getrecast.com/report-template-library/saturation-curves/)

## What it does

For your Recast model + chosen KPI:

1. Fires the `compute_spend_response_curves` report for all spend channels
2. Pulls each channel's modeled spend-vs-incremental-revenue curve
3. Marks where current 7-day spend sits on the curve
4. Computes % saturated and remaining headroom per channel
5. Outputs a single, self-contained HTML file you can host wherever

The output is fully customer-agnostic by default — your brand colors, your KPI, your channels. Customize further by editing `template.html`.

## Prerequisites

- A Recast account with API access enabled
- A Recast API token (Personal Access Token / PAT) — see [INSTALL.md](INSTALL.md)
- Python 3.10+ (stdlib only — no pip install required)

## Quick start

`.env` holds `API_PAT`; `my-config.json` holds `client_slug` and report settings.

```bash
# 1. Put your token in .env (never commit this)
cp .env.example .env
# Edit .env: API_PAT=gr_your_actual_token

# 2. Configure for your model
cp config.example.json my-config.json
# Edit my-config.json: set client_slug, kpi_name, brand colors

# 3. Validate setup, then build the report
python3 build.py my-config.json --check
python3 build.py my-config.json
# → outputs saturation-curves.html
```

The `--check` preflight is read-only — it confirms your token works, your KPI name resolves, and the API
returns the shapes this bundle expects, with a plain-language error if anything
is off. It never prints your token. If the build later fails with a 422
mentioning `report_type`, run the report once from the Recast UI first (see
`INSTALL.md`).

Open the resulting HTML in any browser. It's a single self-contained file — share via Slack, email attachment, or host it yourself.

See [INSTALL.md](INSTALL.md) for safer token handling, and [docs/customize.md](docs/customize.md) for layout/data tweaks.

## What's in this bundle

| File | Purpose |
|---|---|
| `README.md` | This file. |
| `INSTALL.md` | Setup steps + API key safety. |
| `build.py` | Stdlib Python script: hits the API, pulls curves, fills the template. |
| `template.html` | The report HTML, with `{{PLACEHOLDER}}` tokens that `build.py` replaces. |
| `config.example.json` | Generic config template. Copy to `your-config.json` to customize. |
| `.env.example` | Generic env template. Copy to `.env`, paste your token. |
| `.gitignore` | Blocks `.env`, configs, generated output. |
| `docs/api-reference.md` | The Recast API endpoints this bundle uses. |
| `docs/customize.md` | How to change layout, channels, time window, or styling. |
| `docs/SKILL.md` | Canonical agent entrypoint for guided builds. |

## What this bundle does NOT include

- Authentication / login wall for the output (it's a static HTML file; host it where you control access)
- Multi-KPI support (one report = one KPI)
- Historical curve evolution (future enhancement)
- Per-region or per-segment breakdowns (future enhancement)

## Going further

This bundle is open source. Fork it, modify it, extend it. If you build something useful, [submit it back to the library](https://research.getrecast.com/report-template-library/).

The Recast API lets you build much more than this one report. Browse the [API docs](https://docs.getrecast.com) to see what else is possible.

## Support

Issues with the bundle: open an issue on the [recast-research-pages repo](https://github.com/getrecast/recast-research-pages/issues).

Issues with the Recast API itself: contact your Recast account team.
