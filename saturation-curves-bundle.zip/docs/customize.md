# Customizing the Saturation Curve Tracker

The bundle is intentionally small. Everything is in plain HTML + vanilla JS + stdlib Python. No frameworks, no build step.

This guide walks through the most common customizations.

## Branding

Edit `config.example.json` (or your copy of it):

```json
{
  "brand": {
    "name": "Your Brand",
    "primary_color": "#E37C65",
    "accent_color": "#161614"
  }
}
```

- `primary_color` — curve stroke, eyebrow text, accent details
- `accent_color` — primary text color, table header background, frame border

Re-run `python3 build.py your-config.json` and the colors update in the output.

For deeper visual changes (typography, layout, spacing), edit the `<style>` block in `template.html` directly.

## Change the spend window

By default the report looks at the last 7 days of spend. To use a different window:

```json
{
  "spend_window_days": 30
}
```

This controls the `num_days` parameter passed to `compute_spend_response_curves`. Common values: 7, 14, 30. Larger values smooth out short-term noise but lag changes.

## Filter to specific channels

By default the bundle fetches curves for every channel in the deployment. If you only want to display a subset, you can:

**Option A — filter in `build.py`** (cleaner): in the `_current_spends_from_report` flow, filter the `channels` list before firing the report.

**Option B — filter in `template.html`** (lazier): in the inline `<script>`, filter `channels` after `window.REAL_DATA` loads:

```js
const channels = (window.REAL_DATA.channels || [])
  .filter(c => ["Linear TV", "Meta Prospecting", "Search Branded"].includes(c.channel));
```

## Restyle the curve cards

The curve cards are rendered in JS at the bottom of `template.html`. To change the layout, edit the `curveCard.innerHTML` template literal. The SVG itself is plain hand-built `<path>` markup — you can:

- Swap fill colors per channel by adding a `color` field to each channel in `build.py`'s `compute_summary` output
- Add tooltips on hover (add a `<title>` element inside each `<circle>`)
- Show confidence intervals if you have them in the API response (extend `_num` in `build.py` to extract `impact_low` / `impact_high`)

## Add new metrics to the summary tiles

The four tiles at the top are built from these computed values:
- `headroomCh`, `tightCh`, `satCh` — channel counts per status
- `weightedSat` — spend-weighted average saturation

Add tiles by appending to the `tiles` array in `template.html`. For instance, total spend tile:

```js
tiles.push({
  label: "Total weekly spend",
  value: fmtMoney(totalSpend),
  delta: "Across all channels",
});
```

## Change the `mROI < 2x` headroom threshold

Currently `build.py` computes headroom as the additional spend before marginal ROI drops below 2.0. To use a different floor:

```python
# in build.py compute_summary():
headroom_spend = _headroom(pts, cur_spend, mroi_floor=1.5)
```

## Add new channels' colors

By default the curve uses the brand `primary_color`. If you want each channel in its own color:

1. In `build.py`, add a palette dict:
   ```python
   CHANNEL_PALETTE = {
       "Linear TV": "#E37C65",
       "Meta Prospecting": "#2B5C8A",
       # ...
   }
   ```
2. Annotate each channel in `compute_summary` with its color.
3. In `template.html`, use `c.color` as the curve stroke instead of `var(--primary)`.

## Embed in a dashboard

The output `saturation-curves.html` is one self-contained file. Host it anywhere:
- Drop into your own static site
- Embed in an iframe inside another dashboard
- Host on S3 / Cloudflare Pages with auth (Cloudflare Access works well)

The file has no external dependencies beyond Google Fonts.

## Schedule weekly refreshes

Add a cron job:

```cron
0 9 * * 1  cd /path/to/bundle && python3 build.py my-config.json --rebuild
```

Every Monday at 9 AM, re-run with a fresh API pull. Output overwrites the previous file.

If you want to keep weekly archives, change `output_path` in config to include a date placeholder, then post-process in your cron:

```bash
python3 build.py my-config.json --rebuild
mv saturation-curves.html "saturation-curves-$(date +%Y-%m-%d).html"
```
