---
name: recast-saturation-curves
description: Build a Saturation Curve Tracker report from a Recast model using the compute_spend_response_curves API. Plots each channel's spend-vs-impact response curve, marks current spend position, and computes headroom + % saturated.
---

# Recast Saturation Curve Tracker Skill

Canonical agent entrypoint that runs the local `build.py` against a Recast model and produces the report HTML.

**This is the canonical agent entrypoint for guided builds.** The CLI command `python3 build.py my-config.json` does the same thing. Use the skill if you want a guided, interactive flow.

## Official Recast API docs

If API behavior is unclear, consult the official docs before changing endpoint paths, authentication, polling, or response parsing:

- Recast API authentication and tokens: https://docs.getrecast.com/docs/the-recast-api
- Optimizer API: https://docs.getrecast.com/docs/the-optimizer-api
- Forecaster API: https://docs.getrecast.com/docs/the-forecaster-api
- Spend Forecasting API: https://docs.getrecast.com/docs/spend-forecasting-api
- Helper endpoints: https://docs.getrecast.com/docs/helper-endpoints
- Insights API: https://docs.getrecast.com/docs/the-insights-api
- API FAQ: https://docs.getrecast.com/docs/api-faq
- Client-facing API reference: https://app.getrecast.com/api-docs/index.html

## When to invoke

User says any of:
- "Build the saturation curve tracker for [client]"
- "Run saturation curves on my Recast model"
- Drops a Recast client_slug + asks for saturation curves

## Setup (only required once)

1. Bundle unpacked at a known path
2. `.env` file exists with `API_PAT=gr_...`

If `.env` does not exist or contains the placeholder token, tell the user:

> Before I can run this, you need to put your Recast API token in `.env`. Copy `.env.example` to `.env` and paste your token after `API_PAT=`. Do NOT paste the token in this chat — I never need to see it.

## API token rules — non-negotiable

- **NEVER ask the user to paste the token into chat.**
- **NEVER save the token to memory or any persistent store.**
- **NEVER echo the token back in any message.**
- **NEVER write the token to `config.json` or any tracked file.**
- **NEVER create, edit, or print `.env` contents; the user owns that file.**
- If the user accidentally pastes the token in chat: tell them to regenerate it immediately, put the new one in `.env`, and proceed.

`build.py` reads `.env` directly. You never need to see or handle the token yourself.

## Intake — three questions

Use AskUserQuestion. Group when possible.

Do not ask for the API token. Tell the user to keep the token in `.env` and never paste it into chat. Create or edit only the user-owned config JSON, never `.env` contents or tracked files containing the token.

**Round 1 — client & KPI**
1. **Client slug** — "Which Recast client are we building this for? Use the slug from the Recast URL between `/clients/` and `/dashboards/`."
2. **KPI** — "Which KPI? Exact case-sensitive name as it appears in the Recast app."

**Round 2 — brand**
3. **Brand name** — "Brand name to show in the top-right of the report."
4. **Primary color** — "Brand primary color (hex). Defaults to Recast coral `#E37C65` if you skip."

## Preflight check (run this first)

Before the full build, validate the setup:

```bash
python3 build.py <their-config.json> --check
```

Read-only: confirms the token, KPI, deployment, and template, and prints a
plain-language error if anything is off. The check never prints the token. If
it passes, proceed to the build.

## Build step

Write the config to a user-owned JSON file (e.g., `their-client.json`):

```json
{
  "client_slug": "<client slug>",
  "kpi_name": "<KPI name>",
  "brand": {
    "name": "<brand name>",
    "primary_color": "<hex>",
    "accent_color": "#161614"
  },
  "output_path": "./saturation-curves.html",
  "data_dir": "./data",
  "spend_window_days": 7
}
```

Run:

```bash
python3 build.py <their-client.json>
```

Report progress to the user as each stage completes. When done, tell them:
1. Where the file is (`saturation-curves.html`)
2. How to open it (`open saturation-curves.html`)
3. That it's a single self-contained HTML file they can host anywhere

## Failure modes

| Symptom | Response |
|---|---|
| `API_PAT not set` | User hasn't put token in `.env`. Tell them to copy `.env.example` and edit. |
| `401 Unauthorized` | Token rejected. Ask them to regenerate in the Recast app and update `.env`. |
| `KPI 'X' not found` | Echo the list of available KPIs from the error message. Ask them to confirm exact spelling. |
| `Report polling timed out` | Re-run. Recast backend occasionally drops queued jobs. |
| `No curve data returned` | Confirm the model has channels with spend in the chosen window. May need to extend `spend_window_days`. |
| 422 `is not a supported report_type` | This report type has never been run for this client | Tell the user to run a Spend Response Curves report once from the Recast UI, then re-run the build. |
| `KPI '...' has no depvars` | Model inactive or KPI has no deployment | Ask the user to confirm the model is active in the Recast app. |

## What this skill does NOT do

- Modify the bundle source files
- Cache anything outside the bundle's local `./data/` directory
- Touch any file outside the bundle directory

Stay scoped to running the build. If the user asks for layout changes, point them to `docs/customize.md`.
