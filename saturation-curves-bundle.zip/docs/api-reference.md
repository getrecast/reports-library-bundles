# Recast API endpoints used by this bundle

This bundle hits three Recast API endpoints. All require a valid Personal Access Token (PAT) in the `Authorization: Bearer ...` header.

## Official Recast API docs

This file covers only the endpoints used by this bundle. For current API contracts, auth/token setup, helper endpoints, and broader Recast APIs, consult:

- Recast API authentication and tokens: https://docs.getrecast.com/docs/the-recast-api
- Optimizer API: https://docs.getrecast.com/docs/the-optimizer-api
- Forecaster API: https://docs.getrecast.com/docs/the-forecaster-api
- Spend Forecasting API: https://docs.getrecast.com/docs/spend-forecasting-api
- Helper endpoints: https://docs.getrecast.com/docs/helper-endpoints
- Insights API: https://docs.getrecast.com/docs/the-insights-api
- API FAQ: https://docs.getrecast.com/docs/api-faq
- Client-facing API reference: https://app.getrecast.com/api-docs/index.html

## Base URL

Default: `https://api.getrecast.com/v1`

Override via the `RECAST_API_BASE` environment variable in `.env` if you're on a non-default deployment.

## Authentication

```
Authorization: Bearer gr_your_token_here
```

Tokens are scoped to the user account that generated them. Anyone with your token has the same data access you do.

## 1. List KPIs for a client

```
GET /clients/{client_slug}/kpis
```

Used to find the KPI by name and resolve its deployment ID.

**Response shape (relevant fields):**
```json
[
  {
    "id": "<kpi_id>",
    "name": "<KPI display name>",
    "depvar_configurations": [
      { "deployment_id": 12345 }
    ],
    "depvars": [
      { "slug": "<kpi_slug>", "weight": 1.0 }
    ]
  }
]
```

The bundle matches `kpi_name` from your config against `name` (case-sensitive), then resolves the deployment ID. Older API responses carry `depvar_configurations[].deployment_id`; the current API returns `depvars[].slug` instead, and `build.py` resolves the slug to the active deployment via `GET /clients/{client_slug}/deployments`. The script handles both shapes.

## 2. Get deployment metadata

```
GET /clients/{client_slug}/deployments/{deployment_id}?extra_fields=spend_channels_labels,upper_funnel_channel_labels,lower_funnel_channel_labels
```

Used to get the model end date and the full channel list. The current API returns the model end date as `end_date`; older responses used `model_date` or `model_end_date`. `build.py` tries all three.

**Response shape (relevant fields):**
```json
{
  "end_date": "YYYY-MM-DD",
  "spend_channels_labels": ["channel_a", "channel_b", ...],
  "upper_funnel_channel_labels": [...],
  "lower_funnel_channel_labels": [...]
}
```

## 3. Fire and poll `compute_spend_response_curves`

**Create:**
```
POST /clients/{client_slug}/reports
Content-Type: application/json

{
  "form": {
    "report_type": "compute_spend_response_curves",
    "deployment_id": <id>,
    "date": "<model_date>",
    "num_days": 7,
    "channels": ["channel_a", "channel_b", ...]
  },
  "show_in_ui": false
}
```

**Poll:**
```
GET /clients/{client_slug}/reports/{report_id}
```

Returns `status` of `queued`, `running`, `success`, or `error`. The bundle polls every 15 seconds until completion (10-minute timeout by default).

**Download curve CSVs:**
```
GET /clients/{client_slug}/reports/{report_id}/downloads/{download_key}
Accept: text/csv
```

One CSV per channel. Each row is one point on the spend-impact response curve.

## Rate limits

Recast limits report creation to roughly 25 per minute. This bundle fires a single report, so rate limits should not be a concern. If you're chaining this bundle with others, add a 0.2-second pause between report creates.

## Errors you may see

| HTTP status | Meaning | What to do |
|---|---|---|
| 401 | Token rejected | Regenerate, update `.env` |
| 403 | Token valid but lacks access to this client | Check that your account has access |
| 404 | Client slug or KPI not found | Verify slug + KPI spelling |
| 422 | Bad parameters (e.g., date out of range) | Check your config |
| 429 | Rate-limited | Wait and retry |
| 5xx | Recast backend issue | Wait and retry; contact support if persistent |

## Going further

The Recast API exposes many more endpoints. Full documentation is at the Recast API docs (or contact your account team for access).

Other endpoints relevant to extending this bundle:
- `compute_insights_overview` — channel-level ROI/mROI snapshots
- `compute_grouped_channel_summaries` — per-channel weekly time series
- `compute_lower_funnel_waterfall` — drivers of lower-funnel spend
- `compute_marketing_vs_baseline` — baseline vs marketing decomposition
