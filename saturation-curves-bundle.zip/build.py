#!/usr/bin/env python3
"""
Saturation Curve Tracker — build script.

Reads a config JSON, hits the Recast API for `compute_spend_response_curves`,
fills the local template.html, writes a self-contained HTML report.

Stdlib only. Python 3.10+.

Usage:
    python3 build.py my-config.json
    python3 build.py my-config.json --rebuild   # force fresh API pull

Token loaded from .env (API_PAT=gr_...) in the same directory.
"""

from __future__ import annotations

import argparse
import csv
import io
import json
import os
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path


def import_shared_runner():
    here = Path(__file__).parent.resolve()
    for candidate in (here / "_shared", here.parent / "_shared"):
        if candidate.exists():
            sys.path.insert(0, str(candidate))
            import recast_runner
            return recast_runner
    print("[BLOCK] Shared runner is missing -> Re-download the bundle or run the package script before distributing", file=sys.stderr)
    sys.exit(1)


rr = import_shared_runner()
rr.require_python_version((3, 10))
REQUIRED_REPORT_TYPES = ["compute_spend_response_curves"]


def die(msg):
    print(f"ERROR: {msg}", file=sys.stderr)
    sys.exit(1)


def load_dotenv(path):
    if not path.exists():
        return
    for raw in path.read_text().splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, _, v = line.partition("=")
        k = k.strip()
        v = v.strip().strip('"').strip("'")
        if k and k not in os.environ:
            os.environ[k] = v


def api(method, path, token, base, body=None, accept="application/json"):
    url = base.rstrip("/") + path
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Authorization", f"Bearer {token}")
    req.add_header("Accept", accept)
    if data is not None:
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            return resp.read()
    except urllib.error.HTTPError as e:
        body_text = e.read().decode(errors="replace") if hasattr(e, "read") else str(e)
        die(f"API {method} {path} failed ({e.code}): {body_text}")


def get_json(path, token, base):
    return json.loads(api("GET", path, token, base))


def post_json(path, body, token, base):
    return json.loads(api("POST", path, token, base, body=body))


def get_csv(path, token, base):
    return api("GET", path, token, base, accept="text/csv").decode()


def num(v):
    if v is None or v == "":
        return None
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def resolve_kpi(client_slug, kpi_name, token, base):
    print(f"[1/5] Looking up KPI '{kpi_name}' for '{client_slug}'...", flush=True)
    resp = get_json(f"/clients/{client_slug}/kpis", token, base)
    items = resp if isinstance(resp, list) else resp.get("data") or resp.get("kpis") or []
    for k in items:
        if k.get("name") == kpi_name:
            # Legacy API shape: depvar_configurations[].deployment_id
            deps = k.get("depvar_configurations") or []
            if deps:
                return str(deps[0]["deployment_id"])
            # Current API shape: depvars[].slug — resolve the active deployment by slug
            depvars = k.get("depvars") or []
            if not depvars:
                die(f"KPI '{kpi_name}' has no depvars. Confirm the model is active.")
            depvar_slug = depvars[0]["slug"]
            all_deps = get_json(f"/clients/{client_slug}/deployments", token, base)
            dep_items = all_deps if isinstance(all_deps, list) else all_deps.get("data") or all_deps.get("deployments") or []
            for d in dep_items:
                full = get_json(f"/clients/{client_slug}/deployments/{d['id']}", token, base)
                if full.get("dashboard_slug") == depvar_slug and full.get("active"):
                    return str(full["id"])
            die(f"KPI '{kpi_name}': no active deployment found for its depvar slug. Confirm the model is active.")
    available = ", ".join(k.get("name", "?") for k in items)
    die(f"KPI '{kpi_name}' not found. Available: {available}")


def get_deployment(client_slug, deployment_id, token, base):
    print(f"[2/5] Fetching deployment {deployment_id}...", flush=True)
    extra = "spend_channels_labels"
    return get_json(
        f"/clients/{client_slug}/deployments/{deployment_id}?extra_fields={extra}",
        token, base,
    )


def fire_and_poll(client_slug, deployment_id, model_date, channels, window_days, token, base, timeout=600):
    print(f"[3/5] Firing compute_spend_response_curves for {len(channels)} channels...", flush=True)
    body = {
        "form": {
            "report_type": "compute_spend_response_curves",
            "deployment_id": deployment_id,
            "date": model_date,
            "num_days": window_days,
            "channels": channels,
        },
        "show_in_ui": False,
    }
    resp = post_json(f"/clients/{client_slug}/reports", body, token, base)
    report_id = str(resp["id"])
    print(f"      Polling report {report_id} (max {timeout}s)...", flush=True)
    deadline = time.time() + timeout
    while time.time() < deadline:
        r = get_json(f"/clients/{client_slug}/reports/{report_id}", token, base)
        status = r.get("status")
        if status == "success":
            return r
        if status == "error":
            die(f"Report {report_id} errored: {r.get('error', '(no detail)')}")
        time.sleep(15)
    die(f"Report polling timed out after {timeout}s.")


def _channel_from_key(key):
    """Extract the channel slug from a single-channel download key like
    'multi_day-single_channel-affiliate-tables-total'. Segments use '_' internally
    and '-' as the separator, so the marker token is 'single_channel'."""
    parts = key.split("-")
    try:
        ch_start = parts.index("single_channel") + 1
    except ValueError:
        return key
    try:
        ch_end = parts.index("tables", ch_start)
    except ValueError:
        ch_end = len(parts)
    return "-".join(parts[ch_start:ch_end]) or key


def _detect_columns(fieldnames):
    """Find (spend_col, impact_col) across known and current API CSV shapes.

    Multi-channel files: channel,spend,total_mean,total_q2.5,...  → spend/total_mean
    Single-channel files: 7_day_spend,<kpi_slug>,cpa              → 7_day_spend/<kpi_slug>
    """
    fields = [f for f in (fieldnames or []) if f]
    spend_col = next((c for c in fields if c in ("spend", "x", "Spend")), None) \
        or next((c for c in fields if c.lower().endswith("_spend")), None)
    known_impact = ("impact_total", "y", "Impact", "incremental_revenue", "total_mean")
    impact_col = next((c for c in fields if c in known_impact), None)
    if impact_col is None:
        rest = [c for c in fields
                if c != spend_col and c != "channel"
                and "cpa" not in c.lower() and "_q" not in c.lower()]
        impact_col = rest[0] if rest else None
    return spend_col, impact_col


def download_curves(client_slug, report, data_dir, token, base):
    print("[4/5] Downloading curve CSVs...", flush=True)
    data_dir.mkdir(parents=True, exist_ok=True)
    report_id = report["id"]
    multi, single_direct, single_total = {}, {}, {}
    for dl in report.get("results", {}).get("downloads", []) or []:
        key = dl.get("key") or dl.get("name") or ""
        if not key:
            continue
        text = get_csv(
            f"/clients/{client_slug}/reports/{report_id}/downloads/{urllib.parse.quote(key)}",
            token, base,
        )
        (data_dir / f"{key}.csv").write_text(text)
        rows = list(csv.DictReader(io.StringIO(text)))
        if not rows:
            continue
        spend_col, impact_col = _detect_columns(rows[0].keys())
        if spend_col is None or impact_col is None:
            continue

        def points_from(rws):
            pts = []
            for row in rws:
                spend = num(row.get(spend_col))
                impact = num(row.get(impact_col))
                if spend is None or impact is None:
                    continue
                pts.append({"spend": spend, "impact": impact})
            return sorted(pts, key=lambda p: p["spend"])

        if "channel" in rows[0]:
            groups = {}
            for row in rows:
                groups.setdefault(row.get("channel") or "", []).append(row)
            for ch, rws in groups.items():
                pts = points_from(rws)
                if ch and pts:
                    multi[ch] = pts
        else:
            ch = _channel_from_key(key)
            pts = points_from(rows)
            if not pts:
                continue
            if "-tables-total" in key:
                single_total[ch] = pts
            else:
                single_direct[ch] = pts
    # Single-channel totals are the preferred series; direct-only fills gaps;
    # the multi-channel table backstops anything not covered by either.
    curves = {}
    curves.update(multi)
    curves.update(single_direct)
    curves.update(single_total)
    if not curves:
        die("No curve data returned. Check that channels have spend in the chosen window.")
    return curves


def curves_from_download_csvs(csvs):
    multi, single_direct, single_total = {}, {}, {}
    for key, text in csvs.items():
        rows = list(csv.DictReader(io.StringIO(text)))
        if not rows:
            continue
        spend_col, impact_col = _detect_columns(rows[0].keys())
        if spend_col is None or impact_col is None:
            continue

        def points_from(rws):
            pts = []
            for row in rws:
                spend = num(row.get(spend_col))
                impact = num(row.get(impact_col))
                if spend is None or impact is None:
                    continue
                pts.append({"spend": spend, "impact": impact})
            return sorted(pts, key=lambda p: p["spend"])

        if "channel" in rows[0]:
            groups = {}
            for row in rows:
                groups.setdefault(row.get("channel") or "", []).append(row)
            for ch, rws in groups.items():
                pts = points_from(rws)
                if ch and pts:
                    multi[ch] = pts
        else:
            ch = _channel_from_key(key)
            pts = points_from(rows)
            if not pts:
                continue
            if "-tables-total" in key:
                single_total[ch] = pts
            else:
                single_direct[ch] = pts
    curves = {}
    curves.update(multi)
    curves.update(single_direct)
    curves.update(single_total)
    if not curves:
        rr.block("No curve data returned from spend response CSV downloads", "Check that channels have spend in the chosen window")
    return curves


def curve_report_record(label, report, form, csvs):
    return {
        "label": label,
        "report_id": str(report.get("id", "")),
        "form": form,
        "downloads": {
            key: {"row_count": len(rr.read_csv_text(text))}
            for key, text in csvs.items()
        },
    }


def interp(points, x):
    """Linear interp y(x) over sorted points."""
    if not points:
        return 0
    if x <= points[0]["spend"]:
        return points[0]["impact"]
    if x >= points[-1]["spend"]:
        return points[-1]["impact"]
    for a, b in zip(points, points[1:]):
        if a["spend"] <= x <= b["spend"] and b["spend"] != a["spend"]:
            t = (x - a["spend"]) / (b["spend"] - a["spend"])
            return a["impact"] + t * (b["impact"] - a["impact"])
    return 0


def headroom(points, cur, mroi_floor=2.0):
    """Additional spend before marginal ROI drops below floor."""
    if len(points) < 2:
        return 0
    for a, b in zip(points, points[1:]):
        if b["spend"] <= cur or b["spend"] == a["spend"]:
            continue
        mroi = (b["impact"] - a["impact"]) / (b["spend"] - a["spend"])
        if mroi < mroi_floor:
            return max(0, b["spend"] - cur)
    return max(0, points[-1]["spend"] - cur)


def current_spend_for(channel, curves, highlights):
    """Best-effort current spend. Falls back to median curve x if API doesn't surface it."""
    surfaced = highlights.get("current_spends") or highlights.get("channel_spends") or {}
    if channel in surfaced and num(surfaced[channel]) is not None:
        return float(surfaced[channel])
    # Fallback: median of the curve's spend axis. Curves are typically anchored
    # around recent spend, so median is a sensible default for the marker.
    pts = curves.get(channel, [])
    if not pts:
        return 0
    spends = sorted(p["spend"] for p in pts)
    return spends[len(spends) // 2]


def build_payload(curves, highlights):
    out = []
    for ch, pts in curves.items():
        max_impact = max(p["impact"] for p in pts) if pts else 0
        cur = current_spend_for(ch, curves, highlights)
        cur_impact = interp(pts, cur)
        pct_sat = (cur_impact / max_impact * 100) if max_impact > 0 else 0
        status = "headroom" if pct_sat < 70 else ("tight" if pct_sat < 90 else "saturated")
        out.append({
            "channel": ch,
            "points": pts,
            "current_spend": cur,
            "current_impact": cur_impact,
            "max_impact": max_impact,
            "pct_saturated": pct_sat,
            "headroom_spend": headroom(pts, cur, 2.0),
            "status": status,
        })
    return {"channels": out}


def render(template_path, output_path, payload, config, model_date):
    print(f"[5/5] Rendering → {output_path}", flush=True)
    html = template_path.read_text()
    replacements = {
        "{{BRAND_NAME}}": config["brand"]["name"],
        "{{PAGE_TITLE}}": config.get("page_title", "Saturation Curve Tracker"),
        "{{KPI_NAME}}": config["kpi_name"],
        "{{PRIMARY_COLOR}}": config["brand"].get("primary_color", "#E37C65"),
        "{{ACCENT_COLOR}}": config["brand"].get("accent_color", "#161614"),
        "{{MODEL_END_DATE}}": model_date,
        "{{SPEND_WINDOW_DAYS}}": str(config.get("spend_window_days", 7)),
        "{{REAL_DATA_JSON}}": json.dumps(payload),
    }
    for k, v in replacements.items():
        html = html.replace(k, v)
    output_path.write_text(html)


def run_check(config, token):
    """Preflight (--check): validate token, API access, KPI, and deployment shape.

    Read-only — fires no report, writes nothing, never prints the token.
    """
    base = os.environ.get("RECAST_API_BASE", "https://api.getrecast.com/v1")
    client_slug = config["client_slug"]
    kpi_name = config["kpi_name"]
    print(f"Preflight check — client '{client_slug}', KPI '{kpi_name}'", flush=True)
    resp = get_json(f"/clients/{client_slug}/kpis", token, base)
    items = resp if isinstance(resp, list) else resp.get("data") or resp.get("kpis") or []
    print(f"  OK   API token accepted; {len(items)} KPI(s) visible on this client")
    deployment_id = resolve_kpi(client_slug, kpi_name, token, base)
    print(f"  OK   KPI resolved to active deployment {deployment_id}")
    deployment = get_json(
        f"/clients/{client_slug}/deployments/{deployment_id}?extra_fields=spend_channels_labels",
        token, base,
    )
    model_date = deployment.get("model_date") or deployment.get("model_end_date") or deployment.get("end_date") or ""
    if not model_date:
        die("Deployment has no model end date (checked model_date, model_end_date, end_date). "
            "The API shape may have changed — see docs/api-reference.md.")
    print(f"  OK   Model end date: {model_date}")
    channels = deployment.get("spend_channels_labels") or []
    if channels:
        print(f"  OK   {len(channels)} spend channel(s) on the deployment")
    else:
        print("  WARN No spend_channels_labels returned — the build may fail at the report step")
    if not (Path(__file__).parent / "template.html").exists():
        die("template.html missing next to build.py — re-download the bundle.")
    print("  OK   template.html present")
    print()
    print("Note: this check cannot verify report-type activation. If the build later fails")
    print("with 'is not a supported report_type', run this report once from the Recast UI")
    print("first (see INSTALL.md troubleshooting), then re-run build.py.")
    print()
    print("Preflight passed. Next: python3 build.py <your-config.json>")


def probe_report_types(config, client, bundle_dir=None):
    here = Path(bundle_dir).resolve() if bundle_dir else Path(__file__).parent.resolve()
    return rr.probe_report_types(client, config, REQUIRED_REPORT_TYPES, template_path=here / "template.html")


def build_with_client(config, client, bundle_dir=None, rebuild=False):
    rr.validate_config(config, required=("client_slug", "kpi_name", "brand.name"))
    here = Path(bundle_dir).resolve() if bundle_dir else Path(__file__).parent.resolve()
    client_slug = config["client_slug"]
    kpi_name = config["kpi_name"]
    window = int(config.get("spend_window_days", 7))
    data_dir = Path(config.get("data_dir", "./data")).expanduser().resolve()
    output_path = Path(config.get("output_path", "./saturation-curves.html")).expanduser().resolve()
    template_path = here / "template.html"
    cache = data_dir / "manifest.json"

    deployment_id = rr.resolve_kpi(client, client_slug, kpi_name)
    deployment = rr.get_deployment(client, client_slug, deployment_id)
    model_date = rr.deployment_model_date(deployment)
    channels = deployment.get("spend_channels_labels") or []
    if not channels:
        rr.block("No spend channels on this deployment", "Choose a KPI with active spend channels")
    form = {
        "report_type": "compute_spend_response_curves",
        "deployment_id": deployment_id,
        "date": model_date,
        "num_days": window,
        "channels": channels,
    }
    cache_key = rr.build_cache_key("saturation-curves", config, deployment_id, [form])

    if cache.exists() and not rebuild:
        print("Using cached API data (pass --rebuild to refresh).", flush=True)
        data, manifest = rr.load_cached_data(cache, cache_key)
        curves = data["curves"]
        highlights = data["highlights"]
        model_date = data["model_date"]
    else:
        print(f"[3/5] Firing compute_spend_response_curves for {len(channels)} channels...", flush=True)
        report_id = rr.create_report(client, client_slug, form)
        print(f"[4/5] Polling report {report_id} and downloading curve CSVs...", flush=True)
        report = rr.poll_report(client, client_slug, report_id)
        csvs = rr.download_report_csvs(client, client_slug, report, data_dir / "curves")
        curves = curves_from_download_csvs(csvs)
        highlights = (report.get("results") or {}).get("highlights") or {}
        record = curve_report_record("spend_response_curves", report, form, csvs)
        manifest = rr.make_manifest(
            "saturation-curves",
            config,
            deployment_id,
            cache_key,
            [record],
            {
                "curves": curves,
                "highlights": highlights,
                "model_date": model_date,
            },
        )
        rr.write_manifest(cache, manifest)

    payload = build_payload(curves, highlights)
    render(template_path, output_path, payload, config, model_date)
    rr.reconcile_rendered_payload(
        output_path,
        payload,
        required_paths=("channels",),
        disallowed_markers=("Math.random", "mock fallback", "Synthetic"),
    )
    print(f"✓ Done. Open: {output_path}", flush=True)
    return {"output_path": str(output_path), "manifest": manifest, "payload": payload}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("config")
    parser.add_argument("--check", action="store_true", help="validate setup and API access without building the report")
    parser.add_argument("--probe-report-types", action="store_true", help="create minimal hidden reports to verify report-type activation")
    parser.add_argument("--rebuild", action="store_true", help="force fresh API pull")
    args = parser.parse_args()

    here = Path(__file__).parent.resolve()
    rr.load_dotenv(here / ".env")
    token = rr.validate_token(os.environ.get("API_PAT", ""))
    config = rr.load_config(Path(args.config).resolve(), required=("client_slug", "kpi_name", "brand.name"))
    client = rr.RecastClient(token)

    if args.check and args.probe_report_types:
        rr.block("Choose either --check or --probe-report-types, not both", "--check is read-only; --probe-report-types creates reports")
    if args.check:
        result = rr.preflight_check(client, config, template_path=here / "template.html")
        print(f"Preflight check — client '{result['client_slug']}', KPI '{result['kpi_name']}'", flush=True)
        print(f"  OK   KPI resolved to active deployment {result['deployment_id']}")
        print(f"  OK   Model end date: {result['model_date']}")
        print(f"  OK   {len(result['channels'])} spend channel(s) on the deployment")
        print("  OK   template.html present")
        print("Preflight passed. Next: python3 build.py <your-config.json>")
        return
    if args.probe_report_types:
        result = probe_report_types(config, client, bundle_dir=here)
        print(f"Probe created {len(result['created'])} hidden report(s).")
        return
    build_with_client(config, client, bundle_dir=here, rebuild=args.rebuild)


if __name__ == "__main__":
    rr.exit_block(main)
