# Install & API Key Safety

## Prerequisites

- Python 3.10 or later (check with `python3 --version`). Comes preinstalled on macOS and most Linux distros.
- A Recast API token. Generate one in the Recast app: click your email (top right) → **Generate API token**.

No `pip install` step. This bundle is stdlib-only.

## Setup

### 1. Get the bundle

If you downloaded the zip from a release, unzip it anywhere — `~/recast-saturation-curves/` works fine.

```bash
unzip saturation-curves-bundle.zip
cd saturation-curves-bundle
```

### Optional: make the agent skill available

This bundle includes `docs/SKILL.md`, an optional agent guide for Claude Code, Codex, or another AI coding assistant. You do not need to install it to run the report; `python3 build.py my-config.json` is the primary interface.

If your assistant supports local skills, add `docs/SKILL.md` to its configured skills folder or point the assistant at this file before asking it to run or customize the bundle. The skill tells the assistant to keep your token in `.env`, run `--check` before the full build, and stay scoped to this bundle directory.

### 2. Put your API token in `.env`

```bash
cp .env.example .env
# Open .env in any editor and replace `gr_replace_with_your_token` with your real token.
```

`.env` is **git-ignored by default** (see `.gitignore`). It never gets committed.

Keep token and slug separate: `.env` holds `API_PAT`; `my-config.json` holds `client_slug` and report settings.

### 3. Create your config

```bash
cp config.example.json my-config.json
# Edit my-config.json:
#   - "client_slug" → the Recast URL path between `/clients/` and `/dashboards/`
#   - "kpi_name"    → the KPI you want curves for (e.g., "Revenue", "Signups", "Subscriptions")
#   - "brand"       → primary + accent hex colors
```

### 4. Run

```bash
python3 build.py my-config.json
```

Outputs `saturation-curves.html` (~80–120 KB depending on channel count). Open in a browser.

## API token safety — read this

**Do:**
- Store the token in `.env`. The included `.gitignore` blocks it.
- Use your own personal token. Don't share tokens between teammates.
- Regenerate immediately if your token ends up in chat, Slack, email, or a screen share.

**Don't:**
- Commit the token to git. (The `.gitignore` is your safety net, not a substitute for not pasting it.)
- Hardcode the token into `config.json` or `build.py`.
- Paste the raw token into any chat tool (Claude Code, ChatGPT, etc.) — see "Working with AI assistants" below.
- Add `export API_PAT=...` permanently to `~/.zshrc` or `~/.bashrc`. It ends up in shell history and process listings.

**If exposed:**
- Regenerate in the Recast app immediately (this invalidates the old token).
- Your token has the same access scope as your user account — anyone with it can see whatever data your Recast user can see.

## Working with AI assistants (Claude Code, etc.)

If you want to use Claude Code or another AI assistant to help customize this bundle:

1. **Never paste your token into the chat.** Put it in `.env` and tell the assistant: "Use the token in `.env`. Don't read it back to me."
2. `build.py` loads `.env` automatically — the assistant doesn't need to see the token to run the script.
3. If the assistant suggests editing a tracked file (like `config.json`) to include the token, decline.

For optional local agent skill setup, see "Optional: make the agent skill available" above.

## First-time setup: activate the report type

The Recast API currently requires each report type to have been run at least once
from the Recast UI before it can be created via the API. On a client account that
has never used this report, `build.py` fails with a 422 error mentioning
`report_type`. Fix: open the Recast app, run a Spend Response Curves report once from
the UI, then re-run `build.py`.

## Troubleshooting

| Symptom | Likely cause | Fix |
|---|---|---|
| `API_PAT not set` | `.env` missing or token field empty | Confirm `.env` exists, has `API_PAT=gr_...`, no quotes |
| `KPI '...' not found` | KPI name doesn't match what's in your model | Check exact spelling in the Recast app. Case-sensitive. |
| `KPI '...' has no depvars` | The model has no active deployment for that KPI | Confirm the model is active in the Recast app |
| `report_type is not a supported report_type` (422) | This report type has never been run for your client | Run a Spend Response Curves report once from the Recast UI, then re-run `build.py` |
| `401 Unauthorized` | Token rejected | Regenerate the token. Update `.env`. Old token is now invalid. |
| `Report polling timed out` | Recast queue dropped the job | Re-run `python3 build.py my-config.json` |
| `No spend channels returned` | Model deployment has no active channels | Confirm your Recast model is healthy in the app |
| Output HTML opens blank | JSON parse error from corrupted CSV | Delete `./data/` and re-run with a fresh API pull |

## How long does it take?

| Step | Time |
|---|---|
| API discovery (KPI + deployment lookup) | ~2 seconds |
| Firing `compute_spend_response_curves` report | ~1-3 minutes |
| Downloading + parsing CSVs | ~5 seconds |
| Building the HTML | ~1 second |
| **Total first run** | **~2-4 minutes** |

Re-runs use cached CSV data in `./data/` and are nearly instant. Pass `--rebuild` to force a fresh API pull.

```bash
python3 build.py my-config.json --rebuild
```

## Sharing the output

`saturation-curves.html` is a single self-contained file. Open it in any browser, no server needed.

Distribute via:
- Slack DM / email attachment
- Upload to your own static hosting (S3, Cloudflare Pages, Netlify, etc.)
- Inline preview in a deck or Loom

Recipients don't need anything installed.
