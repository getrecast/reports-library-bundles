# Recast API endpoints used by this bundle

This bundle hits four Recast API endpoints. All require a valid Personal Access Token (PAT).

## Official Recast API docs

This file covers only the endpoints used by this bundle. For current API contracts, auth/token setup, helper endpoints, and broader Recast APIs, consult:

- Recast API authentication and tokens: https://docs.getrecast.com/docs/the-recast-api
- Optimizer API: https://docs.getrecast.com/docs/the-optimizer-api
- Forecaster API: https://docs.getrecast.com/docs/the-forecaster-api
- Spend Forecasting API: https://docs.getrecast.com/docs/spend-forecasting-api
- Helper endpoints: https://docs.getrecast.com/docs/helper-endpoints
- Insights API: https://docs.getrecast.com/docs/the-insights-api
- API FAQ: https://docs.getrecast.com/docs/api-faq
- Client-facing API reference: https://app.getrecast.com/api-docs/index.html

## Base URL

Default: `https://api.getrecast.com/v1`. Override via `RECAST_API_BASE` in `.env`.

## Authentication

```
Authorization: Bearer gr_your_token_here
```

## 1. List KPIs

```
GET /clients/{client_slug}/kpis
```

Used to resolve the KPI name to its deployment ID.

## 2. Get deployment metadata

```
GET /clients/{client_slug}/deployments/{deployment_id}?extra_fields=spend_channels_labels
```

Returns the model end date — `end_date` in the current API; older responses use `model_date` or `model_end_date`, and `build.py` tries all three — used as the upper bound for all windows, plus channel labels.

## 3. Fire three `compute_insights_overview` reports

For each of three windows (current 7d, prior 7d, 7d ending 30 days ago):

```
POST /clients/{client_slug}/reports
{
  "form": {
    "report_type": "compute_insights_overview",
    "deployment_id": <id>,
    "start_date": "<YYYY-MM-DD>",
    "end_date": "<YYYY-MM-DD>"
  },
  "show_in_ui": false
}
```

## 4. Poll each report

```
GET /clients/{client_slug}/reports/{report_id}
```

When each report succeeds, the completed report includes `results.downloads[]`.
The bundle downloads the overview CSVs and reads per-channel spend, ROI, and
mROI from `summaries-total-roi.csv` and `summaries-direct-mroi.csv`, then
computes WoW + MoM deltas locally.

## Errors

| HTTP status | Meaning | What to do |
|---|---|---|
| 401 | Token rejected | Regenerate, update `.env` |
| 403 | Lack of access to this client | Confirm your account has access |
| 404 | Slug/KPI not found | Check spelling |
| 422 | Bad parameters | Check date range and deployment_id |
| 5xx | Recast backend issue | Retry; contact support if persistent |
