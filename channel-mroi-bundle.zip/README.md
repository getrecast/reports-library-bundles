# Channel mROI · Stock-Picker View — Recast Reports Library

Ranks every channel by current marginal ROI. WoW and MoM deltas show momentum. A weekly pulse for marketers tracking saturation and trajectory across the portfolio.

**Live preview:** [https://research.getrecast.com/report-template-library/channel-mroi/](https://research.getrecast.com/report-template-library/channel-mroi/)

## What it does

For your Recast model + chosen KPI:

1. Fires three `compute_insights_overview` reports — current 7d, prior 7d, and the 7d window ending 30 days ago
2. Extracts per-channel mROI, ROI, and spend from each
3. Computes WoW and MoM deltas as percent change in mROI
4. Classifies each channel as Strong / Healthy / Saturating
5. Outputs a single self-contained HTML file

## Prerequisites

- A Recast account with API access enabled
- A Recast API token — see [INSTALL.md](INSTALL.md)
- Python 3.10+ (stdlib only)

## Quick start

`.env` holds `API_PAT`; `my-config.json` holds `client_slug` and report settings.

```bash
cp .env.example .env
# Edit .env and paste your token.
# Edit .env: API_PAT=gr_your_actual_token

cp config.example.json my-config.json
# Edit my-config.json: set client_slug, kpi_name, brand colors

python3 build.py my-config.json --check
python3 build.py my-config.json
# → outputs channel-mroi.html
```

The `--check` preflight is read-only — it confirms your token works, your KPI name resolves, and the API
returns the shapes this bundle expects, with a plain-language error if anything
is off. It never prints your token. If the build later fails with a 422
mentioning `report_type`, run the report once from the Recast UI first (see
`INSTALL.md`).

See [INSTALL.md](INSTALL.md) for token safety details and [docs/customize.md](docs/customize.md) for layout/data tweaks.

## What's in this bundle

| File | Purpose |
|---|---|
| `README.md` | This file. |
| `INSTALL.md` | Setup + API key safety. |
| `build.py` | Stdlib Python script. Hits the API, builds the report. |
| `template.html` | Report HTML with `{{PLACEHOLDER}}` tokens that `build.py` replaces. |
| `config.example.json` | Generic config template. |
| `.env.example` | Generic env template. |
| `.gitignore` | Blocks `.env`, configs, generated output. |
| `docs/api-reference.md` | The Recast API endpoints this bundle uses. |
| `docs/customize.md` | How to change layout, channels, time window, styling. |
| `docs/SKILL.md` | Canonical agent entrypoint for guided builds. |

## Support

Bundle issues: [recast-research-pages issues](https://github.com/getrecast/recast-research-pages/issues).
Recast API issues: contact your account team.
