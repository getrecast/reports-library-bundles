# Recast-Driven Experimentation Roadmap — Recast Reports Library

Plots each channel's modeled uncertainty against current spend. Top-right quadrant = channels where the next lift test moves the most signal. Replaces gut-call test prioritization with a data-driven view.

**Live preview:** [https://research.getrecast.com/report-template-library/testing-roadmap/](https://research.getrecast.com/report-template-library/testing-roadmap/)

## What it does

For your Recast model + chosen KPI:

1. Fires `compute_insights_overview` for the configured window (default 30 days)
2. Extracts per-channel spend, mean impact, and uncertainty bounds (p25, p75)
3. Computes IQR per channel and median thresholds across the portfolio
4. Flags channels above both medians as test candidates and ranks them
5. Optionally renders prior lift test history from a CSV you provide

## Prerequisites

- Recast API access + token (see [INSTALL.md](INSTALL.md))
- Python 3.10+ (stdlib only)

## Quick start

`.env` holds `API_PAT`; `my-config.json` holds `client_slug` and report settings.

```bash
cp .env.example .env
# Edit .env and paste your token.
cp config.example.json my-config.json
# Edit my-config.json: client_slug, kpi_name, brand colors
python3 build.py my-config.json --check
python3 build.py my-config.json
# → outputs testing-roadmap.html
```

The `--check` preflight is read-only — it confirms your token works, your KPI name resolves, and the API
returns the shapes this bundle expects, with a plain-language error if anything
is off. It never prints your token. If the build later fails with a 422
mentioning `report_type`, run the report once from the Recast UI first (see
`INSTALL.md`).

## Adding prior experiments

If you want the "Recent lift tests" section populated, create an `experiments.csv` with these columns and reference it in your config:

```csv
channel,label,test_type,window,measured,modeled,outcome,note
meta_retargeting,Meta Retargeting,Geo holdout,Aug 2025,iROAS 2.0x,2.4x,trimmed ~17%,"9 months old — back on the list"
mailers,Mailers,Geo holdout,Sep 2025,iROAS 1.6x,1.5x,confirmed,model held within interval
```

Then add to your config:
```json
{ "experiments_csv": "./experiments.csv" }
```

## What's in this bundle

| File | Purpose |
|---|---|
| `README.md`, `INSTALL.md` | Docs. |
| `build.py` | Hits the API, computes candidate ranking, fills the template. |
| `template.html` | Scatter + ranking + experiments table. |
| `config.example.json`, `.env.example`, `.gitignore` | Setup. |
| `docs/api-reference.md` | API endpoints used. |
| `docs/customize.md` | Layout + data tweaks. |
| `docs/SKILL.md` | Canonical agent entrypoint for guided builds. |

## Support

Bundle issues: [recast-research-pages issues](https://github.com/getrecast/recast-research-pages/issues).
