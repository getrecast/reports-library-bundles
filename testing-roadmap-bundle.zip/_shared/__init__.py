"""Shared Reports Library runtime helpers."""
