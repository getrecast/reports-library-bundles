# Recast API endpoints used by this bundle

## Official Recast API docs

This file covers only the endpoints used by this bundle. For current API contracts, auth/token setup, helper endpoints, and broader Recast APIs, consult:

- Recast API authentication and tokens: https://docs.getrecast.com/docs/the-recast-api
- Optimizer API: https://docs.getrecast.com/docs/the-optimizer-api
- Forecaster API: https://docs.getrecast.com/docs/the-forecaster-api
- Spend Forecasting API: https://docs.getrecast.com/docs/spend-forecasting-api
- Helper endpoints: https://docs.getrecast.com/docs/helper-endpoints
- Insights API: https://docs.getrecast.com/docs/the-insights-api
- API FAQ: https://docs.getrecast.com/docs/api-faq
- Client-facing API reference: https://app.getrecast.com/api-docs/index.html

## Base URL

Default: `https://api.getrecast.com/v1`. Override via `RECAST_API_BASE`.

## Endpoints

### 1. `GET /clients/{client_slug}/kpis`

Resolves the KPI name to a deployment_id.

### 2. `GET /clients/{client_slug}/deployments/{deployment_id}?extra_fields=spend_channels_labels`

Returns the model end date (`end_date` in the current API; older responses use `model_date` or `model_end_date` — `build.py` tries all three) and channel labels.

### 3. `POST /clients/{client_slug}/reports` firing `compute_insights_overview`

```json
{
  "form": {
    "report_type": "compute_insights_overview",
    "deployment_id": <id>,
    "start_date": "<YYYY-MM-DD>",
    "end_date": "<YYYY-MM-DD>"
  },
  "show_in_ui": false
}
```

When the report succeeds, the completed report includes `results.downloads[]`.
The bundle downloads the overview CSVs and reads per-channel spend, impact, and
uncertainty bounds from `summaries-total-roi.csv`,
`summaries-direct-mroi.csv`, and `summaries-direct-impact_shifted.csv`.

### 4. `GET /clients/{client_slug}/reports/{report_id}` — polls until completion.

### 5. `GET /clients/{client_slug}/reports/{report_id}/downloads/{download_key}` — downloads the CSVs listed in `results.downloads[]`.

## Errors

Standard HTTP. 401 = bad token, 403 = no access, 404 = bad slug/KPI, 422 = bad params, 5xx = retry.

## Local CSV

This bundle also optionally reads `experiments.csv` (no API). Path configured via `config.experiments_csv`.
