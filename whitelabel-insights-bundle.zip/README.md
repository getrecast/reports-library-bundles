# Whitelabeled Recast Insights — Recast Reports Library

A full Recast Insights dashboard, white-labeled for your brand. Channels, KPI, ROI, saturation curves, baseline, spikes, context variables, backtests, experiments — all powered by your live Recast model. Host it on your internal stack, share with stakeholders, or use as a reference for a deeper custom build.

**Live preview:** [https://research.getrecast.com/report-template-library/whitelabel-insights/](https://research.getrecast.com/report-template-library/whitelabel-insights/)

## What it does

For your Recast model + chosen KPI:

1. Fires ~14 API reports in parallel (overview at 4 time windows, share of spend vs effect, marketing vs baseline, lower funnel waterfall, spend summary, response curves, shift curves, spike detail, context summary, backtests, and per-channel weekly summaries)
2. Pulls the resulting CSVs and parses them into a single JSON blob
3. Applies your brand colors and logo
4. Inlines everything into the template and outputs a single self-contained HTML file

The output is significantly more complete than any of the smaller reports in this library — it's a near-replica of Recast's Insights view.

## Prerequisites

- Recast API access + token (see [INSTALL.md](INSTALL.md))
- Python 3.10+ (stdlib only)
- A logo SVG for your brand (optional but recommended)

## Quick start

`.env` holds `API_PAT`; `my-config.json` holds `client_slug` and report settings.

```bash
cp .env.example .env
# Edit .env and paste your token.
# Edit .env: API_PAT=gr_your_token

cp config.example.json my-config.json
# Edit my-config.json: client_slug, kpi_name, brand colors, logo path, user name

python3 build.py my-config.json --check
python3 build.py my-config.json
# → outputs whitelabel-insights.html
```

The `--check` preflight is read-only — it confirms your token works, your KPI name resolves, and the API
returns the shapes this bundle expects, with a plain-language error if anything
is off. It never prints your token. If the build later fails with a 422
mentioning `report_type`, run the report once from the Recast UI first (see
`INSTALL.md`).

Build time: ~7-12 minutes for the first run (the API needs time to compute all 14 reports). Re-runs use cached data in `./data/` and are nearly instant — pass `--rebuild` to force a fresh API pull.

## What's in this bundle

| File | Purpose |
|---|---|
| `README.md` | This file. |
| `INSTALL.md` | Setup + API key safety. |
| `build.py` | Stdlib Python. Fires all reports in parallel, polls, parses, fills the template. |
| `template.html` | The dashboard template (~145 KB) with `{{PLACEHOLDER}}` tokens. |
| `config.example.json` | Generic config template. |
| `.env.example` | Generic env template. |
| `.gitignore` | Blocks `.env`, configs, generated output. |
| `docs/api-reference.md` | Full list of API endpoints used. |
| `docs/customize.md` | How to tweak layout, drop sections, restyle. |
| `docs/SKILL.md` | Canonical agent entrypoint for guided builds. |

## What this bundle does NOT include

- Plans / Forecaster / Optimizer / Reporter / Refresh Tracker tabs (Insights-only)
- Data Concerns + Configuration tabs (internal-only views)
- Optional API sections that return no data are visibly marked unavailable in the output
- Baseline values are sourced from API-backed reports when available; if not, the output marks the section unavailable
- Authentication on the output HTML (host it where you control access)

## Going further

This bundle is open source. Fork it, modify it, extend it. If you build something useful, [submit it back](https://research.getrecast.com/report-template-library/).

## Support

Bundle issues: [recast-research-pages issues](https://github.com/getrecast/recast-research-pages/issues).
Recast API issues: contact your account team.
