# Install & API Key Safety

## Prerequisites

- Python 3.10+ (check with `python3 --version`)
- A Recast API token. Generate one in the Recast app: click your email (top right) → **Generate API token**
- A logo SVG for your brand (or skip and run without)

No `pip install` step. Stdlib only.

## Setup

### 1. Get the bundle

```bash
unzip whitelabel-insights-bundle.zip
cd whitelabel-insights-bundle
```

### Optional: make the agent skill available

This bundle includes `docs/SKILL.md`, an optional agent guide for Claude Code, Codex, or another AI coding assistant. You do not need to install it to run the report; `python3 build.py my-config.json` is the primary interface.

If your assistant supports local skills, add `docs/SKILL.md` to its configured skills folder or point the assistant at this file before asking it to run or customize the bundle. The skill tells the assistant to keep your token in `.env`, run `--check` before the full build, and stay scoped to this bundle directory.

### 2. Put your API token in `.env`

```bash
cp .env.example .env
# Edit .env and replace `gr_replace_with_your_token` with your real token.
```

`.env` is git-ignored by default. Never commit it.

Keep token and slug separate: `.env` holds `API_PAT`; `my-config.json` holds `client_slug` and report settings.

### 3. Configure for your model + brand

```bash
cp config.example.json my-config.json
# Edit my-config.json:
#   - "client_slug" → the Recast URL path between `/clients/` and `/dashboards/`
#   - "kpi_name" → the KPI you want this dashboard for
#   - "brand" → name, tagline, primary hex color, accent hex color, logo path
#   - "user" → display name + initials for the user pill
```

### 4. Run

```bash
python3 build.py my-config.json
```

First build takes 7-12 minutes (firing 14 API reports in parallel). Outputs `whitelabel-insights.html` (~550 KB to 1 MB depending on data volume).

## API token safety — read this

**Do:**
- Store the token in `.env`. The included `.gitignore` blocks it.
- Use your own personal token. Don't share tokens between teammates.
- Regenerate immediately if your token ends up in chat, Slack, email, or a screen share.

**Don't:**
- Commit the token to git. (The `.gitignore` is a safety net, not a substitute for not pasting it anywhere.)
- Hardcode the token into `config.json` or `build.py`.
- Paste the raw token into any chat tool (Claude Code, ChatGPT, etc.) — see below.
- Add `export API_PAT=...` permanently to `~/.zshrc` or `~/.bashrc`.

**If exposed:**
- Regenerate in the Recast app immediately (this invalidates the old token).
- The token has full access to whatever data your user account can see.

## Working with AI assistants (Claude Code, etc.)

If you want to use Claude Code or another AI assistant to help customize this bundle:

1. **Never paste your token into the chat.** Put it in `.env` and tell the assistant: "Use the token in `.env`. Don't read it back to me."
2. `build.py` loads `.env` automatically — the assistant doesn't need to see the token to run.
3. If the assistant suggests editing a tracked file to include the token, decline.

For optional local agent skill setup, see "Optional: make the agent skill available" above.

## First-time setup: activate the report type

The Recast API currently requires each report type to have been run at least once
from the Recast UI before it can be created via the API. On a client account that
has never used this report, `build.py` fails with a 422 error mentioning
`report_type`. Fix: open the Recast app, run each report type this bundle uses (at minimum Insights Overview, Marketing vs. Baseline, and Spend Response Curves) once from
the UI, then re-run `build.py`.

## Troubleshooting

| Symptom | Likely cause | Fix |
|---|---|---|
| `API_PAT not set` | `.env` missing or token field empty | Confirm `.env` exists, has `API_PAT=gr_...`, no quotes |
| `KPI '...' not found` | KPI name doesn't match what's in your model | Check exact spelling in the Recast app. Case-sensitive. |
| `KPI '...' has no depvars` | The model has no active deployment for that KPI | Confirm the model is active in the Recast app |
| `report_type is not a supported report_type` (422) | This report type has never been run for your client | Run each report type this bundle uses (at minimum Insights Overview, Marketing vs. Baseline, and Spend Response Curves) once from the Recast UI, then re-run `build.py` |
| `401 Unauthorized` | Token rejected | Regenerate the token. Update `.env`. |
| Output says optional data is unavailable | The API did not return that optional section for this deployment | Keep the visible notice or remove that optional section from the template. Required data failures still block the build. |
| `Channels changed since the report was run` (shift_curves) | Lower funnel channels rejected | Already handled — sends only upper_funnel channels |
| `start_date can't be before 2024-04-08` | History start before allowed range | Already handled — automatically clipped |
| Logo huge on output | SVG had hardcoded `width=`/`height=` | `build.py` strips these. Re-run if you see it on stale output. |
| Output opens blank | JSON parse error from corrupted CSV | Delete `./data/` and re-run with `--rebuild` |

## How long does it take?

- API discovery: ~2 seconds
- Firing 14 reports in parallel: ~5-10 minutes (longest report ~6 minutes)
- Downloading + parsing CSVs: ~10 seconds
- Building the HTML: ~3 seconds
- **Total first run: ~7-12 minutes**

Re-runs use cached CSVs in `./data/`. Nearly instant. Pass `--rebuild` to force a fresh API pull.

## Sharing the output

`whitelabel-insights.html` is a single self-contained file. Open in any browser, no server needed.

Distribute via:
- Slack DM / email attachment (file is ~550 KB to 1 MB)
- Upload to your own static hosting (S3, Cloudflare Pages, Netlify, etc.)
- Inline preview in a deck or Loom

Recipients don't need anything installed.
