#!/usr/bin/env python3
"""
Recast white-label dashboard builder.

Usage:
    export API_PAT=gr_your_token_here
    python3 build.py config.json

Reads a client config, fires all required Recast API reports, downloads CSVs,
parses them into REAL_DATA JSON, inlines it into template.html, applies brand
styling, and writes dashboard.html.

Requires: Python 3.10+, no external deps.
"""
from __future__ import annotations
import csv, io, json, os, re, sys, time, urllib.request, urllib.error
from datetime import datetime, timedelta
from pathlib import Path


def import_shared_runner():
    here = Path(__file__).parent.resolve()
    for candidate in (here / "_shared", here.parent / "_shared"):
        if candidate.exists():
            sys.path.insert(0, str(candidate))
            import recast_runner
            return recast_runner
    print("[BLOCK] Shared runner is missing -> Re-download the bundle or run the package script before distributing", file=sys.stderr)
    sys.exit(1)


rr = import_shared_runner()
rr.require_python_version((3, 10))

BASE = "https://api.getrecast.com"
RATE_LIMIT_SLEEP = 0.25  # seconds between report creates
POLL_INTERVAL = 15
POLL_TIMEOUT = 1200
REQUIRED_REPORTS = {
    "overview_7d",
    "overview_30d",
    "overview_90d",
    "overview_365d",
    "marketing_vs_baseline_7d",
    "marketing_vs_baseline_full",
    "spend_summary_full",
    "spend_response_curves",
    "grouped_weekly",
}
PROBE_REPORT_TYPES = [
    "compute_insights_overview",
    "compute_marketing_vs_baseline",
    "compute_spend_summary",
    "compute_spend_response_curves",
    "compute_grouped_channel_summaries",
]

# Default channel color palette — distinguishable on dark bg. Cycles if > 9 channels.
CHANNEL_COLOR_PALETTE = [
    "#5B8BFF", "#2DD4BF", "#7DD3FC", "#9D8FFF", "#C084FC",
    "#FB923C", "#FB7185", "#34D399", "#FBBF24",
]


def http(pat, method, path, body=None, accept="application/json"):
    url = f"{BASE}{path}"
    headers = {"Authorization": f"Bearer {pat}", "Accept": accept}
    data = None
    if body is not None:
        data = json.dumps(body).encode()
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=120) as r:
            raw = r.read()
            return r.status, (json.loads(raw.decode()) if accept == "application/json" else raw)
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode(errors="ignore")
    except urllib.error.URLError as e:
        rr.block(
            f"API {method} {path} could not connect: {e.reason}",
            "Confirm network access and RECAST_API_BASE, then rerun",
        )


def days_back(end_date: str, n: int) -> str:
    end = datetime.strptime(end_date, "%Y-%m-%d")
    return (end - timedelta(days=n - 1)).strftime("%Y-%m-%d")


def clamp_history_start(hist_start: str, meta: dict) -> str:
    floor = meta.get("start_date")
    if not floor:
        return hist_start
    return max(
        datetime.strptime(hist_start, "%Y-%m-%d"),
        datetime.strptime(floor, "%Y-%m-%d"),
    ).strftime("%Y-%m-%d")


# ----------------------------------------------------------------------
# API DISCOVERY
# ----------------------------------------------------------------------

def discover(pat: str, slug: str, kpi_name: str, hist_start: str) -> dict:
    """Find KPI + deployment + channels. Returns {kpi_id, deployment_id, channels, lower_funnel, model_date}."""
    status, data = http(pat, "GET", f"/v1/clients/{slug}/kpis")
    if status != 200:
        rr.block(f"GET /kpis failed: {status} {data}", "Confirm the token and client slug, then rerun")
    kpi = next((k for k in data["data"] if k["name"] == kpi_name), None)
    if not kpi:
        names = [k["name"] for k in data["data"]]
        suggestion = rr.suggest_available_name(kpi_name, names)
        fix = f"Use the exact KPI name from Recast. Available: {names}"
        if suggestion:
            fix = f"Did you mean '{suggestion}'? {fix}"
        rr.block(f"KPI '{kpi_name}' not found", fix)
    kpi_id = kpi["id"]
    status, kdata = http(pat, "GET", f"/v1/clients/{slug}/kpis/{kpi_id}")
    if status != 200:
        rr.block(f"GET /kpis/{kpi_id} failed: {status} {kdata}", "Confirm the KPI is available to this token")
    # Legacy API shape: depvar_configurations[].deployment_id
    deps = kdata.get("depvar_configurations") or []
    if len(deps) > 1:
        rr.block(
            f"KPI '{kpi_name}' is a multi-depvar KPI",
            "Choose a single-depvar KPI; aggregate multi-depvar KPIs are not supported by this bundle yet",
        )
    if deps:
        deployment_id = deps[0]["deployment_id"]
    else:
        # Current API shape: depvars[].slug — resolve the active deployment by slug
        depvars = kdata.get("depvars") or kpi.get("depvars") or []
        if len(depvars) > 1:
            rr.block(
                f"KPI '{kpi_name}' is a multi-depvar KPI",
                "Choose a single-depvar KPI; aggregate multi-depvar KPIs are not supported by this bundle yet",
            )
        if not depvars:
            rr.block(f"KPI '{kpi_name}' has no depvars", "Confirm the model is active in Recast")
        depvar_slug = depvars[0]["slug"]
        status, all_deps = http(pat, "GET", f"/v1/clients/{slug}/deployments")
        if status != 200:
            rr.block(f"GET /deployments failed: {status} {all_deps}", "Confirm the token can read deployments")
        dep_items = all_deps if isinstance(all_deps, list) else all_deps.get("data") or all_deps.get("deployments") or []
        deployment_id = None
        for d in dep_items:
            status, full = http(pat, "GET", f"/v1/clients/{slug}/deployments/{d['id']}")
            if full.get("dashboard_slug") == depvar_slug and full.get("active"):
                deployment_id = full["id"]
                break
        if deployment_id is None:
            rr.block(f"KPI '{kpi_name}' has no active deployment", "Confirm the model is active in Recast")
    status, ddata = http(
        pat, "GET",
        f"/v1/clients/{slug}/deployments/{deployment_id}"
        f"?extra_fields=spend_channels_labels,upper_funnel_channel_labels,lower_funnel_channel_labels,contextual_variable_defaults"
    )
    if status != 200:
        rr.block(f"GET /deployments/{deployment_id} failed: {status} {ddata}", "Confirm the deployment is active")
    channels = ddata.get("spend_channels_labels", [])
    lower = ddata.get("lower_funnel_channel_labels", [])
    upper = [c for c in channels if c not in lower]
    model_date = ddata.get("model_date") or ddata.get("end_date") or ""
    return {
        "kpi_id": kpi_id,
        "deployment_id": deployment_id,
        "channels": channels,
        "upper_funnel": upper,
        "lower_funnel": lower,
        "model_date": model_date,
        "start_date": ddata.get("start_date") or ddata.get("history_start") or ddata.get("model_start_date"),
        "context_vars": ddata.get("contextual_variable_defaults", {}),
    }


# ----------------------------------------------------------------------
# REPORT FIRING + POLLING
# ----------------------------------------------------------------------

def build_report_specs(meta: dict, hist_start: str) -> dict:
    end = meta["model_date"]
    hist_start = clamp_history_start(hist_start, meta)
    channels = meta["channels"]
    upper = meta["upper_funnel"]
    specs = {
        "overview_7d": {"report_type": "compute_insights_overview", "start_date": days_back(end, 7), "end_date": end},
        "overview_30d": {"report_type": "compute_insights_overview", "start_date": days_back(end, 30), "end_date": end},
        "overview_90d": {"report_type": "compute_insights_overview", "start_date": days_back(end, 90), "end_date": end},
        "overview_365d": {"report_type": "compute_insights_overview", "start_date": days_back(end, 365), "end_date": end},
        "marketing_vs_baseline_7d": {"report_type": "compute_marketing_vs_baseline", "start_date": days_back(end, 7), "end_date": end},
        "marketing_vs_baseline_full": {"report_type": "compute_marketing_vs_baseline", "start_date": hist_start, "end_date": end},
        "spend_summary_full": {"report_type": "compute_spend_summary", "start_date": hist_start, "end_date": end},
        "spend_response_curves": {"report_type": "compute_spend_response_curves", "date": end, "num_days": 7, "channels": channels},
        "spike_detail": {"report_type": "compute_spike_detail_summary"},
        "context_summary": {"report_type": "compute_context_variable_summary", "start_date": hist_start, "end_date": end},
        "backtests": {"report_type": "compute_backtest_summaries"},
        "grouped_weekly": {
            "report_type": "compute_grouped_channel_summaries",
            "start_date": hist_start, "end_date": end,
            "channel_groups": [{"name": ch, "channels": [ch]} for ch in channels],
            "include_lower_funnel_effects": "false",
        },
    }
    if meta.get("lower_funnel"):
        specs["lower_funnel_waterfall_7d"] = {"report_type": "compute_lower_funnel_waterfall", "start_date": days_back(end, 7), "end_date": end}
    if upper:
        specs["shift_curves"] = {"report_type": "compare_shift_curves", "channels": upper}
    return specs


def fire_reports(
    pat: str,
    slug: str,
    deployment_id: int,
    specs: dict,
    data_dir: Path,
    config: dict | None = None,
    cache_key: str | None = None,
    output_path: str | None = None,
) -> dict:
    """Create all reports, poll until done, download CSVs. Returns manifest."""
    data_dir.mkdir(parents=True, exist_ok=True)
    print(f"Firing {len(specs)} reports for client `{slug}`...")
    ids = {}
    config = config or {}
    manifest = {
        "_meta": {
            "manifest_version": rr.MANIFEST_VERSION,
            "bundle_slug": "whitelabel-insights",
            "cache_key": cache_key,
            "output_path": output_path,
            "config_identity": {
                "client_slug": config.get("client_slug"),
                "kpi_name": config.get("kpi_name"),
                "brand_name": (config.get("brand") or {}).get("name"),
            },
            "deployment_id": str(deployment_id),
        }
    }
    optional_unavailable = {}
    for name, form in specs.items():
        payload = {
            "name": f"whitelabel-build {name}",
            "show_in_ui": False,
            "form": {**form, "deployment_id": deployment_id},
        }
        status, body = http(pat, "POST", f"/v1/clients/{slug}/reports", payload)
        if status != 201:
            if name in REQUIRED_REPORTS:
                rr.block(f"Required report '{name}' failed to start: {body}", "Run this report type once in the Recast UI, then rerun with --rebuild")
            optional_unavailable[name] = str(body)
            manifest[name] = {
                "status": "unavailable",
                "reason": str(body),
                "required": False,
                "form": payload["form"],
                "downloads": {},
                "highlights": {},
            }
            print(f"  [OPTIONAL UNAVAILABLE] {name}: {body}", file=sys.stderr)
            continue
        rid = body.get("id")
        ids[name] = rid
        print(f"  [QUEUED] {name} -> id={rid}")
        time.sleep(RATE_LIMIT_SLEEP)

    print(f"\nWaiting on {len(ids)} reports...")
    pending = dict(ids)
    completed = {}
    failed = {}
    t0 = time.time()
    while pending:
        time.sleep(POLL_INTERVAL)
        elapsed = int(time.time() - t0)
        done = []
        for name, rid in list(pending.items()):
            s, body = http(pat, "GET", f"/v1/clients/{slug}/reports/{rid}")
            if s != 200 or body.get("status") in ("ready", "processing"):
                continue
            if body.get("status") == "success":
                completed[name] = body
                done.append(name)
                print(f"  [{elapsed}s DONE] {name}")
            else:
                failed[name] = body.get("status", "unknown")
                done.append(name)
                if name in REQUIRED_REPORTS:
                    rr.block(f"Required report '{name}' failed while polling: {body.get('status')}", "Run this report type once in the Recast UI, then rerun with --rebuild")
                manifest[name] = {
                    "status": "unavailable",
                    "reason": body.get("status", "unknown"),
                    "required": False,
                    "form": body.get("form"),
                    "downloads": {},
                    "highlights": {},
                }
                print(f"  [{elapsed}s OPTIONAL UNAVAILABLE] {name} -> {body.get('status')}")
        for n in done:
            del pending[n]
        if pending and elapsed > POLL_TIMEOUT:
            required_pending = [name for name in pending if name in REQUIRED_REPORTS]
            if required_pending:
                rr.block(f"Required reports timed out: {required_pending}", "Rerun the build; if it repeats, contact Recast support")
            for name in list(pending):
                manifest[name] = {
                    "status": "unavailable",
                    "reason": "timeout",
                    "required": False,
                    "form": specs.get(name),
                    "downloads": {},
                    "highlights": {},
                }
            print(f"  [TIMEOUT] optional reports unavailable: {list(pending.keys())}", file=sys.stderr)
            break

    print(f"\nDownloading CSVs...")
    for name, body in completed.items():
        rdir = data_dir / name
        rdir.mkdir(parents=True, exist_ok=True)
        results = (body.get("results") or {})
        dls = results.get("downloads") or []
        manifest[name] = {
            "status": "success",
            "report_id": ids[name],
            "form": body.get("form"),
            "downloads": {},
            "highlights": results.get("highlights"),
        }
        for d in dls:
            key = d.get("key")
            if not key:
                continue
            s, raw = http(pat, "GET", f"/v1/clients/{slug}/reports/{ids[name]}/downloads/{key}", accept="text/csv")
            if s == 200:
                text = raw.decode() if isinstance(raw, bytes) else raw
                (rdir / f"{key}.csv").write_text(text)
                manifest[name]["downloads"][key] = {
                    "path": f"{name}/{key}.csv",
                    "row_count": len(list(csv.DictReader(io.StringIO(text)))),
                }
        print(f"  [{name}] {len(manifest[name]['downloads'])} files")

    (data_dir / "manifest.json").write_text(json.dumps(manifest, indent=2, default=str))
    if failed or optional_unavailable:
        print(f"\nOptional reports unavailable: {sorted(set(failed) | set(optional_unavailable))}")
    return manifest


# ----------------------------------------------------------------------
# CSV → REAL_DATA SHAPE
# ----------------------------------------------------------------------

def read_csv(p: Path):
    if not p.exists():
        return []
    with open(p) as f:
        return list(csv.DictReader(f))


def num(s, default=0):
    if s is None or s == "" or s == "NA" or s == "NaN":
        return default
    try:
        return float(s)
    except ValueError:
        return default


def build_real_data(meta: dict, data_dir: Path, kpi_name: str) -> dict:
    manifest = json.loads((data_dir / "manifest.json").read_text())
    channels = meta["channels"]
    lower = meta["lower_funnel"]
    channel_label_map = {c: c + (" ▼" if c in lower else "") for c in channels}

    # Channel colors from palette
    color_map = {ch: CHANNEL_COLOR_PALETTE[i % len(CHANNEL_COLOR_PALETTE)] for i, ch in enumerate(channels)}
    color_map["overall"] = "#E8E9EE"

    out = {"kpi_name": kpi_name, "model_date": meta["model_date"]}
    out["availability"] = {
        name: {
            "status": report.get("status", "success"),
            "reason": report.get("reason", ""),
        }
        for name, report in manifest.items()
        if name != "_meta" and report.get("status") == "unavailable"
    }

    # ---- Overview highlights ----
    overviews = {}
    for key in ["overview_7d", "overview_30d", "overview_90d", "overview_365d"]:
        overviews[key] = (manifest.get(key, {}) or {}).get("highlights") or {}
    out["overviews"] = overviews

    # ---- Per-period summaries ----
    summaries = {}
    for key in ["overview_7d", "overview_30d", "overview_90d", "overview_365d"]:
        rdir = data_dir / key
        summaries[key] = {
            "total_roi": read_csv(rdir / "summaries-total-roi.csv"),
            "direct_mroi": read_csv(rdir / "summaries-direct-mroi.csv"),
            "direct_impact_shifted": read_csv(rdir / "summaries-direct-impact_shifted.csv"),
        }
    out["summaries"] = summaries

    # ---- Channel list ----
    out["channels"] = [{"key": "overall", "label": "overall", "color": color_map["overall"]}]
    for ch in channels:
        out["channels"].append({"key": ch, "label": channel_label_map[ch], "color": color_map[ch]})

    # ---- Weekly + Monthly history ----
    weekly = read_csv(data_dir / "spend_summary_full" / "tables-weekly.csv")
    out["weekly"] = [
        {
            "date": r["start_date"],
            "total": num(r["total"]),
            "kpi": num(r.get(kpi_name.lower().replace(" ", "_")) or r.get("kpi") or r.get("value")),
            "roi": num(r.get("roi")),
            "blended_roi": num(r.get("blended_roi")),
            "spends": {ch: num(r.get(ch)) for ch in channels},
        }
        for r in weekly
    ]
    monthly = read_csv(data_dir / "spend_summary_full" / "tables-monthly.csv")
    out["monthly"] = [
        {
            "date": f"{r['year']}-{int(num(r['month'])):02d}-01",
            "total": num(r["total"]),
            "kpi": num(r.get(kpi_name.lower().replace(" ", "_")) or r.get("kpi") or r.get("value")),
            "roi": num(r.get("roi")),
            "blended_roi": num(r.get("blended_roi")),
            "spends": {ch: num(r.get(ch)) for ch in channels},
        }
        for r in monthly
    ]

    # ---- Saturation curves ----
    sat = read_csv(data_dir / "spend_response_curves" / "multi_day-multi_channel-tables-full_table.csv")
    sat_by_ch = {}
    for r in sat:
        ch = r["channel"]
        sat_by_ch.setdefault(ch, []).append({
            "spend": num(r["spend"]),
            "impact_total": num(r["total_mean"]),
            "impact_direct": num(r["direct_mean"]),
            "roi_total": num(r["roi_total_mean"]),
            "roi_direct": num(r["roi_direct_mean"]),
        })
    out["saturation"] = sat_by_ch

    # ---- Shift curves ----
    shifts = read_csv(data_dir / "shift_curves" / "all_shift_curves_summarized.csv")
    shift_by_ch = {}
    for r in shifts:
        shift_by_ch.setdefault(r["channel"], []).append({
            "day": int(num(r["days"])),
            "pct": num(r["mean"]),
            "lo": num(r.get("25%")),
            "hi": num(r.get("75%")),
        })
    out["shift_curves"] = shift_by_ch

    # ---- Lower funnel ----
    lf_key = lower[0] if lower else None
    if lf_key:
        lf = read_csv(data_dir / "lower_funnel_waterfall_7d" / f"channel_summaries-{lf_key}-summary_table.csv")
        out["lower_funnel"] = [
            {"channel": r["channel"], "spend_driven": num(r.get("spend_driven")), "effect_driven": num(r.get("effect_driven_mean"))}
            for r in lf
        ]
    else:
        out["lower_funnel"] = []

    # ---- Spikes ----
    sp = read_csv(data_dir / "spike_detail" / "individual_cumulative_effects_summarized.csv")
    out["spikes"] = [
        {"name": r.get("spike_name"), "date": r.get("spike_date"),
         "mean": num(r["mean"]), "p025": num(r.get("2.5%")), "p25": num(r.get("25%")),
         "p50": num(r.get("50%")), "p75": num(r.get("75%")), "p975": num(r.get("97.5%"))}
        for r in sp
    ]
    daily = read_csv(data_dir / "spike_detail" / "individual_daily_effects.csv")
    out["spikes_daily"] = [
        {"name": r["spike_name"], "spike_date": r["spike_date"], "date": r["date"], "mean": num(r["mean"])}
        for r in daily
    ]
    grouped = read_csv(data_dir / "spike_detail" / "grouped_cumulative_effects_summarized.csv")
    out["spikes_grouped"] = [
        {"name": r.get("spike_name"), "mean": num(r["mean"]),
         "p025": num(r.get("2.5%")), "p25": num(r.get("25%")), "p50": num(r.get("50%")),
         "p75": num(r.get("75%")), "p975": num(r.get("97.5%"))}
        for r in grouped
    ]

    # ---- Context ----
    ctx_h = (manifest.get("context_summary", {}) or {}).get("highlights", {}) or {}
    out["context"] = ctx_h.get("context_variables", [])

    # ---- Backtests ----
    bt_h = (manifest.get("backtests", {}) or {}).get("highlights", {}) or {}
    out["backtest_summary"] = bt_h.get("holdout", [])
    out["experiments"] = []
    out["availability"].setdefault(
        "experiments",
        {"status": "unavailable", "reason": "No experiments CSV or API experiment data was provided"},
    )

    # ---- Per-channel weekly time series ----
    gw_dir = data_dir / "grouped_weekly"
    channel_series = {}
    for ch in channels:
        ch_data = {}
        for metric in ["roi", "mroi", "impact", "impact_shifted"]:
            rows = read_csv(gw_dir / f"group_summaries-{ch}-{metric}-summary_weekly.csv")
            ch_data[metric] = [
                {"date": r.get("start_date"), "mean": num(r.get(f"{metric}_mean")),
                 "p25": num(r.get(f"{metric}_p25")), "p75": num(r.get(f"{metric}_p75")),
                 "spend": num(r.get("spend"))}
                for r in rows if r.get(f"{metric}_mean") not in (None, "", "NaN", "NA")
            ]
        channel_series[ch] = ch_data
    out["channel_series"] = channel_series

    # ---- Over/under (computed from 7d impact + spend) ----
    impact_rows = summaries["overview_7d"]["direct_impact_shifted"]
    spend_total = sum(num(r.get("spend")) for r in impact_rows if r["channel"] != "overall")
    impact_total = sum(num(r.get("mean")) for r in impact_rows if r["channel"] != "overall")
    ou = []
    for r in impact_rows:
        if r["channel"] == "overall":
            continue
        share_eff = num(r["mean"]) / impact_total if impact_total else 0
        share_sp = num(r.get("spend")) / spend_total if spend_total else 0
        ou.append({"ch": r["channel"], "color": color_map.get(r["channel"], "#9D8FFF"), "pct": (share_eff - share_sp) * 100})
    out["over_under"] = sorted(ou, key=lambda x: -x["pct"])

    # ---- Waterfall ----
    overview7 = overviews.get("overview_7d") or {}
    cur = overview7.get("current_period", {}) or {}
    baseline_outcome = ((cur.get("outcome") or {}).get("baseline") or {}).get("point_estimate", 0)
    if not baseline_outcome:
        mvb = ((manifest.get("marketing_vs_baseline_7d", {}) or {}).get("highlights") or {})
        mvb_cur = mvb.get("current_period", {}) or {}
        baseline_outcome = ((mvb_cur.get("outcome") or {}).get("baseline") or {}).get("point_estimate", 0)
    if not baseline_outcome:
        out["availability"]["baseline"] = {"status": "unavailable", "reason": "baseline not returned by API-backed reports"}
    total_outcome = (cur.get("outcome") or {}).get("total", 0)
    paid_rows = [r for r in impact_rows if r["channel"] != "overall"]
    paid_rows.sort(key=lambda r: -num(r["mean"]))
    waterfall = [{"label": "Baseline", "value": baseline_outcome, "color": "#2B2F3B"}]
    for r in paid_rows[:6]:
        waterfall.append({"label": r["channel"], "value": num(r["mean"]), "color": color_map.get(r["channel"], "#9D8FFF")})
    other_sum = sum(num(r["mean"]) for r in paid_rows[6:])
    waterfall.append({"label": "Other", "value": other_sum, "color": "#6E7281"})
    sum_so_far = sum(w["value"] for w in waterfall)
    waterfall.append({"label": "Unexplained Variation", "value": total_outcome - sum_so_far, "color": "#22252E"})
    out["waterfall"] = waterfall

    return out


# ----------------------------------------------------------------------
# TEMPLATE FILL + WRITE
# ----------------------------------------------------------------------

def hex_to_rgba(hex_str: str, alpha: float) -> str:
    h = hex_str.lstrip("#")
    r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    return f"rgba({r},{g},{b},{alpha})"


def derive_palette(primary: str, accent: str | None) -> dict:
    return {
        "violet": accent or primary,
        "violet_deep": primary,
        "violet_bg": hex_to_rgba(accent or primary, 0.10),
        "violet_bg_strong": hex_to_rgba(accent or primary, 0.18),
    }


def sanitize_user_template(html: str) -> str:
    def replace_between(source: str, start: str, end: str, replacement: str) -> str:
        start_idx = source.find(start)
        end_idx = source.find(end, start_idx + len(start)) if start_idx != -1 else -1
        if start_idx == -1 or end_idx == -1:
            return source
        return source[:start_idx] + replacement + source[end_idx:]

    unavailable_js = """
function renderUnavailableElement(id, message) {
  const node = document.getElementById(id);
  if (!node) return;
  node.outerHTML = `<div id="${id}" class="data-unavailable" data-unavailable><strong>Data unavailable</strong><span>${message}</span></div>`;
}
"""
    if ".data-unavailable" not in html:
        html = html.replace(
            "</style>",
            ".data-unavailable{display:flex;min-height:220px;align-items:center;justify-content:center;flex-direction:column;gap:8px;border:1px dashed rgba(255,255,255,.18);border-radius:8px;background:rgba(255,255,255,.03);color:#B4B7C4;font:14px system-ui,sans-serif;text-align:center;padding:24px}.data-unavailable strong{color:#E8E9EE;font-size:15px}.data-unavailable span{max-width:560px}</style>",
            1,
        )
    html = html.replace(
        "This table shows all experiments that are actively calibrating {{BRAND_NAME}}. The main rows are the results of your lift tests, including point estimates and standard errors.",
        "This table shows configured experiment results when an experiments CSV or API experiment data is available.",
    )
    for name in [
        "CHANNELS",
        "OVER",
        "UNDER",
        "WATERFALL",
        "SATURATION",
        "TIMESHIFT",
        "LF_WATERFALL",
        "SPIKES",
        "CONTEXT_VARS",
    ]:
        html = re.sub(
            rf"let\s+{name}\s*=\s*\[[\s\S]*?\n\s*\];",
            f"let {name} = Array.from([]);",
            html,
            count=1,
        )
    html = re.sub(
        r"const\s+EXPERIMENTS\s*=\s*\[[\s\S]*?\];",
        "const EXPERIMENTS = (window.REAL_DATA.experiments || []);",
        html,
        count=1,
    )
    html = re.sub(
        r"(?:let|const)\s+CHANNEL_DETAIL\s*=\s*\{[\s\S]*?\n\};",
        "let CHANNEL_DETAIL = (window.REAL_DATA.channel_detail || {});",
        html,
        count=1,
    )
    html = re.sub(
        r"(?:let|const)\s+CHANNEL_DETAIL\s*=\s*\{[^;]*\};",
        "let CHANNEL_DETAIL = (window.REAL_DATA.channel_detail || {});",
        html,
        count=1,
    )
    html = re.sub(r"^\s*//.*mock.*$", "", html, flags=re.MULTILINE | re.IGNORECASE)
    html = html.replace("Keep Hill stub for fallback dot calculation", "Use real curve points when available")
    html = html.replace("7d only — keep YoY/WoW mock for now", "7d only")
    html = replace_between(
        html,
        "function seedWeekly()",
        "function renderWeeklySpendKpi()",
        """
function seedWeekly() {
  return (WEEKLY_REAL || []).map(d => ({
    t: d.date ? new Date(d.date).getTime() : d.t,
    total: d.total,
    kpi: d.kpi,
    spends: d.spends || {},
    roi: d.roi,
    blended_roi: d.blended_roi,
  }));
}
let WEEKLY = seedWeekly();

""",
    )
    html = replace_between(
        html,
        "function renderBaselineSummary(",
        "// ============================================================\n// SPIKES",
        unavailable_js + """
function renderBaselineSummary(elId, withSpikes) {
  renderUnavailableElement(elId, "API-backed baseline time series were not returned for this build.");
}

// ============================================================
// SPIKES
""",
    )
    html = replace_between(
        html,
        "function renderContextEffectTime()",
        "// ============================================================\n// BACKTESTS",
        """
function renderContextEffectTime() {
  renderUnavailableElement("context-effect-time", "API-backed context-variable time series were not returned for this build.");
}

// ============================================================
// BACKTESTS
""",
    )
    html = replace_between(
        html,
        "function renderBacktests()",
        "// ============================================================\n// PRIOR VS POSTERIOR",
        """
function renderBacktests() {
  renderUnavailableElement("bt-daily", "API-backed daily backtest series were not returned for this build.");
  renderUnavailableElement("bt-cumulative", "API-backed cumulative backtest series were not returned for this build.");
  renderUnavailableElement("bt-changes", "API-backed prediction-revision data were not returned for this build.");
}

// ============================================================
// PRIOR VS POSTERIOR
""",
    )
    html = replace_between(
        html,
        "function renderPVP()",
        "// ============================================================\n// EXPERIMENTS",
        """
function renderPVP() {
  renderUnavailableElement("pvp-shifts", "API-backed prior-vs-posterior shift ranges were not returned for this build.");
  renderUnavailableElement("pvp-baseline", "API-backed prior-vs-posterior baseline series were not returned for this build.");
}

// ============================================================
// EXPERIMENTS
""",
    )
    html = replace_between(
        html,
        "function renderExperiments()",
        "// ============================================================\n// HEADLINE HYDRATION",
        """
function renderExperiments() {
  const t = document.getElementById("exp-table");
  if (!t) return;
  if (!EXPERIMENTS.length) {
    t.outerHTML = `<div id="exp-table" class="data-unavailable" data-unavailable><strong>Data unavailable</strong><span>No experiments have been provided for this build.</span></div>`;
    return;
  }
  t.innerHTML = `
    <thead><tr>
      <th>Channel</th><th>Date range</th><th class="num">Test ROI</th><th class="num">Std. error</th><th>Significance</th><th class="num">{{BRAND_NAME}} posterior (95% CI)</th>
    </tr></thead>
    <tbody>
      ${EXPERIMENTS.map(e => `
        <tr>
          <td><strong>${e.channel || ""}</strong></td>
          <td>${e.start || ""} -> ${e.end || ""}</td>
          <td class="num">${Number(e.roi || 0).toFixed(1)}x</td>
          <td class="num">+/-${Number(e.se || 0).toFixed(2)}</td>
          <td><span class="exp-status ${e.sig ? 'sig' : 'notsig'}">${e.sig ? 'Significant' : 'Not significant'}</span></td>
          <td class="num">${Number(e.recast_roi || 0).toFixed(2)}x <span style="color: var(--ink-3); font-weight: 400;">(${Number(e.recast_low || 0).toFixed(2)} - ${Number(e.recast_high || 0).toFixed(2)})</span></td>
        </tr>
      `).join("")}
    </tbody>
  `;
}

// ============================================================
// HEADLINE HYDRATION
""",
    )
    return html


def fill_template(template_html: str, cfg: dict, real_data: dict, logo_svg: str) -> str:
    real_data.setdefault("experiments", [])
    brand = cfg["brand"]
    palette = derive_palette(brand["primary_color"], brand.get("accent_color"))
    html = sanitize_user_template(template_html)
    html = html.replace("{{BRAND_NAME}}", brand["name"])
    html = html.replace("{{BRAND_TAG}}", brand.get("tag", "Analytics"))
    html = html.replace("{{PAGE_TITLE}}", cfg.get("page_title", "Channel-Level Incremental Insights"))
    html = html.replace("{{LOGO_SVG}}", logo_svg)
    html = html.replace("{{USER_NAME}}", cfg["user"]["name"])
    html = html.replace("{{USER_INITIALS}}", cfg["user"].get("initials") or "".join(p[0].upper() for p in cfg["user"]["name"].split()[:2]))
    html = html.replace("{{KPI_NAME}}", cfg["kpi_name"])
    html = html.replace("{{PRIMARY_COLOR}}", brand["primary_color"])
    html = html.replace("{{ACCENT_COLOR}}", brand.get("accent_color") or brand["primary_color"])
    html = html.replace("{{VIOLET}}", palette["violet"])
    html = html.replace("{{VIOLET_DEEP}}", palette["violet_deep"])
    html = html.replace("{{VIOLET_BG}}", palette["violet_bg"])
    html = html.replace("{{VIOLET_BG_STRONG}}", palette["violet_bg_strong"])
    html = html.replace("{{MODEL_END_DATE}}", real_data.get("model_date", ""))
    html = html.replace("{{REAL_DATA_JSON}}", json.dumps(real_data, separators=(",", ":")))
    unavailable = real_data.get("availability") or {}
    if unavailable:
        items = ", ".join(sorted(unavailable))
        notice = (
            '<div style="position:fixed;left:16px;right:16px;bottom:16px;z-index:9999;'
            'padding:12px 14px;border:1px solid rgba(251,191,36,.45);'
            'background:#211b0d;color:#f8e7b0;border-radius:8px;font:13px system-ui,sans-serif;">'
            f"Data unavailable for optional section(s): {items}."
            "</div>"
        )
        html = html.replace("</body>", notice + "\n</body>")
    return html


def load_logo_svg(path: str) -> str:
    p = Path(path).expanduser()
    if not p.exists():
        print(f"WARN: logo not found at {p}, using placeholder", file=sys.stderr)
        return '<svg class="brand-icon" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg"><circle cx="50" cy="50" r="40" fill="#9D8FFF"/></svg>'
    svg = p.read_text()
    # Drop hardcoded width/height attrs and inject our class so CSS sizing applies
    svg = re.sub(r'<svg\b([^>]*)\swidth="[^"]*"', r'<svg\1', svg, count=1)
    svg = re.sub(r'<svg\b([^>]*)\sheight="[^"]*"', r'<svg\1', svg, count=1)
    if 'class="brand-icon"' not in svg:
        svg = re.sub(r'<svg\b', '<svg class="brand-icon"', svg, count=1)
    return svg


# ----------------------------------------------------------------------
# MAIN
# ----------------------------------------------------------------------

def load_env_file():
    """Load KEY=VALUE pairs from .env in CWD or alongside this script."""
    for p in [Path(".env"), Path(__file__).parent / ".env"]:
        if p.exists():
            for line in p.read_text().splitlines():
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, _, v = line.partition("=")
                os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))
            return p
    return None


def probe_report_types(config, client, bundle_dir=None):
    here = Path(bundle_dir).resolve() if bundle_dir else Path(__file__).parent.resolve()
    return rr.probe_report_types(client, config, PROBE_REPORT_TYPES, template_path=here / "template.html")


def main():
    if len(sys.argv) < 2:
        print("Usage: python3 build.py config.json", file=sys.stderr)
        sys.exit(1)
    env_path = load_env_file()
    pat = os.environ.get("API_PAT")
    pat = rr.validate_token(pat)
    if env_path:
        print(f"[env] Loaded API_PAT from {env_path}")
    cfg = rr.load_config(Path(sys.argv[1]), required=("client_slug", "kpi_name", "brand.name", "user.name"))
    slug = cfg["client_slug"]
    kpi_name = cfg["kpi_name"]
    hist_start = cfg.get("history_start", "2024-04-08")

    if "--check" in sys.argv and "--probe-report-types" in sys.argv:
        rr.block("Choose either --check or --probe-report-types, not both", "--check is read-only; --probe-report-types creates reports")
    if "--probe-report-types" in sys.argv:
        result = probe_report_types(cfg, rr.RecastClient(pat), bundle_dir=Path(__file__).parent)
        print(f"Probe created {len(result['created'])} hidden report(s).")
        return

    print("=== Whitelabel insights build ===")
    print(f"Client: {slug}")
    print(f"KPI: {kpi_name}")
    print(f"Brand: {cfg['brand']['name']}")

    print("\n[1/4] Discovering deployment + channels...")
    meta = discover(pat, slug, kpi_name, hist_start)
    hist_start = clamp_history_start(hist_start, meta)
    print(f"  Deployment: {meta['deployment_id']}, channels: {meta['channels']}")
    if cfg.get("model_end"):
        meta["model_date"] = cfg["model_end"]
    if not meta["model_date"]:
        print("ERROR: Deployment has no model end date (checked model_date, end_date) and no", file=sys.stderr)
        print("       'model_end' override in the config. The API shape may have changed —", file=sys.stderr)
        print("       see docs/api-reference.md.", file=sys.stderr)
        sys.exit(1)

    if "--check" in sys.argv:
        if not (Path(__file__).parent / "template.html").exists():
            print("ERROR: template.html missing next to build.py — re-download the bundle.", file=sys.stderr)
            sys.exit(1)
        print("\nPreflight passed: token accepted, KPI and deployment resolved, template present.")
        print("Note: this check cannot verify report-type activation. If the build later fails")
        print("with 'is not a supported report_type', run the report types this bundle uses once")
        print("from the Recast UI first (see INSTALL.md troubleshooting), then re-run build.py.")
        return

    data_dir = Path(cfg.get("data_dir") or f"{slug}-data").expanduser()
    data_dir.mkdir(parents=True, exist_ok=True)
    out_path = Path(cfg.get("output_path") or f"{slug}-dashboard.html").expanduser()
    specs = build_report_specs(meta, hist_start)
    cache_key = rr.build_cache_key("whitelabel-insights", cfg, meta["deployment_id"], list(specs.values()))

    if not (data_dir / "manifest.json").exists() or "--rebuild" in sys.argv:
        print("\n[2/4] Firing reports + waiting...")
        fire_reports(
            pat,
            slug,
            meta["deployment_id"],
            specs,
            data_dir,
            config=cfg,
            cache_key=cache_key,
            output_path=str(out_path),
        )
    else:
        cached = json.loads((data_dir / "manifest.json").read_text())
        rr.validate_cache_key(cached.get("_meta") or {}, cache_key)
        print("\n[2/4] Using cached data (pass --rebuild to force refresh)")

    print("\n[3/4] Building REAL_DATA JSON...")
    real_data = build_real_data(meta, data_dir, kpi_name)
    (data_dir / "real-data.json").write_text(json.dumps(real_data, indent=2, default=str))
    print(f"  Wrote {data_dir/'real-data.json'} ({(data_dir/'real-data.json').stat().st_size:,} bytes)")

    print("\n[4/4] Inlining into template...")
    tpl_path = Path(__file__).parent / "template.html"
    if not tpl_path.exists():
        print(f"ERROR: template.html missing at {tpl_path}", file=sys.stderr)
        sys.exit(1)
    template_html = tpl_path.read_text()
    logo_svg = load_logo_svg(cfg["brand"]["logo_path"])
    final_html = fill_template(template_html, cfg, real_data, logo_svg)
    out_path.write_text(final_html)
    rr.reconcile_rendered_payload(
        out_path,
        real_data,
        required_paths=("kpi_name", "model_date", "channels", "summaries", "availability", "experiments"),
        disallowed_markers=(
            "Math.random",
            "170000",
            "966800",
            "89871",
            "19.1",
            "-17.6",
            "priorLo",
            "postMid",
            "250000 + Math.sin",
            "Synthetic Paid",
            "mock fallback",
            "actively calibrating",
        ),
    )
    print(f"  Wrote {out_path} ({out_path.stat().st_size:,} bytes)")

    print(f"\n✓ Done. Open: open {out_path}")


if __name__ == "__main__":
    rr.exit_block(main)
