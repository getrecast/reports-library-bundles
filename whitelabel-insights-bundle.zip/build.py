#!/usr/bin/env python3
"""
Recast white-label dashboard builder.

Usage:
    export API_PAT=gr_your_token_here
    python3 build.py config.json

Reads a client config, fires all required Recast API reports, downloads CSVs,
parses them into REAL_DATA JSON, inlines it into template.html, applies brand
styling, and writes dashboard.html.

Requires: Python 3.10+, no external deps.
"""
from __future__ import annotations
import csv, io, json, os, re, sys, time, urllib.request, urllib.error
from datetime import datetime, timedelta, timezone
from pathlib import Path


def import_shared_runner():
    here = Path(__file__).parent.resolve()
    for candidate in (here / "_shared", here.parent / "_shared"):
        if candidate.exists():
            sys.path.insert(0, str(candidate))
            import recast_runner
            return recast_runner
    print("[BLOCK] Shared runner is missing -> Re-download the bundle or run the package script before distributing", file=sys.stderr)
    sys.exit(1)


rr = import_shared_runner()
rr.require_python_version((3, 10))

BASE = (os.environ.get("RECAST_API_BASE") or "https://api.getrecast.com").rstrip("/")
RATE_LIMIT_SLEEP = 0.25  # seconds between report creates
POLL_INTERVAL = 15
POLL_TIMEOUT = 1200
REQUIRED_REPORTS = {
    "overview_7d",
    "overview_30d",
    "overview_90d",
    "overview_365d",
    "marketing_vs_baseline_7d",
    "marketing_vs_baseline_full",
    "spend_summary_full",
    "spend_response_curves",
    "grouped_weekly",
}
PROBE_REPORT_TYPES = [
    "compute_insights_overview",
    "compute_marketing_vs_baseline",
    "compute_spend_summary",
    "compute_spend_response_curves",
    "compute_grouped_channel_summaries",
    "compare_shift_curves",
]
SOURCE_STATUS_STATES = {
    "success_data",
    "success_empty",
    "create_failed",
    "report_failed",
    "timeout",
    "parse_empty",
    "stale_cache",
}
UNAVAILABLE_SOURCE_STATUSES = {"create_failed", "report_failed", "timeout", "parse_empty"}

# Default channel color palette — distinguishable on dark bg. Cycles if > 9 channels.
CHANNEL_COLOR_PALETTE = [
    "#5B8BFF", "#2DD4BF", "#7DD3FC", "#9D8FFF", "#C084FC",
    "#FB923C", "#FB7185", "#34D399", "#FBBF24",
]


def http(pat, method, path, body=None, accept="application/json"):
    url = f"{BASE}{path}"
    headers = {"Authorization": f"Bearer {pat}", "Accept": accept}
    data = None
    if body is not None:
        data = json.dumps(body).encode()
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=120) as r:
            raw = r.read()
            return r.status, (json.loads(raw.decode()) if accept == "application/json" else raw)
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode(errors="ignore")
    except urllib.error.URLError as e:
        rr.block(
            f"API {method} {path} could not connect: {e.reason}",
            "Confirm network access and RECAST_API_BASE, then rerun",
        )


def days_back(end_date: str, n: int) -> str:
    end = datetime.strptime(end_date, "%Y-%m-%d")
    return (end - timedelta(days=n - 1)).strftime("%Y-%m-%d")


def clamp_history_start(hist_start: str, meta: dict) -> str:
    floor = meta.get("start_date")
    if not floor:
        return hist_start
    return max(
        datetime.strptime(hist_start, "%Y-%m-%d"),
        datetime.strptime(floor, "%Y-%m-%d"),
    ).strftime("%Y-%m-%d")


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def compact_error(value) -> str:
    if value in (None, ""):
        return ""
    if isinstance(value, str):
        return value
    return json.dumps(value, sort_keys=True)


def parser_result(state: str, rows=None, reason: str = "", **extra) -> dict:
    if state not in {"data", "empty_valid", "unrecognized"}:
        raise ValueError(f"unknown parser state: {state}")
    out = {"state": state, "rows": rows or []}
    if reason:
        out["reason"] = reason
    out.update(extra)
    return out


def source_status_record(status: str, reason: str = "", **extra) -> dict:
    if status not in SOURCE_STATUS_STATES:
        raise ValueError(f"unknown source status: {status}")
    out = {"status": status}
    if reason:
        out["reason"] = reason
    out.update(extra)
    return out


def derive_availability(source_status: dict) -> dict:
    availability = {}
    for name, record in (source_status or {}).items():
        status = (record or {}).get("status")
        if status not in UNAVAILABLE_SOURCE_STATUSES:
            continue
        availability[name] = {
            "status": "unavailable",
            "source_status": status,
            "reason": (record or {}).get("reason") or status.replace("_", " "),
        }
    return availability


# ----------------------------------------------------------------------
# API DISCOVERY
# ----------------------------------------------------------------------

def discover(pat: str, slug: str, kpi_name: str, hist_start: str) -> dict:
    """Find KPI + deployment + channels. Returns {kpi_id, deployment_id, channels, lower_funnel, model_date}."""
    status, data = http(pat, "GET", f"/v1/clients/{slug}/kpis")
    if status != 200:
        rr.block(f"GET /kpis failed: {status} {data}", "Confirm the token and client slug, then rerun")
    kpi = next((k for k in data["data"] if k["name"] == kpi_name), None)
    if not kpi:
        names = [k["name"] for k in data["data"]]
        suggestion = rr.suggest_available_name(kpi_name, names)
        fix = f"Use the exact KPI name from Recast. Available: {names}"
        if suggestion:
            fix = f"Did you mean '{suggestion}'? {fix}"
        rr.block(f"KPI '{kpi_name}' not found", fix)
    kpi_id = kpi["id"]
    status, kdata = http(pat, "GET", f"/v1/clients/{slug}/kpis/{kpi_id}")
    if status != 200:
        rr.block(f"GET /kpis/{kpi_id} failed: {status} {kdata}", "Confirm the KPI is available to this token")
    # Legacy API shape: depvar_configurations[].deployment_id
    deps = kdata.get("depvar_configurations") or []
    if len(deps) > 1:
        rr.block(
            f"KPI '{kpi_name}' is a multi-depvar KPI",
            "Choose a single-depvar KPI; aggregate multi-depvar KPIs are not supported by this bundle yet",
        )
    if deps:
        deployment_id = deps[0]["deployment_id"]
    else:
        # Current API shape: depvars[].slug — resolve the active deployment by slug
        depvars = kdata.get("depvars") or kpi.get("depvars") or []
        if len(depvars) > 1:
            rr.block(
                f"KPI '{kpi_name}' is a multi-depvar KPI",
                "Choose a single-depvar KPI; aggregate multi-depvar KPIs are not supported by this bundle yet",
            )
        if not depvars:
            rr.block(f"KPI '{kpi_name}' has no depvars", "Confirm the model is active in Recast")
        depvar_slug = depvars[0]["slug"]
        status, all_deps = http(pat, "GET", f"/v1/clients/{slug}/deployments")
        if status != 200:
            rr.block(f"GET /deployments failed: {status} {all_deps}", "Confirm the token can read deployments")
        dep_items = all_deps if isinstance(all_deps, list) else all_deps.get("data") or all_deps.get("deployments") or []
        deployment_id = None
        for d in dep_items:
            status, full = http(pat, "GET", f"/v1/clients/{slug}/deployments/{d['id']}")
            if full.get("dashboard_slug") == depvar_slug and full.get("active"):
                deployment_id = full["id"]
                break
        if deployment_id is None:
            rr.block(f"KPI '{kpi_name}' has no active deployment", "Confirm the model is active in Recast")
    status, ddata = http(
        pat, "GET",
        f"/v1/clients/{slug}/deployments/{deployment_id}"
        f"?extra_fields=spend_channels_labels,upper_funnel_channel_labels,lower_funnel_channel_labels,contextual_variable_defaults"
    )
    if status != 200:
        rr.block(f"GET /deployments/{deployment_id} failed: {status} {ddata}", "Confirm the deployment is active")
    channels = ddata.get("spend_channels_labels", [])
    lower = ddata.get("lower_funnel_channel_labels", [])
    upper = [c for c in channels if c not in lower]
    model_date = ddata.get("model_date") or ddata.get("end_date") or ""
    return {
        "kpi_id": kpi_id,
        "deployment_id": deployment_id,
        "channels": channels,
        "upper_funnel": upper,
        "lower_funnel": lower,
        "model_date": model_date,
        "start_date": ddata.get("start_date") or ddata.get("history_start") or ddata.get("model_start_date"),
        "context_vars": ddata.get("contextual_variable_defaults", {}),
    }


# ----------------------------------------------------------------------
# REPORT FIRING + POLLING
# ----------------------------------------------------------------------

def build_report_specs(meta: dict, hist_start: str) -> dict:
    end = meta["model_date"]
    hist_start = clamp_history_start(hist_start, meta)
    channels = meta["channels"]
    upper = meta["upper_funnel"]
    specs = {
        "overview_7d": {"report_type": "compute_insights_overview", "start_date": days_back(end, 7), "end_date": end},
        "overview_30d": {"report_type": "compute_insights_overview", "start_date": days_back(end, 30), "end_date": end},
        "overview_90d": {"report_type": "compute_insights_overview", "start_date": days_back(end, 90), "end_date": end},
        "overview_365d": {"report_type": "compute_insights_overview", "start_date": days_back(end, 365), "end_date": end},
        "marketing_vs_baseline_7d": {"report_type": "compute_marketing_vs_baseline", "start_date": days_back(end, 7), "end_date": end},
        "marketing_vs_baseline_full": {"report_type": "compute_marketing_vs_baseline", "start_date": hist_start, "end_date": end},
        "spend_summary_full": {"report_type": "compute_spend_summary", "start_date": hist_start, "end_date": end},
        "spend_response_curves": {"report_type": "compute_spend_response_curves", "date": end, "num_days": 7, "channels": channels},
        "spike_detail": {"report_type": "compute_spike_detail_summary"},
        "context_summary": {"report_type": "compute_context_variable_summary", "start_date": hist_start, "end_date": end},
        "backtests": {"report_type": "compute_backtest_summaries"},
        "baseline_summary_full": {"report_type": "compute_baseline_summary", "start_date": hist_start, "end_date": end, "include_spikes": "false"},
        "baseline_spikes_full": {"report_type": "compute_baseline_summary", "start_date": hist_start, "end_date": end, "include_spikes": "true"},
        "prior_vs_posterior": {"report_type": "compute_prior_vs_posterior", "start_date": hist_start, "end_date": end, "channels": channels},
        "grouped_weekly": {
            "report_type": "compute_grouped_channel_summaries",
            "start_date": hist_start, "end_date": end,
            "channel_groups": [{"name": ch, "channels": [ch]} for ch in channels],
            "include_lower_funnel_effects": "false",
        },
    }
    if meta.get("lower_funnel"):
        specs["lower_funnel_waterfall_7d"] = {"report_type": "compute_lower_funnel_waterfall", "start_date": days_back(end, 7), "end_date": end}
    return specs


def manifest_report_record(
    form: dict,
    deployment_id,
    status: str,
    report_id=None,
    report_body: dict | None = None,
    error_body=None,
    now: str | None = None,
) -> dict:
    report_body = report_body or {}
    form = (report_body.get("form") or form or {}).copy()
    now = now or utc_now()
    results = report_body.get("results") or {}
    record = {
        "status": status,
        "report_id": str(report_id if report_id is not None else report_body.get("id", "")),
        "report_type": form.get("report_type"),
        "deployment_id": str(form.get("deployment_id") or deployment_id),
        "created_at": report_body.get("created_at") or now,
        "updated_at": report_body.get("updated_at") or now,
        "form": form,
        "downloads": {},
        "highlights": results.get("highlights") or {},
    }
    if error_body not in (None, ""):
        record["error_body"] = error_body
        record["reason"] = compact_error(error_body)
    return record


def fire_reports(
    pat: str,
    slug: str,
    deployment_id: int,
    specs: dict,
    data_dir: Path,
    config: dict | None = None,
    cache_key: str | None = None,
    output_path: str | None = None,
) -> dict:
    """Create all reports, poll until done, download CSVs. Returns manifest."""
    data_dir.mkdir(parents=True, exist_ok=True)
    print(f"Firing {len(specs)} reports for client `{slug}`...")
    ids = {}
    created_forms = {}
    config = config or {}
    manifest_created_at = utc_now()
    manifest = {
        "_meta": {
            "manifest_version": rr.MANIFEST_VERSION,
            "bundle_slug": "whitelabel-insights",
            "cache_key": cache_key,
            "output_path": output_path,
            "config_identity": {
                "client_slug": config.get("client_slug"),
                "kpi_name": config.get("kpi_name"),
                "brand_name": (config.get("brand") or {}).get("name"),
            },
            "deployment_id": str(deployment_id),
            "created_at": manifest_created_at,
            "updated_at": manifest_created_at,
            "source_as_of": manifest_created_at,
        }
    }
    optional_unavailable = {}
    for name, form in specs.items():
        payload = {
            "name": f"whitelabel-build {name}",
            "show_in_ui": False,
            "form": {**form, "deployment_id": deployment_id},
        }
        status, body = http(pat, "POST", f"/v1/clients/{slug}/reports", payload)
        if status != 201:
            if name in REQUIRED_REPORTS:
                rr.block(f"Required report '{name}' failed to start: {body}", "Run this report type once in the Recast UI, then rerun with --rebuild")
            optional_unavailable[name] = compact_error(body)
            manifest[name] = manifest_report_record(
                payload["form"],
                deployment_id,
                "create_failed",
                error_body=body,
            )
            print(f"  [OPTIONAL UNAVAILABLE] {name}: {body}", file=sys.stderr)
            continue
        rid = body.get("id")
        ids[name] = rid
        created_forms[name] = payload["form"]
        print(f"  [QUEUED] {name} -> id={rid}")
        time.sleep(RATE_LIMIT_SLEEP)

    print(f"\nWaiting on {len(ids)} reports...")
    pending = dict(ids)
    completed = {}
    failed = {}
    latest = {}
    t0 = time.time()
    while pending:
        time.sleep(POLL_INTERVAL)
        elapsed = int(time.time() - t0)
        done = []
        for name, rid in list(pending.items()):
            s, body = http(pat, "GET", f"/v1/clients/{slug}/reports/{rid}")
            if isinstance(body, dict):
                latest[name] = body
            if s != 200 or body.get("status") in ("ready", "processing"):
                continue
            if body.get("status") == "success":
                completed[name] = body
                done.append(name)
                print(f"  [{elapsed}s DONE] {name}")
            else:
                failed[name] = body.get("status", "unknown")
                done.append(name)
                if name in REQUIRED_REPORTS:
                    rr.block(f"Required report '{name}' failed while polling: {body.get('status')}", "Run this report type once in the Recast UI, then rerun with --rebuild")
                manifest[name] = manifest_report_record(
                    created_forms.get(name) or specs.get(name),
                    deployment_id,
                    "report_failed",
                    report_id=rid,
                    report_body=body,
                    error_body=body.get("error") or body.get("status", "unknown"),
                )
                print(f"  [{elapsed}s OPTIONAL UNAVAILABLE] {name} -> {body.get('status')}")
        for n in done:
            del pending[n]
        if pending and elapsed > POLL_TIMEOUT:
            required_pending = [name for name in pending if name in REQUIRED_REPORTS]
            if required_pending:
                rr.block(f"Required reports timed out: {required_pending}", "Rerun the build; if it repeats, contact Recast support")
            for name in list(pending):
                manifest[name] = manifest_report_record(
                    created_forms.get(name) or specs.get(name),
                    deployment_id,
                    "timeout",
                    report_id=pending.get(name),
                    report_body=latest.get(name),
                    error_body="timeout",
                )
            print(f"  [TIMEOUT] optional reports unavailable: {list(pending.keys())}", file=sys.stderr)
            break

    print(f"\nDownloading CSVs...")
    for name, body in completed.items():
        rdir = data_dir / name
        rdir.mkdir(parents=True, exist_ok=True)
        results = (body.get("results") or {})
        dls = results.get("downloads") or []
        manifest[name] = manifest_report_record(
            created_forms.get(name) or specs.get(name),
            deployment_id,
            "success",
            report_id=ids[name],
            report_body=body,
        )
        for d in dls:
            key = d.get("key")
            if not key:
                continue
            s, raw = http(pat, "GET", f"/v1/clients/{slug}/reports/{ids[name]}/downloads/{key}", accept="text/csv")
            if s == 200:
                text = raw.decode() if isinstance(raw, bytes) else raw
                (rdir / f"{key}.csv").write_text(text)
                manifest[name]["downloads"][key] = {
                    "path": f"{name}/{key}.csv",
                    "row_count": len(list(csv.DictReader(io.StringIO(text)))),
                }
        print(f"  [{name}] {len(manifest[name]['downloads'])} files")

    manifest["_meta"]["updated_at"] = utc_now()
    manifest["_meta"]["source_as_of"] = manifest["_meta"]["updated_at"]
    (data_dir / "manifest.json").write_text(json.dumps(manifest, indent=2, default=str))
    if failed or optional_unavailable:
        print(f"\nOptional reports unavailable: {sorted(set(failed) | set(optional_unavailable))}")
    return manifest


# ----------------------------------------------------------------------
# CSV → REAL_DATA SHAPE
# ----------------------------------------------------------------------

def read_csv(p: Path):
    if not p.exists():
        return []
    with open(p) as f:
        return list(csv.DictReader(f))


def num(s, default=0):
    if s is None or s == "" or s == "NA" or s == "NaN":
        return default
    try:
        return float(s)
    except ValueError:
        return default


def csv_rows_and_headers(text: str) -> tuple[list[dict], list[str]]:
    reader = csv.DictReader(io.StringIO(text or ""))
    rows = list(reader)
    return rows, reader.fieldnames or []


def _field(row: dict, *names, default=None):
    folded = {str(k).casefold(): k for k in row}
    for name in names:
        key = folded.get(str(name).casefold())
        if key is not None:
            return row.get(key)
    return default


def _fieldname(headers: list[str], *names):
    folded = {str(k).casefold(): k for k in headers}
    for name in names:
        key = folded.get(str(name).casefold())
        if key is not None:
            return key
    return None


def parse_backtest_changes(csvs: dict) -> list:
    """Per-horizon per-channel prediction reconciliation from backtest downloads.

    Each reconciliation CSV has columns: Channel, Spend, As of <old-date>,
    As of <new-date>, Difference. Returns one entry per horizon with real rows.
    """
    out = []
    for key, text in sorted((csvs or {}).items()):
        if "reconciliation" not in str(key).lower():
            continue
        rows, headers = csv_rows_and_headers(text)
        if not headers:
            continue
        asof_cols = [h for h in headers if str(h).strip().lower().startswith("as of")]
        if len(asof_cols) < 2:
            continue
        old_col, new_col = asof_cols[0], asof_cols[1]
        ch_col = _fieldname(headers, "channel", "component", "name", "label") or headers[0]
        spend_col = _fieldname(headers, "spend")
        diff_col = _fieldname(headers, "difference", "diff", "change") or headers[-1]
        match = re.search(r"(\d+)\s*days?", str(key), re.IGNORECASE)
        horizon = f"{match.group(1)} days" if match else str(key)
        items = []
        for row in rows:
            channel = str(row.get(ch_col) or "").strip()
            if not channel:
                continue
            items.append({
                "channel": channel,
                "spend": num(row.get(spend_col)) if spend_col else 0,
                "old": num(row.get(old_col)),
                "new": num(row.get(new_col)),
                "diff": num(row.get(diff_col)),
            })
        if items:
            out.append({
                "horizon": horizon,
                "as_of_old": str(old_col)[len("As of"):].strip(" :"),
                "as_of_new": str(new_col)[len("As of"):].strip(" :"),
                "rows": items,
            })
    return out


def parse_prior_vs_posterior(csvs: dict) -> dict:
    """Schema-agnostic capture of prior-vs-posterior report downloads.

    The exact column shape is not observable from the demo client (empty there),
    so each non-empty download is captured as a {name, columns, rows} table that
    the panel renders generically. Returns {"tables": []} when nothing is returned.
    """
    tables = []
    for key, text in sorted((csvs or {}).items()):
        rows, headers = csv_rows_and_headers(text)
        if headers and rows:
            tables.append({
                "name": str(key),
                "columns": headers,
                "rows": [[str(row.get(h, "")) for h in headers] for row in rows],
            })
    return {"tables": tables}


def parse_baseline_series(csvs: dict) -> dict:
    """Monthly + daily baseline time series (mean + 2.5%/97.5% CI band) from a
    compute_baseline_summary report's downloads (summary_monthly, summary_daily).
    """
    out = {}
    for gran in ("monthly", "daily"):
        for key, text in (csvs or {}).items():
            if gran not in str(key).lower():
                continue
            rows, headers = csv_rows_and_headers(text)
            if not headers:
                continue
            mean_col = _fieldname(headers, "mean", "50%", "median")
            lo_col = _fieldname(headers, "2.5%", "p2.5", "lower")
            hi_col = _fieldname(headers, "97.5%", "p97.5", "upper")
            date_col = _fieldname(headers, "date")
            series = []
            for row in rows:
                date = row.get(date_col) if date_col else None
                if not date:
                    continue
                series.append({
                    "date": date,
                    "mean": num(row.get(mean_col)),
                    "lo": num(row.get(lo_col)),
                    "hi": num(row.get(hi_col)),
                })
            if series:
                out[gran] = series
            break
    return out


def parse_experiments_highlights(highlights: dict) -> dict:
    highlights = highlights or {}
    rows = None
    for key in ("experiments", "lift_tests", "lift_test_results", "calibration_experiments"):
        if key in highlights:
            rows = highlights.get(key)
            break
    if rows is None or not isinstance(rows, list):
        return parser_result("unrecognized", reason="No recognized experiments highlights array was found")
    if not rows:
        return parser_result("empty_valid", reason="No experiments found for this model")

    parsed = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        posterior = row.get("posterior") or row.get("recast_posterior") or {}
        sig = row.get("statistically_significant", row.get("significant", row.get("sig", False)))
        if isinstance(sig, str):
            sig = sig.strip().lower() in {"true", "yes", "1", "significant"}
        parsed.append({
            "channel": _field(row, "channel", "channel_name", "spend_channel", default=""),
            "start": _field(row, "start_date", "start", default=""),
            "end": _field(row, "end_date", "end", default=""),
            "roi": num(_field(row, "test_roi", "roi", "point_estimate"), default=0),
            "se": num(_field(row, "standard_error", "std_error", "se"), default=0),
            "sig": bool(sig),
            "recast_roi": num(_field(row, "recast_roi", "posterior_roi", default=posterior.get("mean")), default=0),
            "recast_low": num(_field(row, "recast_low", "posterior_low", default=posterior.get("lower_bound") or posterior.get("lower")), default=0),
            "recast_high": num(_field(row, "recast_high", "posterior_high", default=posterior.get("upper_bound") or posterior.get("upper")), default=0),
        })
    return parser_result("data", rows=parsed)


def parse_baseline_downloads(csvs: dict) -> dict:
    saw_rows = False
    saw_recognized_headers = False
    baseline_names = {"intercept", "baseline", "organic baseline", "baseline + spikes outcome"}
    value_fields = ("point_estimate", "mean", "impact", "impact_total", "baseline", "baseline_mean", "value")
    p25_fields = ("p25", "25%", "lower_bound", "baseline_p25")
    p75_fields = ("p75", "75%", "upper_bound", "baseline_p75")

    for text in (csvs or {}).values():
        rows, headers = csv_rows_and_headers(text)
        if not headers:
            continue
        channel_col = _fieldname(headers, "channel", "component", "name", "label")
        value_col = _fieldname(headers, *value_fields)
        if channel_col and value_col:
            saw_recognized_headers = True
        for row in rows:
            saw_rows = True
            channel = str(row.get(channel_col) or "").strip() if channel_col else ""
            channel_norm = rr.normalize_channel_name(channel)
            value = num(_field(row, *value_fields), default=None)
            if value is None:
                continue
            if channel_norm in baseline_names or any(str(k).casefold().startswith("baseline") for k in row):
                return parser_result(
                    "data",
                    baseline={
                        "point_estimate": value,
                        "p25": num(_field(row, *p25_fields), default=None),
                        "p75": num(_field(row, *p75_fields), default=None),
                    },
                )

    if saw_recognized_headers and not saw_rows:
        return parser_result("empty_valid", reason="Baseline CSV had recognized headers but no rows")
    if not saw_rows:
        return parser_result("empty_valid", reason="No baseline CSV rows returned")
    return parser_result("unrecognized", reason="Baseline report succeeded, but no recognized baseline columns were found")


def parse_clean_data_downloads(csvs: dict, context_columns) -> dict:
    if isinstance(context_columns, dict):
        context_columns = list(context_columns)
    wanted = {str(col).casefold(): str(col) for col in (context_columns or [])}
    if not wanted:
        return parser_result("empty_valid", reason="No configured context-variable columns")

    saw_rows = False
    for text in (csvs or {}).values():
        rows, headers = csv_rows_and_headers(text)
        if not headers:
            continue
        date_col = _fieldname(headers, "date", "day", "start_date")
        matched = [header for header in headers if str(header).casefold() in wanted]
        if not date_col or not matched:
            saw_rows = saw_rows or bool(rows)
            continue
        if not rows:
            return parser_result("empty_valid", reason="Clean data CSV had recognized headers but no rows")
        out_rows = []
        for row in rows:
            out = {"date": row.get(date_col)}
            for header in matched:
                canonical = wanted[str(header).casefold()]
                out[canonical] = num(row.get(header), default=row.get(header))
            out_rows.append(out)
        return parser_result("data", rows=out_rows)

    if saw_rows:
        return parser_result("unrecognized", reason="Clean data succeeded, but configured context-variable columns were not found")
    return parser_result("empty_valid", reason="No clean data rows returned")


def report_csvs_from_manifest(data_dir: Path, report_name: str, report: dict) -> dict:
    csvs = {}
    for key, info in ((report or {}).get("downloads") or {}).items():
        rel = (info or {}).get("path") or f"{report_name}/{key}.csv"
        path = data_dir / rel
        if path.exists():
            csvs[key] = path.read_text()
    return csvs


def validate_report_deployments(manifest: dict, expected_deployment_id) -> None:
    expected = str(expected_deployment_id or (manifest.get("_meta") or {}).get("deployment_id") or "")
    if not expected:
        return
    for name, report in manifest.items():
        if name == "_meta" or not isinstance(report, dict):
            continue
        candidates = [
            report.get("deployment_id"),
            (report.get("form") or {}).get("deployment_id"),
        ]
        for value in candidates:
            if value not in (None, "") and str(value) != expected:
                rr.block(
                    f"Report '{name}' uses deployment {value}, but build resolved deployment {expected}",
                    "Delete the data directory or rerun with --rebuild so one build uses one deployment",
                )


def manifest_source_as_of(manifest: dict) -> str:
    meta = manifest.get("_meta") or {}
    if meta.get("source_as_of"):
        return meta["source_as_of"]
    times = []
    for report in manifest.values():
        if isinstance(report, dict):
            times.extend([report.get("updated_at"), report.get("created_at")])
    return max([t for t in times if t] or [utc_now()])


def report_source_status(name: str, report: dict) -> dict:
    status = (report or {}).get("status")
    base = {
        "report_id": (report or {}).get("report_id"),
        "report_type": (report or {}).get("report_type"),
        "deployment_id": (report or {}).get("deployment_id"),
    }
    if status in {"create_failed", "report_failed", "timeout"}:
        return source_status_record(status, (report or {}).get("reason") or status.replace("_", " "), **base)
    if status == "success":
        downloads = (report or {}).get("downloads") or {}
        highlights = (report or {}).get("highlights") or {}
        has_rows = any((info or {}).get("row_count", 0) > 0 for info in downloads.values())
        has_highlights = bool(highlights)
        if has_rows or has_highlights:
            return source_status_record("success_data", **base)
        return source_status_record("success_empty", "Report succeeded with no rows or highlights", **base)
    if status == "unavailable":
        return source_status_record("report_failed", (report or {}).get("reason") or "Report unavailable", **base)
    return source_status_record("parse_empty", f"Unrecognized report lifecycle status for {name}: {status}", **base)


def source_status_from_parser(result: dict, empty_reason: str, parse_reason: str, **extra) -> dict:
    state = (result or {}).get("state")
    if state == "data":
        return source_status_record("success_data", **extra)
    if state == "empty_valid":
        return source_status_record("success_empty", (result or {}).get("reason") or empty_reason, **extra)
    return source_status_record("parse_empty", (result or {}).get("reason") or parse_reason, **extra)


def experiments_from_manifest(manifest: dict) -> dict:
    found_unrecognized = None
    for name, report in manifest.items():
        if name == "_meta" or not isinstance(report, dict) or report.get("status") != "success":
            continue
        highlights = report.get("highlights") or {}
        if not any(key in highlights for key in ("experiments", "lift_tests", "lift_test_results", "calibration_experiments")):
            continue
        parsed = parse_experiments_highlights(highlights)
        if parsed["state"] in {"data", "empty_valid"}:
            parsed["report_name"] = name
            return parsed
        found_unrecognized = parsed
    if found_unrecognized:
        return found_unrecognized
    return parser_result("empty_valid", reason="No experiments found for this model")


def baseline_from_highlights(manifest: dict) -> dict | None:
    for key in ("overview_7d", "marketing_vs_baseline_7d", "overview_30d", "overview_90d", "overview_365d"):
        highlights = ((manifest.get(key) or {}).get("highlights") or {})
        cur = highlights.get("current_period", {}) or {}
        baseline = ((cur.get("outcome") or {}).get("baseline") or {})
        if isinstance(baseline, dict):
            value = baseline.get("point_estimate")
            if value:
                return {
                    "point_estimate": value,
                    "p25": baseline.get("p25") or baseline.get("25%"),
                    "p75": baseline.get("p75") or baseline.get("75%"),
                    "report_name": key,
                }
    return None


def baseline_from_manifest_downloads(manifest: dict, data_dir: Path) -> dict:
    csvs = {}
    for key in ("overview_7d", "marketing_vs_baseline_7d"):
        csvs.update(report_csvs_from_manifest(data_dir, key, manifest.get(key) or {}))
    return parse_baseline_downloads(csvs)


def build_real_data(meta: dict, data_dir: Path, kpi_name: str, cache_used: bool = False) -> dict:
    manifest = json.loads((data_dir / "manifest.json").read_text())
    validate_report_deployments(manifest, meta.get("deployment_id") or (manifest.get("_meta") or {}).get("deployment_id"))
    channels = meta["channels"]
    lower = meta["lower_funnel"]
    channel_label_map = {c: c + (" ▼" if c in lower else "") for c in channels}

    # Channel colors from palette
    color_map = {ch: CHANNEL_COLOR_PALETTE[i % len(CHANNEL_COLOR_PALETTE)] for i, ch in enumerate(channels)}
    color_map["overall"] = "#E8E9EE"

    source_as_of = manifest_source_as_of(manifest)
    out = {
        "kpi_name": kpi_name,
        "model_date": meta["model_date"],
        "source_as_of": source_as_of,
    }
    if cache_used:
        out["cache_as_of"] = source_as_of
    source_status = {
        name: report_source_status(name, report)
        for name, report in manifest.items()
        if name != "_meta" and isinstance(report, dict)
    }
    source_status["cache"] = (
        source_status_record("stale_cache", "Using cached API results for this config", source_as_of=source_as_of)
        if cache_used
        else source_status_record("success_data", "Fresh API results", source_as_of=source_as_of)
    )

    # ---- Overview highlights ----
    overviews = {}
    for key in ["overview_7d", "overview_30d", "overview_90d", "overview_365d"]:
        overviews[key] = (manifest.get(key, {}) or {}).get("highlights") or {}
    out["overviews"] = overviews

    # ---- Per-period summaries ----
    summaries = {}
    for key in ["overview_7d", "overview_30d", "overview_90d", "overview_365d"]:
        rdir = data_dir / key
        summaries[key] = {
            "total_roi": read_csv(rdir / "summaries-total-roi.csv"),
            "direct_mroi": read_csv(rdir / "summaries-direct-mroi.csv"),
            "direct_impact_shifted": read_csv(rdir / "summaries-direct-impact_shifted.csv"),
        }
    out["summaries"] = summaries

    # ---- Channel list ----
    out["channels"] = [{"key": "overall", "label": "overall", "color": color_map["overall"]}]
    for ch in channels:
        out["channels"].append({"key": ch, "label": channel_label_map[ch], "color": color_map[ch]})

    # ---- Weekly + Monthly history ----
    weekly = read_csv(data_dir / "spend_summary_full" / "tables-weekly.csv")
    out["weekly"] = [
        {
            "date": r["start_date"],
            "total": num(r["total"]),
            "kpi": num(r.get(kpi_name.lower().replace(" ", "_")) or r.get("kpi") or r.get("value")),
            "roi": num(r.get("roi")),
            "blended_roi": num(r.get("blended_roi")),
            "spends": {ch: num(r.get(ch)) for ch in channels},
        }
        for r in weekly
    ]
    monthly = read_csv(data_dir / "spend_summary_full" / "tables-monthly.csv")
    out["monthly"] = [
        {
            "date": f"{r['year']}-{int(num(r['month'])):02d}-01",
            "total": num(r["total"]),
            "kpi": num(r.get(kpi_name.lower().replace(" ", "_")) or r.get("kpi") or r.get("value")),
            "roi": num(r.get("roi")),
            "blended_roi": num(r.get("blended_roi")),
            "spends": {ch: num(r.get(ch)) for ch in channels},
        }
        for r in monthly
    ]

    # ---- Saturation curves ----
    sat = read_csv(data_dir / "spend_response_curves" / "multi_day-multi_channel-tables-full_table.csv")
    sat_by_ch = {}
    for r in sat:
        ch = r["channel"]
        sat_by_ch.setdefault(ch, []).append({
            "spend": num(r["spend"]),
            "impact_total": num(r["total_mean"]),
            "impact_direct": num(r["direct_mean"]),
            "roi_total": num(r["roi_total_mean"]),
            "roi_direct": num(r["roi_direct_mean"]),
        })
    out["saturation"] = sat_by_ch

    # ---- Shift curves ----
    shifts = read_csv(data_dir / "shift_curves" / "all_shift_curves_summarized.csv")
    shift_by_ch = {}
    for r in shifts:
        shift_by_ch.setdefault(r["channel"], []).append({
            "day": int(num(r["days"])),
            "pct": num(r["mean"]),
            "lo": num(r.get("25%")),
            "hi": num(r.get("75%")),
        })
    out["shift_curves"] = shift_by_ch

    # ---- Lower funnel ----
    lf_key = lower[0] if lower else None
    if lf_key:
        lf = read_csv(data_dir / "lower_funnel_waterfall_7d" / f"channel_summaries-{lf_key}-summary_table.csv")
        out["lower_funnel"] = [
            {"channel": r["channel"], "spend_driven": num(r.get("spend_driven")), "effect_driven": num(r.get("effect_driven_mean"))}
            for r in lf
        ]
    else:
        out["lower_funnel"] = []

    # ---- Spikes ----
    sp = read_csv(data_dir / "spike_detail" / "individual_cumulative_effects_summarized.csv")
    out["spikes"] = [
        {"name": r.get("spike_name"), "date": r.get("spike_date"),
         "mean": num(r["mean"]), "p025": num(r.get("2.5%")), "p25": num(r.get("25%")),
         "p50": num(r.get("50%")), "p75": num(r.get("75%")), "p975": num(r.get("97.5%"))}
        for r in sp
    ]
    daily = read_csv(data_dir / "spike_detail" / "individual_daily_effects.csv")
    out["spikes_daily"] = [
        {"name": r["spike_name"], "spike_date": r["spike_date"], "date": r["date"], "mean": num(r["mean"])}
        for r in daily
    ]
    grouped = read_csv(data_dir / "spike_detail" / "grouped_cumulative_effects_summarized.csv")
    out["spikes_grouped"] = [
        {"name": r.get("spike_name"), "mean": num(r["mean"]),
         "p025": num(r.get("2.5%")), "p25": num(r.get("25%")), "p50": num(r.get("50%")),
         "p75": num(r.get("75%")), "p975": num(r.get("97.5%"))}
        for r in grouped
    ]

    # ---- Context ----
    ctx_h = (manifest.get("context_summary", {}) or {}).get("highlights", {}) or {}
    out["context"] = ctx_h.get("context_variables", [])
    clean_csvs = report_csvs_from_manifest(data_dir, "context_summary", manifest.get("context_summary") or {})
    clean_data = parse_clean_data_downloads(clean_csvs, meta.get("context_vars") or {})
    out["clean_data"] = clean_data.get("rows", [])
    source_status["clean_data"] = source_status_from_parser(
        clean_data,
        "No clean data rows returned",
        "Clean data report succeeded, but no recognized configured context-variable columns were found",
    )

    # ---- Backtests ----
    bt_h = (manifest.get("backtests", {}) or {}).get("highlights", {}) or {}
    out["backtest_summary"] = bt_h.get("holdout", [])
    bt_csvs = report_csvs_from_manifest(data_dir, "backtests", manifest.get("backtests") or {})
    out["backtest_changes"] = parse_backtest_changes(bt_csvs)
    pvp_csvs = report_csvs_from_manifest(data_dir, "prior_vs_posterior", manifest.get("prior_vs_posterior") or {})
    out["prior_vs_posterior"] = parse_prior_vs_posterior(pvp_csvs)
    experiment_data = experiments_from_manifest(manifest)
    out["experiments"] = experiment_data.get("rows", [])
    source_status["experiments"] = source_status_from_parser(
        experiment_data,
        "No experiments found for this model",
        "Experiment report succeeded, but no recognized experiments shape was found",
        report_name=experiment_data.get("report_name"),
    )

    # ---- Per-channel weekly time series ----
    gw_dir = data_dir / "grouped_weekly"
    channel_series = {}
    for ch in channels:
        ch_data = {}
        for metric in ["roi", "mroi", "impact", "impact_shifted"]:
            rows = read_csv(gw_dir / f"group_summaries-{ch}-{metric}-summary_weekly.csv")
            ch_data[metric] = [
                {"date": r.get("start_date"), "mean": num(r.get(f"{metric}_mean")),
                 "p25": num(r.get(f"{metric}_p25")), "p75": num(r.get(f"{metric}_p75")),
                 "spend": num(r.get("spend"))}
                for r in rows if r.get(f"{metric}_mean") not in (None, "", "NaN", "NA")
            ]
        channel_series[ch] = ch_data
    out["channel_series"] = channel_series

    # ---- Over/under (computed from 7d impact + spend) ----
    impact_rows = summaries["overview_7d"]["direct_impact_shifted"]
    spend_total = sum(num(r.get("spend")) for r in impact_rows if r["channel"] != "overall")
    impact_total = sum(num(r.get("mean")) for r in impact_rows if r["channel"] != "overall")
    ou = []
    for r in impact_rows:
        if r["channel"] == "overall":
            continue
        share_eff = num(r["mean"]) / impact_total if impact_total else 0
        share_sp = num(r.get("spend")) / spend_total if spend_total else 0
        ou.append({"ch": r["channel"], "color": color_map.get(r["channel"], "#9D8FFF"), "pct": (share_eff - share_sp) * 100})
    out["over_under"] = sorted(ou, key=lambda x: -x["pct"])

    # ---- Waterfall ----
    overview7 = overviews.get("overview_7d") or {}
    cur = overview7.get("current_period", {}) or {}
    baseline_info = baseline_from_highlights(manifest)
    baseline_outcome = (baseline_info or {}).get("point_estimate", 0)
    if baseline_info:
        source_status["baseline"] = source_status_record("success_data", report_name=baseline_info.get("report_name"))
    else:
        baseline_downloads = baseline_from_manifest_downloads(manifest, data_dir)
        if baseline_downloads.get("state") == "data":
            baseline_info = baseline_downloads.get("baseline") or {}
            baseline_outcome = baseline_info.get("point_estimate", 0)
        source_status["baseline"] = source_status_from_parser(
            baseline_downloads,
            "No API-backed baseline rows returned",
            "Baseline report succeeded, but no recognized baseline columns were found",
        )
    # ---- Baseline time series (compute_baseline_summary, both spike variants) ----
    baseline_series = {
        "without_spikes": parse_baseline_series(
            report_csvs_from_manifest(data_dir, "baseline_summary_full", manifest.get("baseline_summary_full") or {})),
        "with_spikes": parse_baseline_series(
            report_csvs_from_manifest(data_dir, "baseline_spikes_full", manifest.get("baseline_spikes_full") or {})),
    }
    out["baseline_summary"] = baseline_series
    if any(v.get("monthly") or v.get("daily") for v in baseline_series.values()):
        source_status["baseline_summary"] = source_status_record("success_data", "Baseline time series returned")
    else:
        source_status["baseline_summary"] = source_status_record(
            "create_failed", "Baseline summary report was not available for this build")
    total_outcome = (cur.get("outcome") or {}).get("total", 0)
    paid_rows = [r for r in impact_rows if r["channel"] != "overall"]
    paid_rows.sort(key=lambda r: -num(r["mean"]))
    waterfall = [{"label": "Baseline", "value": baseline_outcome, "color": "#2B2F3B"}]
    for r in paid_rows[:6]:
        waterfall.append({"label": r["channel"], "value": num(r["mean"]), "color": color_map.get(r["channel"], "#9D8FFF")})
    other_sum = sum(num(r["mean"]) for r in paid_rows[6:])
    waterfall.append({"label": "Other", "value": other_sum, "color": "#6E7281"})
    sum_so_far = sum(w["value"] for w in waterfall)
    waterfall.append({"label": "Unexplained Variation", "value": total_outcome - sum_so_far, "color": "#22252E"})
    out["waterfall"] = waterfall

    out["source_status"] = source_status
    out["availability"] = derive_availability(source_status)

    return out


# ----------------------------------------------------------------------
# TEMPLATE FILL + WRITE
# ----------------------------------------------------------------------

def hex_to_rgba(hex_str: str, alpha: float) -> str:
    h = hex_str.lstrip("#")
    r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    return f"rgba({r},{g},{b},{alpha})"


def derive_palette(primary: str, accent: str | None) -> dict:
    return {
        "violet": accent or primary,
        "violet_deep": primary,
        "violet_bg": hex_to_rgba(accent or primary, 0.10),
        "violet_bg_strong": hex_to_rgba(accent or primary, 0.18),
    }


def sanitize_user_template(html: str) -> str:
    def replace_between(source: str, start: str, end: str, replacement: str) -> str:
        start_idx = source.find(start)
        end_idx = source.find(end, start_idx + len(start)) if start_idx != -1 else -1
        if start_idx == -1 or end_idx == -1:
            return source
        return source[:start_idx] + replacement + source[end_idx:]

    unavailable_js = """
function renderUnavailableElement(id, message) {
  const node = document.getElementById(id);
  if (!node) return;
  node.outerHTML = `<div id="${id}" class="data-unavailable" data-unavailable><strong>Data unavailable</strong><span>${message}</span></div>`;
}
"""
    if ".data-unavailable" not in html:
        html = html.replace(
            "</style>",
            ".data-unavailable{display:flex;min-height:220px;align-items:center;justify-content:center;flex-direction:column;gap:8px;border:1px dashed rgba(255,255,255,.18);border-radius:8px;background:rgba(255,255,255,.03);color:#B4B7C4;font:14px system-ui,sans-serif;text-align:center;padding:24px}.data-unavailable strong{color:#E8E9EE;font-size:15px}.data-unavailable span{max-width:560px}</style>",
            1,
        )
    html = html.replace(
        "This table shows all experiments that are actively calibrating {{BRAND_NAME}}. The main rows are the results of your lift tests, including point estimates and standard errors.",
        "This table shows configured experiment results when an experiments CSV or API experiment data is available.",
    )
    for name in [
        "CHANNELS",
        "OVER",
        "UNDER",
        "WATERFALL",
        "SATURATION",
        "TIMESHIFT",
        "LF_WATERFALL",
        "SPIKES",
        "CONTEXT_VARS",
    ]:
        html = re.sub(
            rf"let\s+{name}\s*=\s*\[[\s\S]*?\n\s*\];",
            f"let {name} = Array.from([]);",
            html,
            count=1,
        )
    html = re.sub(
        r"const\s+EXPERIMENTS\s*=\s*\[[\s\S]*?\];",
        "const EXPERIMENTS = (window.REAL_DATA.experiments || []);",
        html,
        count=1,
    )
    html = re.sub(
        r"(?:let|const)\s+CHANNEL_DETAIL\s*=\s*\{[\s\S]*?\n\};",
        "let CHANNEL_DETAIL = (window.REAL_DATA.channel_detail || {});",
        html,
        count=1,
    )
    html = re.sub(
        r"(?:let|const)\s+CHANNEL_DETAIL\s*=\s*\{[^;]*\};",
        "let CHANNEL_DETAIL = (window.REAL_DATA.channel_detail || {});",
        html,
        count=1,
    )
    html = re.sub(r"^\s*//.*mock.*$", "", html, flags=re.MULTILINE | re.IGNORECASE)
    html = html.replace("Keep Hill stub for fallback dot calculation", "Use real curve points when available")
    html = html.replace("7d only — keep YoY/WoW mock for now", "7d only")
    html = replace_between(
        html,
        "function renderChannelHistorical(key) {",
        "function renderChannelImpact(key) {",
        """function renderChannelHistorical(key) {
  const svg = document.getElementById("ch-historical");
  if (!svg) return;
  const ch = CHANNELS.find(c => c.key === key);
  const color = (ch && ch.color) || "#10B981";
  const metric = (PERIOD_TABS && PERIOD_TABS.chHistorical) || "roi";
  const status = ((window.REAL_DATA || {}).source_status || {}).grouped_weekly || {};
  const realSeries = (((window.REAL_DATA || {}).channel_series || {})[key] || {})[metric];
  if (!realSeries || !realSeries.length) {
    renderUnavailableElement("ch-historical", status.reason || "Per-channel weekly time series were not returned for this build.");
    return;
  }
  const W = 1200, H = 380;
  svg.setAttribute("viewBox", `0 0 ${W} ${H}`);
  svg.innerHTML = "";
  const padL = 96, padR = 168, padT = 24, padB = 50;
  const chartW = W - padL - padR;
  const chartH = H - padT - padB;
  let dates = [], roiSeries = [], spendSeries = [];
  realSeries.forEach(r => {
    dates.push(r.date);
    roiSeries.push(r.mean);
    spendSeries.push(r.spend);
  });
  const N = roiSeries.length;
  const sx = i => padL + (i / Math.max(1, N - 1)) * chartW;
  const maxROI = Math.max(...roiSeries) * 1.1;
  const maxSpend = Math.max(...spendSeries) * 1.15;
  const sy = v => padT + chartH * (1 - v / maxROI);
  const syR = v => padT + chartH * (1 - v / maxSpend);
  for (let g = 0; g <= 4; g++) {
    const y = padT + chartH * (g / 4);
    svg.appendChild(el("line", { x1: padL, x2: W - padR, y1: y, y2: y, stroke: "#22252E", "stroke-dasharray": "2,4" }));
  }
  const barW = chartW / N * 0.6;
  spendSeries.forEach((s, i) => svg.appendChild(el("rect", { x: sx(i) - barW/2, y: syR(s), width: barW, height: chartH - (syR(s) - padT), fill: color, opacity: 0.45 })));
  svg.appendChild(el("path", { d: "M " + roiSeries.map((v, i) => `${sx(i)},${sy(v)}`).join(" L "), fill: "none", stroke: "#E8E9EE", "stroke-width": 1.5 }));
  roiSeries.forEach((v, i) => svg.appendChild(el("circle", { cx: sx(i), cy: sy(v), r: 1.8, fill: "#E8E9EE" })));
  for (let g = 0; g <= 5; g++) {
    svg.appendChild(el("text", { x: padL - 8, y: padT + chartH * (g/5) + 4, "text-anchor": "end", "font-size": 11, fill: "#6E7281" }, (maxROI * (1 - g/5)).toFixed(1)));
    svg.appendChild(el("text", { x: W - padR + 8, y: padT + chartH * (g/5) + 4, "text-anchor": "start", "font-size": 11, fill: "#6E7281" }, "$" + Math.round(maxSpend * (1 - g/5) / 1000) + "k"));
  }
  const yLabel = metric === "mroi" ? "Marginal ROI" : "Direct ROI";
  svg.appendChild(el("text", { x: 28, y: H/2, "text-anchor": "middle", "font-size": 12, fill: "#9CA0AE", transform: `rotate(-90, 28, ${H/2})` }, yLabel));
  svg.appendChild(el("text", { x: W - padR + 60, y: H/2, "text-anchor": "middle", "font-size": 12, fill: "#9CA0AE", transform: `rotate(90, ${W - padR + 60}, ${H/2})` }, "Weekly Spend"));
  [0, Math.floor(N/3), Math.floor(2*N/3), N-1].forEach(i => {
    const d = new Date(dates[i] || ("2024-04-08"));
    svg.appendChild(el("text", { x: sx(i), y: H - padB + 18, "text-anchor": "middle", "font-size": 11, fill: "#6E7281" }, d.toLocaleDateString("en-US", { month: "short", year: "numeric" })));
  });
  const lg = el("g", { transform: `translate(${W - 150}, 30)` });
  lg.appendChild(el("rect", { x: -10, y: -10, width: 140, height: 56, fill: "#15181F", stroke: "rgba(255,255,255,0.07)", rx: 6 }));
  lg.appendChild(el("line", { x1: 0, y1: 7, x2: 18, y2: 7, stroke: "#E8E9EE", "stroke-width": 1.5 }));
  lg.appendChild(el("text", { x: 24, y: 11, "font-size": 11, fill: "#B4B7C4" }, yLabel));
  lg.appendChild(el("rect", { x: 0, y: 18, width: 14, height: 12, fill: color, opacity: 0.5, rx: 2 }));
  lg.appendChild(el("text", { x: 24, y: 27, "font-size": 11, fill: "#B4B7C4" }, "Weekly Spend"));
  svg.appendChild(lg);
}

""",
    )
    html = replace_between(
        html,
        "function renderChannelImpact(key) {",
        "function renderChannelTimeShift(key) {",
        """function renderChannelImpact(key) {
  const svg = document.getElementById("ch-impact");
  if (!svg) return;
  const ch = CHANNELS.find(c => c.key === key);
  const color = (ch && ch.color) || "#10B981";
  const variant = (PERIOD_TABS && PERIOD_TABS.chImpact) || "impact";
  const metricKey = variant === "shifted" ? "impact_shifted" : "impact";
  const status = ((window.REAL_DATA || {}).source_status || {}).grouped_weekly || {};
  const realSeries = (((window.REAL_DATA || {}).channel_series || {})[key] || {})[metricKey];
  if (!realSeries || !realSeries.length) {
    renderUnavailableElement("ch-impact", status.reason || "Per-channel weekly impact series were not returned for this build.");
    return;
  }
  const W = 1200, H = 380;
  svg.setAttribute("viewBox", `0 0 ${W} ${H}`);
  svg.innerHTML = "";
  const padL = 96, padR = 168, padT = 24, padB = 50;
  const chartW = W - padL - padR;
  const chartH = H - padT - padB;
  let dates = [], display = [], spendSeries = [];
  realSeries.forEach(r => {
    dates.push(r.date);
    display.push(r.mean);
    spendSeries.push(r.spend);
  });
  const N = display.length;
  const sx = i => padL + (i / Math.max(1, N - 1)) * chartW;
  const maxImpact = Math.max(...display) * 1.1;
  const maxSpend = Math.max(...spendSeries) * 1.15;
  const sy = v => padT + chartH * (1 - v / maxImpact);
  const syR = v => padT + chartH * (1 - v / maxSpend);
  for (let g = 0; g <= 5; g++) {
    const y = padT + chartH * (g / 5);
    svg.appendChild(el("line", { x1: padL, x2: W - padR, y1: y, y2: y, stroke: "#22252E", "stroke-dasharray": "2,4" }));
  }
  const barW = chartW / N * 0.6;
  spendSeries.forEach((s, i) => svg.appendChild(el("rect", { x: sx(i) - barW/2, y: syR(s), width: barW, height: chartH - (syR(s) - padT), fill: color, opacity: 0.45 })));
  svg.appendChild(el("path", { d: "M " + display.map((v, i) => `${sx(i)},${sy(v)}`).join(" L "), fill: "none", stroke: "#E8E9EE", "stroke-width": 1.5 }));
  display.forEach((v, i) => svg.appendChild(el("circle", { cx: sx(i), cy: sy(v), r: 1.6, fill: "#E8E9EE" })));
  for (let g = 0; g <= 5; g++) {
    svg.appendChild(el("text", { x: padL - 10, y: padT + chartH * (g/5) + 4, "text-anchor": "end", "font-size": 11, fill: "#6E7281" }, fmt$(maxImpact * (1 - g/5), 0)));
    svg.appendChild(el("text", { x: W - padR + 10, y: padT + chartH * (g/5) + 4, "text-anchor": "start", "font-size": 11, fill: "#6E7281" }, "$" + Math.round(maxSpend * (1 - g/5) / 1000) + "k"));
  }
  const yLbl = variant === "shifted" ? "Impact Shifted" : "Direct Impact";
  svg.appendChild(el("text", { x: 28, y: H/2, "text-anchor": "middle", "font-size": 12, fill: "#9CA0AE", transform: `rotate(-90, 28, ${H/2})` }, yLbl));
  svg.appendChild(el("text", { x: W - padR + 60, y: H/2, "text-anchor": "middle", "font-size": 12, fill: "#9CA0AE", transform: `rotate(90, ${W - padR + 60}, ${H/2})` }, "Weekly Spend"));
  [0, Math.floor(N/3), Math.floor(2*N/3), N-1].forEach(i => {
    const d = new Date(dates[i] || "2024-04-08");
    svg.appendChild(el("text", { x: sx(i), y: H - padB + 18, "text-anchor": "middle", "font-size": 11, fill: "#6E7281" }, d.toLocaleDateString("en-US", { month: "short", year: "numeric" })));
  });
  const lg = el("g", { transform: `translate(${W - 150}, 30)` });
  lg.appendChild(el("rect", { x: -10, y: -10, width: 140, height: 56, fill: "#15181F", stroke: "rgba(255,255,255,0.07)", rx: 6 }));
  lg.appendChild(el("line", { x1: 0, y1: 7, x2: 18, y2: 7, stroke: "#E8E9EE", "stroke-width": 1.5 }));
  lg.appendChild(el("text", { x: 24, y: 11, "font-size": 11, fill: "#B4B7C4" }, yLbl));
  lg.appendChild(el("rect", { x: 0, y: 18, width: 14, height: 12, fill: color, opacity: 0.5, rx: 2 }));
  lg.appendChild(el("text", { x: 24, y: 27, "font-size": 11, fill: "#B4B7C4" }, "Weekly Spend"));
  svg.appendChild(lg);
}

""",
    )
    html = replace_between(
        html,
        "function renderContextVariable()",
        "function renderContextEffectTime()",
        """function renderContextVariable() {
  const svg = document.getElementById("context-variable");
  if (!svg) return;
  const status = ((window.REAL_DATA || {}).source_status || {}).context_summary || {};
  const rows = ((window.REAL_DATA || {}).clean_data || []);
  let varName = (PERIOD_TABS && PERIOD_TABS.contextVar);
  if (rows.length && (!varName || !(varName in rows[0]))) {
    const cols = Object.keys(rows[0]).filter(k => k !== "date" && !isNaN(Number(rows[0][k])));
    varName = cols.length ? cols[0] : varName;
  }
  const points = [];
  rows.forEach(r => {
    const v = Number(r[varName]);
    if (r.date && !isNaN(v)) points.push({ date: r.date, v: v });
  });
  if (!points.length) {
    renderUnavailableElement("context-variable", status.reason || "API-backed context-variable time series were not returned for this build.");
    return;
  }
  const W = 1200, H = 380;
  svg.setAttribute("viewBox", `0 0 ${W} ${H}`);
  svg.innerHTML = "";
  const padL = 96, padR = 40, padT = 20, padB = 50;
  const chartW = W - padL - padR;
  const chartH = H - padT - padB;
  const N = points.length;
  const vals = points.map(p => p.v);
  const lo = Math.min(...vals), hi = Math.max(...vals);
  const span = (hi - lo) || Math.abs(hi) || 1;
  const yMin = lo - span * 0.1, yMax = hi + span * 0.1;
  const sx = i => padL + (i / Math.max(1, N - 1)) * chartW;
  const sy = v => padT + chartH * (1 - (v - yMin) / (yMax - yMin));
  for (let g = 0; g <= 5; g++) {
    const y = padT + chartH * (g/5);
    svg.appendChild(el("line", { x1: padL, x2: W - padR, y1: y, y2: y, stroke: "#22252E", "stroke-dasharray": "2,4" }));
    const v = yMax - (yMax - yMin) * g/5;
    svg.appendChild(el("text", { x: padL - 10, y: y + 4, "text-anchor": "end", "font-size": 11, fill: "#6E7281" }, Math.abs(v) < 10 ? v.toFixed(2) : v.toFixed(0)));
  }
  svg.appendChild(el("line", { x1: padL, x2: W - padR, y1: H - padB, y2: H - padB, stroke: "#E8E9EE", "stroke-width": 1.5 }));
  let path = "";
  for (let i = 0; i < N; i++) {
    if (i === 0) path += `M${sx(i)},${sy(points[i].v)} `;
    else path += `L${sx(i)},${sy(points[i-1].v)} L${sx(i)},${sy(points[i].v)} `;
  }
  svg.appendChild(el("path", { d: path, fill: "none", stroke: "#B4B7C4", "stroke-width": 1.5 }));
  [0, Math.floor(N/3), Math.floor(2*N/3), N-1].forEach(i => {
    const d = new Date(points[i].date);
    svg.appendChild(el("text", { x: sx(i), y: H - padB + 18, "text-anchor": "middle", "font-size": 11, fill: "#6E7281" }, d.toLocaleDateString("en-US", { month: "short", year: "numeric" })));
  });
  svg.appendChild(el("text", { x: 28, y: H/2, "text-anchor": "middle", "font-size": 12, fill: "#9CA0AE", transform: `rotate(-90, 28, ${H/2})` }, varName));
  svg.appendChild(el("text", { x: W/2, y: H - 8, "text-anchor": "middle", "font-size": 12, fill: "#9CA0AE" }, "Date"));
}

""",
    )
    html = replace_between(
        html,
        "function seedWeekly()",
        "function renderWeeklySpendKpi()",
        """
function seedWeekly() {
  return (WEEKLY_REAL || []).map(d => ({
    t: d.date ? new Date(d.date).getTime() : d.t,
    total: d.total,
    kpi: d.kpi,
    spends: d.spends || {},
    roi: d.roi,
    blended_roi: d.blended_roi,
  }));
}
let WEEKLY = seedWeekly();

""",
    )
    # Inject the renderUnavailableElement helper only once, so sanitize is a
    # fixed point (Part B): a second pass over already-clean output is a no-op.
    baseline_helper = unavailable_js if "function renderUnavailableElement" not in html else ""
    html = replace_between(
        html,
        "function renderBaselineSummary(",
        "// ============================================================\n// SPIKES",
        baseline_helper + """
function renderBaselineSummary(elId, withSpikes) {
  const svg = document.getElementById(elId);
  if (!svg) return;
  const status = ((window.REAL_DATA || {}).source_status || {}).baseline_summary || {};
  const variant = ((window.REAL_DATA || {}).baseline_summary || {})[withSpikes ? "with_spikes" : "without_spikes"] || {};
  const gran = (PERIOD_TABS && PERIOD_TABS.baselineGran) || "monthly";
  let series = variant[gran];
  if (!series || !series.length) series = variant.monthly || variant.daily;
  if (!series || !series.length) {
    renderUnavailableElement(elId, status.reason || "API-backed baseline time series were not returned for this build.");
    return;
  }
  const W = 1200, H = 380, padL = 96, padR = 40, padT = 30, padB = 50;
  svg.setAttribute("viewBox", `0 0 ${W} ${H}`);
  svg.innerHTML = "";
  const chartW = W - padL - padR, chartH = H - padT - padB;
  const N = series.length;
  const yMax = Math.max(...series.map(p => p.hi)) * 1.05;
  const yMin = Math.min(...series.map(p => p.lo)) * 0.95;
  const sx = i => padL + (i / Math.max(1, N - 1)) * chartW;
  const sy = v => padT + chartH * (1 - (v - yMin) / ((yMax - yMin) || 1));
  for (let g = 0; g <= 5; g++) {
    const y = padT + chartH * (g / 5);
    svg.appendChild(el("line", { x1: padL, x2: W - padR, y1: y, y2: y, stroke: "#22252E", "stroke-dasharray": "2,4" }));
    const v = yMax - (yMax - yMin) * g / 5;
    svg.appendChild(el("text", { x: padL - 10, y: y + 4, "text-anchor": "end", "font-size": 11, fill: "#6E7281" }, "$" + (v / 1e6).toFixed(1) + "M"));
  }
  svg.appendChild(el("line", { x1: padL, x2: W - padR, y1: H - padB, y2: H - padB, stroke: "#E8E9EE", "stroke-width": 1.5 }));
  const band = "M " + series.map((p, i) => `${sx(i)},${sy(p.hi)}`).join(" L ") + " L " + series.slice().reverse().map((p, i) => `${sx(N - 1 - i)},${sy(p.lo)}`).join(" L ") + " Z";
  svg.appendChild(el("path", { d: band, fill: "#E8E9EE", opacity: 0.08 }));
  svg.appendChild(el("path", { d: "M " + series.map((p, i) => `${sx(i)},${sy(p.mean)}`).join(" L "), fill: "none", stroke: "#E8E9EE", "stroke-width": gran === "daily" ? 1.2 : 1.8 }));
  [0, Math.floor(N / 3), Math.floor(2 * N / 3), N - 1].forEach(i => {
    const d = new Date(series[i].date);
    svg.appendChild(el("text", { x: sx(i), y: H - padB + 18, "text-anchor": "middle", "font-size": 11, fill: "#6E7281" }, d.toLocaleDateString("en-US", { month: "short", year: "numeric" })));
  });
  svg.appendChild(el("text", { x: 28, y: H / 2, "text-anchor": "middle", "font-size": 12, fill: "#9CA0AE", transform: `rotate(-90, 28, ${H / 2})` }, "Baseline"));
  svg.appendChild(el("text", { x: (padL + W - padR) / 2, y: H - 8, "text-anchor": "middle", "font-size": 12, fill: "#9CA0AE" }, "Date"));
}

""",
    )
    html = replace_between(
        html,
        "function renderContextEffectTime()",
        "// ============================================================\n// BACKTESTS",
        """
function renderContextEffectTime() {
  renderUnavailableElement("context-effect-time", "API-backed context-variable time series were not returned for this build.");
}

""",
    )
    html = replace_between(
        html,
        "function renderBacktests()",
        "// ============================================================\n// PRIOR VS POSTERIOR",
        """
function renderBacktests() {
  const status = ((window.REAL_DATA || {}).source_status || {}).backtests || {};
  const summary = ((window.REAL_DATA || {}).backtest_summary || []);
  const changes = ((window.REAL_DATA || {}).backtest_changes || []);

  // bt-daily: actual KPI per holdout horizon (real backtest_summary)
  const svgD = document.getElementById("bt-daily");
  if (svgD) {
    if (!summary.length) {
      renderUnavailableElement("bt-daily", status.reason || "API-backed backtest summaries were not returned for this build.");
    } else {
      const W = 540, H = 280, padL = 64, padR = 24, padT = 20, padB = 52;
      svgD.setAttribute("viewBox", `0 0 ${W} ${H}`);
      svgD.innerHTML = "";
      const vals = summary.map(s => Number(s.actuals) || 0);
      const N = vals.length;
      const yMax = (Math.max(...vals) || 1) * 1.15;
      const bw = (W - padL - padR) / N * 0.6;
      const bx = i => padL + (i + 0.5) * (W - padL - padR) / N;
      const by = v => padT + (H - padT - padB) * (1 - v / yMax);
      for (let g = 0; g <= 4; g++) {
        const y = padT + (H - padT - padB) * (g / 4);
        svgD.appendChild(el("line", { x1: padL, x2: W - padR, y1: y, y2: y, stroke: "#22252E", "stroke-dasharray": "2,4" }));
        svgD.appendChild(el("text", { x: padL - 8, y: y + 4, "text-anchor": "end", "font-size": 10, fill: "#6E7281" }, fmt$(yMax * (1 - g / 4), 0)));
      }
      summary.forEach((s, i) => {
        const v = Number(s.actuals) || 0;
        svgD.appendChild(el("rect", { x: bx(i) - bw / 2, y: by(v), width: bw, height: (H - padT - padB) - (by(v) - padT), fill: "#9D8FFF", opacity: 0.7, rx: 2 }));
        svgD.appendChild(el("text", { x: bx(i), y: H - padB + 16, "text-anchor": "middle", "font-size": 10, fill: "#6E7281" }, String(s.period || ""));
      });
    }
  }

  // bt-cumulative: cumulative actuals across ordered horizons (real)
  const svgC = document.getElementById("bt-cumulative");
  if (svgC) {
    if (!summary.length) {
      renderUnavailableElement("bt-cumulative", status.reason || "API-backed backtest summaries were not returned for this build.");
    } else {
      const W = 540, H = 280, padL = 64, padR = 24, padT = 20, padB = 52;
      svgC.setAttribute("viewBox", `0 0 ${W} ${H}`);
      svgC.innerHTML = "";
      let cum = 0;
      const pts = summary.map(s => (cum += Number(s.actuals) || 0));
      const N = pts.length;
      const yMax = (pts[N - 1] || 1) * 1.1;
      const sx = i => padL + (N === 1 ? 0 : (i / (N - 1)) * (W - padL - padR));
      const sy = v => padT + (H - padT - padB) * (1 - v / yMax);
      for (let g = 0; g <= 4; g++) {
        const y = padT + (H - padT - padB) * (g / 4);
        svgC.appendChild(el("line", { x1: padL, x2: W - padR, y1: y, y2: y, stroke: "#22252E", "stroke-dasharray": "2,4" }));
        svgC.appendChild(el("text", { x: padL - 8, y: y + 4, "text-anchor": "end", "font-size": 10, fill: "#6E7281" }, fmt$(yMax * (1 - g / 4), 0)));
      }
      if (N > 1) svgC.appendChild(el("path", { d: "M " + pts.map((v, i) => `${sx(i)},${sy(v)}`).join(" L "), fill: "none", stroke: "#E8E9EE", "stroke-width": 1.8 }));
      pts.forEach((v, i) => {
        svgC.appendChild(el("circle", { cx: sx(i), cy: sy(v), r: 3, fill: "#9D8FFF" }));
        svgC.appendChild(el("text", { x: sx(i), y: H - padB + 16, "text-anchor": "middle", "font-size": 10, fill: "#6E7281" }, String(summary[i].period || "")));
      });
    }
  }

  // bt-changes: per-channel prediction revisions (real reconciliation data)
  const svgCh = document.getElementById("bt-changes");
  if (svgCh) {
    const entry = changes.length ? changes[changes.length - 1] : null;
    if (!entry || !entry.rows || !entry.rows.length) {
      renderUnavailableElement("bt-changes", status.reason || "API-backed prediction-revision data were not returned for this build.");
    } else {
      const rows = entry.rows;
      const W = 1200, H = 380, padL = 200, padR = 80, padT = 30, padB = 40;
      svgCh.setAttribute("viewBox", `0 0 ${W} ${H}`);
      svgCh.innerHTML = "";
      const N = rows.length;
      const maxAbs = Math.max(...rows.map(r => Math.abs(Number(r.diff) || 0))) || 1;
      const midX = padL + (W - padL - padR) / 2;
      const scale = ((W - padL - padR) / 2) / (maxAbs * 1.1);
      const rh = (H - padT - padB) / N;
      svgCh.appendChild(el("text", { x: midX, y: padT - 12, "text-anchor": "middle", "font-size": 12, fill: "#9CA0AE" }, `Prediction change (${entry.as_of_old} → ${entry.as_of_new})`));
      svgCh.appendChild(el("line", { x1: midX, x2: midX, y1: padT, y2: H - padB, stroke: "#3A3F4B", "stroke-width": 1 }));
      rows.forEach((r, i) => {
        const cy = padT + i * rh + rh / 2;
        const d = Number(r.diff) || 0;
        const w = Math.abs(d) * scale;
        const x = d >= 0 ? midX : midX - w;
        svgCh.appendChild(el("rect", { x: x, y: cy - rh * 0.3, width: w, height: rh * 0.6, fill: d >= 0 ? "#9D8FFF" : "#F0A6E6", rx: 2 }));
        svgCh.appendChild(el("text", { x: padL - 10, y: cy + 4, "text-anchor": "end", "font-size": 11, fill: "#B4B7C4" }, r.channel));
        svgCh.appendChild(el("text", { x: d >= 0 ? midX + w + 6 : midX - w - 6, y: cy + 4, "text-anchor": d >= 0 ? "start" : "end", "font-size": 10, fill: "#6E7281" }, (d >= 0 ? "+" : "") + fmt$(d, 0)));
      });
    }
  }
}

""",
    )
    html = replace_between(
        html,
        "function renderPVP()",
        "// ============================================================\n// EXPERIMENTS",
        """
function renderPVP() {
  const status = ((window.REAL_DATA || {}).source_status || {}).prior_vs_posterior || {};
  const tables = (((window.REAL_DATA || {}).prior_vs_posterior || {}).tables) || [];
  function renderPvpTable(id, table, fallback) {
    const node = document.getElementById(id);
    if (!node) return;
    if (!table || !table.rows || !table.rows.length) {
      renderUnavailableElement(id, status.reason || fallback);
      return;
    }
    const esc = v => String(v == null ? "" : v).replace(/[&<>]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c]));
    const head = "<tr>" + table.columns.map(c => `<th style="text-align:left;padding:6px 12px;border-bottom:1px solid rgba(255,255,255,.12);color:#9CA0AE;font-weight:600;">${esc(c)}</th>`).join("") + "</tr>";
    const bodyRows = table.rows.map(r => "<tr>" + r.map(v => `<td style="padding:6px 12px;border-bottom:1px solid rgba(255,255,255,.05);color:#E8E9EE;">${esc(v)}</td>`).join("") + "</tr>").join("");
    node.outerHTML = `<div id="${id}" style="overflow:auto;max-height:380px;"><table style="width:100%;border-collapse:collapse;font:13px system-ui,sans-serif;"><thead>${head}</thead><tbody>${bodyRows}</tbody></table></div>`;
  }
  renderPvpTable("pvp-shifts", tables[0], "API-backed prior-vs-posterior shift ranges were not returned for this build.");
  renderPvpTable("pvp-baseline", tables[1], "API-backed prior-vs-posterior baseline series were not returned for this build.");
}

""",
    )
    html = replace_between(
        html,
        "function renderExperiments()",
        "// ============================================================\n// HEADLINE HYDRATION",
        """
function renderExperiments() {
  const t = document.getElementById("exp-table");
  if (!t) return;
  const expStatus = ((window.REAL_DATA || {}).source_status || {}).experiments || {};
  const emptyMessage = expStatus.reason || "No experiments found for this model";
  if (!EXPERIMENTS.length) {
    t.outerHTML = `<div id="exp-table" class="data-unavailable" data-unavailable><strong>No experiments found for this model</strong><span>${emptyMessage}</span></div>`;
    return;
  }
  t.innerHTML = `
    <thead><tr>
      <th>Channel</th><th>Date range</th><th class="num">Test ROI</th><th class="num">Std. error</th><th>Significance</th><th class="num">{{BRAND_NAME}} posterior (95% CI)</th>
    </tr></thead>
    <tbody>
      ${EXPERIMENTS.map(e => `
        <tr>
          <td><strong>${e.channel || ""}</strong></td>
          <td>${e.start || ""} -> ${e.end || ""}</td>
          <td class="num">${Number(e.roi || 0).toFixed(1)}x</td>
          <td class="num">+/-${Number(e.se || 0).toFixed(2)}</td>
          <td><span class="exp-status ${e.sig ? 'sig' : 'notsig'}">${e.sig ? 'Significant' : 'Not significant'}</span></td>
          <td class="num">${Number(e.recast_roi || 0).toFixed(2)}x <span style="color: var(--ink-3); font-weight: 400;">(${Number(e.recast_low || 0).toFixed(2)} - ${Number(e.recast_high || 0).toFixed(2)})</span></td>
        </tr>
      `).join("")}
    </tbody>
  `;
}

""",
    )
    # Collapse runs of blank lines so sanitize is a fixed point (Part B): the
    # replace_between blocks above can introduce an extra blank line per pass,
    # and this normalization keeps sanitize(sanitize(x)) == sanitize(x).
    html = re.sub(r"\n{3,}", "\n\n", html)
    return html


def fill_template(template_html: str, cfg: dict, real_data: dict, logo_svg: str) -> str:
    real_data.setdefault("experiments", [])
    brand = cfg["brand"]
    palette = derive_palette(brand["primary_color"], brand.get("accent_color"))
    html = sanitize_user_template(template_html)
    html = html.replace("{{BRAND_NAME}}", brand["name"])
    html = html.replace("{{BRAND_TAG}}", brand.get("tag", "Analytics"))
    html = html.replace("{{PAGE_TITLE}}", cfg.get("page_title", "Channel-Level Incremental Insights"))
    html = html.replace("{{LOGO_SVG}}", logo_svg)
    html = html.replace("{{USER_NAME}}", cfg["user"]["name"])
    html = html.replace("{{USER_INITIALS}}", cfg["user"].get("initials") or "".join(p[0].upper() for p in cfg["user"]["name"].split()[:2]))
    html = html.replace("{{KPI_NAME}}", cfg["kpi_name"])
    html = html.replace("{{PRIMARY_COLOR}}", brand["primary_color"])
    html = html.replace("{{ACCENT_COLOR}}", brand.get("accent_color") or brand["primary_color"])
    html = html.replace("{{VIOLET}}", palette["violet"])
    html = html.replace("{{VIOLET_DEEP}}", palette["violet_deep"])
    html = html.replace("{{VIOLET_BG}}", palette["violet_bg"])
    html = html.replace("{{VIOLET_BG_STRONG}}", palette["violet_bg_strong"])
    html = html.replace("{{MODEL_END_DATE}}", real_data.get("model_date", ""))
    html = html.replace("{{REAL_DATA_JSON}}", json.dumps(real_data, separators=(",", ":")))
    source_as_of = real_data.get("source_as_of")
    cache_as_of = real_data.get("cache_as_of")
    if source_as_of or cache_as_of:
        bits = []
        if source_as_of:
            bits.append(f"Source as of {source_as_of}")
        if cache_as_of:
            bits.append(f"cached as of {cache_as_of}")
        freshness = (
            '<div class="source-freshness" style="position:fixed;left:16px;bottom:16px;z-index:9998;'
            'padding:8px 10px;border:1px solid rgba(255,255,255,.16);'
            'background:#171a22;color:#b4b7c4;border-radius:8px;font:12px system-ui,sans-serif;">'
            + " · ".join(bits)
            + "</div>"
        )
        html = html.replace("</body>", freshness + "\n</body>")
    unavailable = real_data.get("availability") or {}
    if unavailable:
        details = []
        for name in sorted(unavailable):
            record = unavailable[name] or {}
            prefix = "Data shape problem" if record.get("source_status") == "parse_empty" else "Data unavailable"
            details.append(f"{name}: {prefix} - {record.get('reason', '')}")
        notice = (
            '<div style="position:fixed;left:16px;right:16px;bottom:16px;z-index:9999;'
            'padding:12px 14px;border:1px solid rgba(251,191,36,.45);'
            'background:#211b0d;color:#f8e7b0;border-radius:8px;font:13px system-ui,sans-serif;">'
            f"{'; '.join(details)}"
            "</div>"
        )
        html = html.replace("</body>", notice + "\n</body>")
    return html


def load_logo_svg(path: str) -> str:
    p = Path(path).expanduser()
    if not p.exists():
        print(f"WARN: logo not found at {p}, using placeholder", file=sys.stderr)
        return '<svg class="brand-icon" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg"><circle cx="50" cy="50" r="40" fill="#9D8FFF"/></svg>'
    svg = p.read_text()
    # Drop hardcoded width/height attrs and inject our class so CSS sizing applies
    svg = re.sub(r'<svg\b([^>]*)\swidth="[^"]*"', r'<svg\1', svg, count=1)
    svg = re.sub(r'<svg\b([^>]*)\sheight="[^"]*"', r'<svg\1', svg, count=1)
    if 'class="brand-icon"' not in svg:
        svg = re.sub(r'<svg\b', '<svg class="brand-icon"', svg, count=1)
    return svg


# ----------------------------------------------------------------------
# MAIN
# ----------------------------------------------------------------------

def load_env_file():
    """Load KEY=VALUE pairs from .env in CWD or alongside this script."""
    for p in [Path(".env"), Path(__file__).parent / ".env"]:
        if p.exists():
            for line in p.read_text().splitlines():
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, _, v = line.partition("=")
                os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))
            return p
    return None


def probe_report_types(config, client, bundle_dir=None):
    here = Path(bundle_dir).resolve() if bundle_dir else Path(__file__).parent.resolve()
    return rr.probe_report_types(client, config, PROBE_REPORT_TYPES, template_path=here / "template.html")


def main():
    if len(sys.argv) < 2:
        print("Usage: python3 build.py config.json", file=sys.stderr)
        sys.exit(1)
    env_path = load_env_file()
    pat = os.environ.get("API_PAT")
    pat = rr.validate_token(pat)
    if env_path:
        print(f"[env] Loaded API_PAT from {env_path}")
    cfg = rr.load_config(Path(sys.argv[1]), required=("client_slug", "kpi_name", "brand.name", "user.name"))
    slug = cfg["client_slug"]
    kpi_name = cfg["kpi_name"]
    hist_start = cfg.get("history_start", "2024-04-08")

    if "--check" in sys.argv and "--probe-report-types" in sys.argv:
        rr.block("Choose either --check or --probe-report-types, not both", "--check is read-only; --probe-report-types creates reports")
    if "--probe-report-types" in sys.argv:
        result = probe_report_types(cfg, rr.RecastClient(pat), bundle_dir=Path(__file__).parent)
        print(f"Probe created {len(result['created'])} hidden report(s).")
        return

    print("=== Whitelabel insights build ===")
    print(f"Client: {slug}")
    print(f"KPI: {kpi_name}")
    print(f"Brand: {cfg['brand']['name']}")

    print("\n[1/4] Discovering deployment + channels...")
    meta = discover(pat, slug, kpi_name, hist_start)
    hist_start = clamp_history_start(hist_start, meta)
    print(f"  Deployment: {meta['deployment_id']}, channels: {meta['channels']}")
    if cfg.get("model_end"):
        meta["model_date"] = cfg["model_end"]
    if not meta["model_date"]:
        print("ERROR: Deployment has no model end date (checked model_date, end_date) and no", file=sys.stderr)
        print("       'model_end' override in the config. The API shape may have changed —", file=sys.stderr)
        print("       see docs/api-reference.md.", file=sys.stderr)
        sys.exit(1)

    if "--check" in sys.argv:
        if not (Path(__file__).parent / "template.html").exists():
            print("ERROR: template.html missing next to build.py — re-download the bundle.", file=sys.stderr)
            sys.exit(1)
        print("\nPreflight passed: token accepted, KPI and deployment resolved, template present.")
        print("Note: this check cannot verify report-type activation. If the build later fails")
        print("with 'is not a supported report_type', run the report types this bundle uses once")
        print("from the Recast UI first (see INSTALL.md troubleshooting), then re-run build.py.")
        return

    data_dir = Path(cfg.get("data_dir") or f"{slug}-data").expanduser()
    data_dir.mkdir(parents=True, exist_ok=True)
    out_path = Path(cfg.get("output_path") or f"{slug}-dashboard.html").expanduser()
    specs = build_report_specs(meta, hist_start)
    cache_key = rr.build_cache_key("whitelabel-insights", cfg, meta["deployment_id"], list(specs.values()))

    cache_used = False
    if not (data_dir / "manifest.json").exists() or "--rebuild" in sys.argv:
        print("\n[2/4] Firing reports + waiting...")
        fire_reports(
            pat,
            slug,
            meta["deployment_id"],
            specs,
            data_dir,
            config=cfg,
            cache_key=cache_key,
            output_path=str(out_path),
        )
    else:
        cached = json.loads((data_dir / "manifest.json").read_text())
        rr.validate_cache_key(cached.get("_meta") or {}, cache_key)
        print("\n[2/4] Using cached data (pass --rebuild to force refresh)")
        cache_used = True

    print("\n[3/4] Building REAL_DATA JSON...")
    real_data = build_real_data(meta, data_dir, kpi_name, cache_used=cache_used)
    (data_dir / "real-data.json").write_text(json.dumps(real_data, indent=2, default=str))
    print(f"  Wrote {data_dir/'real-data.json'} ({(data_dir/'real-data.json').stat().st_size:,} bytes)")

    print("\n[4/4] Inlining into template...")
    tpl_path = Path(__file__).parent / "template.html"
    if not tpl_path.exists():
        print(f"ERROR: template.html missing at {tpl_path}", file=sys.stderr)
        sys.exit(1)
    template_html = tpl_path.read_text()
    logo_svg = load_logo_svg(cfg["brand"]["logo_path"])
    final_html = fill_template(template_html, cfg, real_data, logo_svg)
    out_path.write_text(final_html)
    rr.reconcile_rendered_payload(
        out_path,
        real_data,
        required_paths=("kpi_name", "model_date", "channels", "summaries", "source_status", "availability", "experiments"),
        # Structural markers only. Bare synthetic numerics (170000, 966800,
        # 89871, 19.1, -17.6) were removed: once sanitize empties the demo
        # arrays, any of those digit sequences in the OUTPUT is real client
        # data, not fiction (B1 false-positive source). Real fiction surfaces
        # through the code/text markers below. The bare "Math.sin" canary is now
        # active: Step 2 wired every panel that carried a Math.sin seasonality
        # fallback (channel historical/impact, context variable, baseline), so
        # sanitize(template) leaves zero Math.sin calls and any in the OUTPUT is
        # fabricated data.
        disallowed_markers=(
            "Math.sin",
            "Math.random",
            "priorLo",
            "postMid",
            "250000 + Math.sin",
            "Synthetic Paid",
            "mock fallback",
            "actively calibrating",
        ),
    )
    print(f"  Wrote {out_path} ({out_path.stat().st_size:,} bytes)")

    print(f"\n✓ Done. Open: open {out_path}")


if __name__ == "__main__":
    rr.exit_block(main)
