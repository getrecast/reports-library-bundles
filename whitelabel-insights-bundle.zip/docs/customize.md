# Customizing the Whitelabel Insights bundle

The dashboard template (`template.html`) is one big HTML file (~145 KB). It's intentionally one file so the output is self-contained and easy to share. No frameworks, no build step.

## Branding

Edit `config.example.json` (or your copy):

```json
{
  "brand": {
    "name": "Your Brand",
    "tag": "Analytics",
    "primary_color": "#473091",
    "accent_color": "#9D8FFF",
    "logo_path": "./your-logo.svg"
  }
}
```

- `name` — top-left brand label
- `tag` — small subtitle under the brand name
- `primary_color` — main accent color, charts, callouts
- `accent_color` — secondary accent
- `logo_path` — path to your SVG logo. If you don't have one, omit and a placeholder shows.

The logo is inlined directly into the HTML. If the SVG has hardcoded `width`/`height` attributes that make it render too large, `build.py` strips those automatically.

## Drop sections you don't want

The template has these top-level sections:

- Overview (channel ROI/mROI/spend tiles)
- Channels (per-channel performance, saturation, time shifts)
- Baseline / Spikes / Context (model decomposition)
- Backtests (forecast error history)
- Prior vs Posterior (model parameter check)
- Experiments (lift test history)

To drop a section, find the `<section data-tab="...">` block in `template.html` and remove it. Then remove the matching tab in the nav (`<a class="tab" data-tab="...">`).

## Change the time windows

The default windows are 7d, 30d, 90d, and 365d ending at the model's current date. To change:

1. In `build.py`, find `windows = {...}` near the top of `main()`.
2. Edit start_date / end_date for each window. Re-run with `--rebuild`.

## Add a new chart

1. Edit `template.html`:
   - Add the `<section>` markup
   - Add a `render*()` JS function in the `<script>` block at the bottom
   - Add the function to the init list
2. If the chart needs new data, edit `build.py` to fire the relevant API report and pass the data to `REAL_DATA`.
3. Re-run `python3 build.py my-config.json --rebuild` to refresh.

## Restyle anything

All CSS lives in the `<style>` block at the top of `template.html`. Search for the selector and edit. No framework conventions — just plain CSS variables and rules.

## Schedule weekly refreshes

```cron
0 9 * * 1  cd /path/to/bundle && python3 build.py my-config.json --rebuild
```

Every Monday at 9 AM, re-runs against fresh API data. Output overwrites the previous file.
