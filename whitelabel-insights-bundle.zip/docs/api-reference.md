# Recast API Reference (for white-label dashboard builds)

Condensed from official docs, focused on the report types the dashboard template uses. Full Swagger at https://app.getrecast.com/api-docs.

## Official Recast API docs

This file covers only the endpoints used by this bundle. For current API contracts, auth/token setup, helper endpoints, and broader Recast APIs, consult:

- Recast API authentication and tokens: https://docs.getrecast.com/docs/the-recast-api
- Optimizer API: https://docs.getrecast.com/docs/the-optimizer-api
- Forecaster API: https://docs.getrecast.com/docs/the-forecaster-api
- Spend Forecasting API: https://docs.getrecast.com/docs/spend-forecasting-api
- Helper endpoints: https://docs.getrecast.com/docs/helper-endpoints
- Insights API: https://docs.getrecast.com/docs/the-insights-api
- API FAQ: https://docs.getrecast.com/docs/api-faq
- Client-facing API reference: https://app.getrecast.com/api-docs/index.html

## Auth

- Personal Access Token (PAT), generated in app → click email → Generate API token
- Sent as `Authorization: Bearer gr_...`
- Scoped to user's clients
- Regenerate replaces previous token

## Base URL

```
https://api.getrecast.com
```

Path shape: `/v1/clients/{client_slug}/{resource}`

`client_slug` lives in the dashboard URL between `/clients/` and `/dashboards/`.

## Rate limits

- 25 report POSTs / minute (creates for optimization, forecast, insights reports)
- GET reads are unbounded but apply same courtesy limit

## Reports

All async. POST to create → returns `id` → poll `GET /reports/{id}` until `status` is no longer `ready` or `processing` → download CSVs from `results.downloads[]`.

Common request shape:

```json
{
  "name": "any string",
  "show_in_ui": false,
  "form": {
    "deployment_id": 12345,
    "report_type": "...",
    "...": "..."
  }
}
```

### Report types used by this template

| report_type | Required form fields | Returns | Use for |
|---|---|---|---|
| `compute_insights_overview` | start_date, end_date | 8 CSVs (total/direct × roi/mroi × impact_shifted/impact_unshifted) + highlights | Overview tiles per period |
| `compute_marketing_vs_baseline` | start_date, end_date | contribution.csv (% baseline vs % paid) | Headline contribution % |
| `compute_lower_funnel_waterfall` | start_date, end_date | per lower-funnel-channel summary table + daily effect table | "Drivers of Lower Funnel Spend" |
| `compute_spend_summary` | start_date, end_date | tables-daily/weekly/monthly/total/performance.csv | All-Channels Spend per Channel |
| `compute_spend_response_curves` | date, num_days, channels[] | multi-day multi-channel full table + per-channel direct/total | Saturation curves |
| `compare_shift_curves` | channels[] (upper funnel ONLY) | all_shift_curves_summarized.csv | Time Shift by Channel |
| `compute_spike_detail_summary` | (none) | individual+grouped daily/cumulative effect CSVs | Spikes page |
| `compute_context_variable_summary` | start_date, end_date | highlights only (no CSVs) | Context Summary page |
| `compute_backtest_summaries` | (none) | recon CSVs per period + highlights | Backtests page |
| `compute_grouped_channel_summaries` | start_date, end_date, channel_groups[], include_lower_funnel_effects | per-channel weekly/monthly/daily/total summaries for ROI / mROI / impact / impact_shifted | Channel detail Historical Performance + Impact |

### Gotchas (do these or things break)

1. **`start_date` floor is `2024-04-08`** for this client. Earlier dates → 422 validation error.
2. **`compare_shift_curves` rejects lower-funnel channels.** Pass `upper_funnel_channel_labels` only.
3. **`compute_grouped_channel_summaries` rejects lower-funnel channels if `include_lower_funnel_effects: true`.** Use `"false"` (string, not boolean!) to allow lower funnel.
4. **`compute_daily_spend_vs_kpi`** is **lowercase `kpi`**, not `KPI` as the docs imply.
5. **`compute_baseline_summary` returns server error for most clients.** Skip it; use baseline values from API-backed overview or marketing-vs-baseline reports when available.
6. **Do not present missing optional report data as real output.** If an API-backed optional section has no usable data, the bundle records it as unavailable and renders a visible notice.
7. **`compute_share_of_spend_vs_effect`** returns empty downloads. Compute over/under manually from `compute_insights_overview` impact_shifted + spend.
8. **`results.highlights`** has critical data (context bounds, backtest forecast errors, overview tile numbers). Always capture from the report status response — not all of it is in CSVs.

## Helper endpoints

### KPIs
```
GET /v1/clients/{slug}/kpis
```
Returns `[{id, name}]`. Use this to find the KPI's `id`.

```
GET /v1/clients/{slug}/kpis/{kpi_id}
```
Returns the KPI's deployment. Legacy responses carry `depvar_configurations[0].deployment_id`; the current API returns `depvars[].slug`, which `build.py` resolves to the active deployment via `GET /v1/clients/{slug}/deployments`. Both shapes are handled.

### Deployments
```
GET /v1/clients/{slug}/deployments/{deployment_id}?extra_fields=spend_channels_labels,upper_funnel_channel_labels,lower_funnel_channel_labels,contextual_variable_defaults
```

Returns:
- the model end date: `end_date` in the current API, `model_date` in older responses (`build.py` tries both) — use as the window upper bound everywhere
- `spend_channels_labels` (all channels)
- `upper_funnel_channel_labels` (for `compare_shift_curves`)
- `lower_funnel_channel_labels` (usually just `search_branded`)
- `contextual_variable_defaults` (e.g., `brand_awareness: 0.516`, `price: 146`)

```
GET /v1/clients/{slug}/deployments?dashboard_slug={dashboard_slug}&per_page=5
```
Lists deployments for a dashboard. Most recent active first.

## Polling pattern

```python
while True:
    r = GET /v1/clients/{slug}/reports/{report_id}
    if r["status"] == "success":
        for d in r["results"]["downloads"]:
            csv = GET /v1/clients/{slug}/reports/{report_id}/downloads/{d["key"]}
            save(csv)
        break
    if r["status"] == "error":
        log_failure(r)
        break
    sleep(15)  # 15s poll interval is fine
```

Total wait: 1-6 min per report. Fire all in parallel.

## Sample insights_overview response.results.highlights

```json
{
  "period_days": 7,
  "current_period": {
    "spend": 293174,
    "outcome": {
      "baseline": {"point_estimate": 966804.85, "p25": 948917.51, "p75": 990001.64},
      "paid": {"point_estimate": 1234881.39, "p25": 1210349.1, "p75": 1254741.65},
      "total": 2210032
    },
    "roi": {
      "paid": {"point_estimate": 4.36, "p25": 4.26, "p75": 4.43},
      "blended": 7.54
    }
  },
  "previous_period": {"change": {"spend": "18%", "outcome": {...}, "roi": {...}}},
  "previous_year":   {"change": {"spend": "33%", "outcome": {...}, "roi": {...}}}
}
```

This is the source of truth for Overview tiles. Use directly — no CSV parsing needed for headline numbers.
