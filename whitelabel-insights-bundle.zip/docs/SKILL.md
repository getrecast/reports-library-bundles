---
name: recast-whitelabel-insights
description: Build a white-labeled Recast Insights dashboard for one client + KPI. Wraps the local build.py runner. Asks intake questions, fires API reports in parallel, applies brand styling, outputs a self-contained HTML dashboard.
---

# Recast Whitelabel Insights Skill

Canonical agent entrypoint that runs the local `build.py` against a Recast model and produces the full Insights dashboard HTML.

**This is the canonical agent entrypoint for guided builds.** The CLI command `python3 build.py my-config.json` does the same thing. Use the skill if you want a guided, interactive flow.

## Official Recast API docs

If API behavior is unclear, consult the official docs before changing endpoint paths, authentication, polling, or response parsing:

- Recast API authentication and tokens: https://docs.getrecast.com/docs/the-recast-api
- Optimizer API: https://docs.getrecast.com/docs/the-optimizer-api
- Forecaster API: https://docs.getrecast.com/docs/the-forecaster-api
- Spend Forecasting API: https://docs.getrecast.com/docs/spend-forecasting-api
- Helper endpoints: https://docs.getrecast.com/docs/helper-endpoints
- Insights API: https://docs.getrecast.com/docs/the-insights-api
- API FAQ: https://docs.getrecast.com/docs/api-faq
- Client-facing API reference: https://app.getrecast.com/api-docs/index.html

## When to invoke

User says any of:
- "Build the whitelabel insights dashboard for [client]"
- "Make a Recast Insights dashboard for [brand]"
- "Run the whitelabel-insights bundle"

## Setup (once)

1. Bundle unpacked at a known path
2. `.env` file exists with `API_PAT=gr_...`

If `.env` doesn't exist or contains the placeholder token, tell the user:

> Before I can run this, you need to put your Recast API token in `.env`. Copy `.env.example` to `.env` and paste your token after `API_PAT=`. Do NOT paste the token in this chat — I never need to see it.

## API token rules — non-negotiable

- **NEVER ask the user to paste the token into chat.**
- **NEVER save the token to memory or any persistent store.**
- **NEVER echo the token back in any message.**
- **NEVER write the token to `config.json` or any tracked file.**
- **NEVER create, edit, or print `.env` contents; the user owns that file.**
- If the user accidentally pastes the token in chat: tell them to regenerate it immediately, put the new one in `.env`, and proceed.

## Intake — three rounds

Use AskUserQuestion. Group when possible.

Do not ask for the API token. Tell the user to keep the token in `.env` and never paste it into chat. Create or edit only the user-owned config JSON, never `.env` contents or tracked files containing the token.

**Round 1 — Client & KPI**
1. Client slug from the Recast URL between `/clients/` and `/dashboards/`
2. KPI name (case-sensitive)

**Round 2 — Brand**
3. Brand name
4. Brand tagline (e.g., "Analytics", "Intelligence")
5. Logo path (SVG preferred, optional)
6. Primary color (hex)
7. Accent color (hex, optional)

**Round 3 — User pill**
8. Display name in the top-right user pill (e.g., team name, CMO name)

## Preflight check (run this first)

Before the full build, validate the setup:

```bash
python3 build.py <their-config.json> --check
```

Read-only: confirms the token, KPI, deployment, and template, and prints a
plain-language error if anything is off. The check never prints the token. If
it passes, proceed to the build.

## Build step

Write the config to a user-owned JSON file (e.g., `their-client.json`), then run:

```bash
python3 build.py <their-client.json>
```

Report progress as each phase completes:
- Discovery (~2s)
- Report firing + polling (~5-10 min — 14 reports in parallel)
- Parsing + render (~5s)

When done, tell the user:
1. Where the file is (`whitelabel-insights.html`)
2. How to open it (`open whitelabel-insights.html`)
3. That it's self-contained — host it anywhere

## Failure modes

| Symptom | Response |
|---|---|
| `API_PAT not set` | User hasn't put token in `.env`. Direct them to copy `.env.example`. |
| `401 Unauthorized` | Token rejected. Regenerate. |
| `KPI 'X' not found` | Echo the available KPIs. Ask user to confirm spelling. |
| Output says optional data is unavailable | Explain that the API did not return that optional section for this deployment. Keep the visible notice or help the user remove the optional section. |
| Polling timed out | Re-run. Backend occasionally drops queued jobs. |
| 422 `is not a supported report_type` | This report type has never been run for this client | Tell the user to run each report type this bundle uses (at minimum Insights Overview, Marketing vs. Baseline, and Spend Response Curves) once from the Recast UI, then re-run the build. |
| `KPI '...' has no depvars` | Model inactive or KPI has no deployment | Ask the user to confirm the model is active in the Recast app. |

## What this skill does NOT do

- Modify the bundle source files
- Cache anything outside the bundle's local `./data/` directory
- Touch files outside the bundle directory
- Paste, echo, or persist the API token

Stay scoped to running the build. For layout changes, point users to `docs/customize.md`.
