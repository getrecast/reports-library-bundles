# Spend Decomposition Waterfall — Recast Reports Library

Decomposes total revenue into organic baseline plus each channel's incremental contribution. The single clearest view of where the money came from in a given period.

**Live preview:** [https://research.getrecast.com/report-template-library/spend-decomposition/](https://research.getrecast.com/report-template-library/spend-decomposition/)

## What it does

For your Recast model + chosen KPI:

1. Fires `compute_insights_overview` for the configured window
2. Downloads the overview CSVs for per-channel impact, spend, ROI, and baseline
3. Builds a waterfall: baseline first, then each channel sorted by contribution, ending with the total
4. Outputs a single self-contained HTML file

## Prerequisites

- Recast API access + token (see [INSTALL.md](INSTALL.md))
- Python 3.10+ (stdlib only)

## Quick start

`.env` holds `API_PAT`; `my-config.json` holds `client_slug` and report settings.

```bash
cp .env.example .env
# Edit .env and paste your token.
# Edit .env: API_PAT=gr_your_token

cp config.example.json my-config.json
# Edit my-config.json: client_slug, kpi_name, brand colors. Default window_days is 30.

python3 build.py my-config.json --check
python3 build.py my-config.json
# → outputs spend-decomposition.html
```

The `--check` preflight is read-only — it confirms your token works, your KPI name resolves, and the API
returns the shapes this bundle expects, with a plain-language error if anything
is off. It never prints your token. If the build later fails with a 422
mentioning `report_type`, run the report once from the Recast UI first (see
`INSTALL.md`).

See [INSTALL.md](INSTALL.md) for token safety. [docs/customize.md](docs/customize.md) for tweaks.

## What's in this bundle

| File | Purpose |
|---|---|
| `README.md` | This file. |
| `INSTALL.md` | Setup + API key safety. |
| `build.py` | Stdlib Python. Hits the API, downloads report CSVs, fills template. |
| `template.html` | Report HTML with placeholders. |
| `config.example.json` | Generic config. |
| `.env.example` | Generic env. |
| `docs/api-reference.md` | API endpoints used. |
| `docs/customize.md` | Layout + data tweaks. |
| `docs/SKILL.md` | Canonical agent entrypoint for guided builds. |

## Support

Bundle issues: [recast-research-pages issues](https://github.com/getrecast/recast-research-pages/issues).
