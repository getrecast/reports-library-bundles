from __future__ import annotations

import csv
import difflib
import hashlib
import io
import json
import os
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import date, timedelta
from pathlib import Path


DEFAULT_API_BASE = "https://api.getrecast.com/v1"
MANIFEST_VERSION = 1


class RecastBlockError(RuntimeError):
    """A fail-loud, user-fixable bundle blocker."""


def block(problem, fix):
    raise RecastBlockError(f"[BLOCK] {problem} -> {fix}")


def exit_block(fn):
    try:
        return fn()
    except RecastBlockError as exc:
        print(str(exc), file=sys.stderr)
        sys.exit(1)


def require_python_version(min_version=(3, 10)):
    if tuple(sys.version_info[:2]) < tuple(min_version):
        wanted = ".".join(str(part) for part in min_version)
        running = ".".join(str(part) for part in sys.version_info[:3])
        block(
            f"Python {wanted}+ is required; running Python {running}",
            f"Install Python {wanted}+ and rerun with that interpreter",
        )


def suggest_available_name(requested, available_names):
    if not requested:
        return None
    requested_folded = str(requested).casefold()
    folded_to_original = {str(name).casefold(): name for name in available_names}
    if requested_folded in folded_to_original:
        return folded_to_original[requested_folded]
    matches = difflib.get_close_matches(requested_folded, list(folded_to_original), n=1, cutoff=0.72)
    return folded_to_original[matches[0]] if matches else None


def load_dotenv(path):
    path = Path(path)
    if not path.exists():
        return
    for raw in path.read_text().splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        if key and key not in os.environ:
            os.environ[key] = value


def validate_token(token):
    token = (token or "").strip()
    lowered = token.lower()
    if not token:
        block("API_PAT is not set", "Copy .env.example to .env and set API_PAT to your Recast token")
    if lowered.startswith(("gr_replace", "gr_your")) or "your_token" in lowered:
        block("API_PAT still contains a placeholder", "Edit .env and replace the placeholder with your Recast token")
    return token


def _get_dotted(data, key):
    cur = data
    for part in key.split("."):
        if not isinstance(cur, dict) or part not in cur:
            return None
        cur = cur[part]
    return cur


def _looks_placeholder(value):
    if not isinstance(value, str):
        return False
    normalized = value.strip().lower()
    if not normalized:
        return False
    return (
        normalized.startswith("your_")
        or normalized.startswith("your ")
        or normalized in {"your kpi name", "your brand", "client_slug", "kpi name"}
        or normalized.startswith("<")
        or "replace" in normalized
    )


def validate_config(config, required):
    if not isinstance(config, dict):
        block("Config JSON must be an object", "Use config.example.json as the starting point")
    for key in required:
        value = _get_dotted(config, key)
        if value in (None, ""):
            block(f"Missing config key '{key}'", f"Add '{key}' to your config JSON")
        if _looks_placeholder(value):
            block(f"Config key '{key}' still has a placeholder value", f"Edit '{key}' in your config JSON")
    return config


def load_config(path, required):
    path = Path(path)
    if not path.exists():
        block(f"Config file not found: {path}", "Copy config.example.json to my-config.json and edit it")
    try:
        config = json.loads(path.read_text())
    except json.JSONDecodeError as exc:
        block(f"Config JSON is malformed at line {exc.lineno}, column {exc.colno}", "Fix the JSON syntax and rerun")
    return validate_config(config, required)


def num(value, default=None):
    if value is None:
        return default
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value).strip()
    if text == "" or text.upper() in {"NA", "NAN", "NULL", "NONE"}:
        return default
    try:
        return float(text.replace(",", ""))
    except ValueError:
        return default


def normalize_channel_name(name):
    return " ".join(str(name or "").strip().lower().replace("_", " ").replace("-", " ").split())


def slugify_channel_name(name):
    return re.sub(r"[^a-z0-9]+", "-", normalize_channel_name(name)).strip("-")


class RecastClient:
    def __init__(self, token, base_url=None, requester=None):
        self.token = validate_token(token)
        self.base_url = (base_url or os.environ.get("RECAST_API_BASE") or DEFAULT_API_BASE).rstrip("/")
        self.requester = requester

    def request(self, method, path, body=None, accept="application/json"):
        if self.requester is not None:
            return self.requester(method, path, body=body, accept=accept)
        url = self.base_url + path
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(url, data=data, method=method)
        req.add_header("Authorization", f"Bearer {self.token}")
        req.add_header("Accept", accept)
        if data is not None:
            req.add_header("Content-Type", "application/json")
        try:
            with urllib.request.urlopen(req, timeout=60) as resp:
                raw = resp.read()
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode(errors="replace") if hasattr(exc, "read") else str(exc)
            block(f"API {method} {path} failed with HTTP {exc.code}: {detail}", "Confirm the token, client slug, KPI, and report availability")
        except urllib.error.URLError as exc:
            block(f"API {method} {path} could not connect: {exc.reason}", "Confirm network access and RECAST_API_BASE, then rerun")
        if accept == "text/csv":
            return raw.decode()
        return json.loads(raw.decode())

    def get_json(self, path):
        return self.request("GET", path)

    def post_json(self, path, body):
        return self.request("POST", path, body=body)

    def get_csv(self, path):
        raw = self.request("GET", path, accept="text/csv")
        if isinstance(raw, bytes):
            return raw.decode()
        return raw


def _items_from_response(resp, *keys):
    if isinstance(resp, list):
        return resp
    for key in keys:
        items = resp.get(key) if isinstance(resp, dict) else None
        if items is not None:
            return items
    return []


def resolve_kpi(client, client_slug, kpi_name):
    resp = client.get_json(f"/clients/{client_slug}/kpis")
    items = _items_from_response(resp, "data", "kpis")
    for kpi in items:
        if kpi.get("name") != kpi_name:
            continue
        deps = kpi.get("depvar_configurations") or []
        if len(deps) > 1:
            block(
                f"KPI '{kpi_name}' is a multi-depvar KPI",
                "Choose a single-depvar KPI; aggregate multi-depvar KPIs are not supported by these bundles yet",
            )
        if len(deps) == 1:
            return str(deps[0]["deployment_id"])

        depvars = kpi.get("depvars") or []
        if len(depvars) > 1:
            block(
                f"KPI '{kpi_name}' is a multi-depvar KPI",
                "Choose a single-depvar KPI; aggregate multi-depvar KPIs are not supported by these bundles yet",
            )
        if not depvars:
            block(f"KPI '{kpi_name}' has no depvars", "Confirm the model is active in Recast")
        depvar_slug = depvars[0]["slug"]
        deployments = client.get_json(f"/clients/{client_slug}/deployments")
        for deployment in _items_from_response(deployments, "data", "deployments"):
            full = client.get_json(f"/clients/{client_slug}/deployments/{deployment['id']}")
            if full.get("dashboard_slug") == depvar_slug and full.get("active"):
                return str(full["id"])
        block(f"KPI '{kpi_name}' has no active deployment", "Confirm the model is active in Recast")
    available_names = [k.get("name", "?") for k in items]
    available = ", ".join(available_names)
    suggestion = suggest_available_name(kpi_name, available_names)
    fix = f"Use the exact KPI name from Recast. Available: {available}"
    if suggestion:
        fix = f"Did you mean '{suggestion}'? {fix}"
    block(f"KPI '{kpi_name}' not found", fix)


def get_deployment(client, client_slug, deployment_id, extra_fields="spend_channels_labels"):
    return client.get_json(f"/clients/{client_slug}/deployments/{deployment_id}?extra_fields={extra_fields}")


def deployment_model_date(deployment):
    value = deployment.get("model_date") or deployment.get("model_end_date") or deployment.get("end_date")
    if not value:
        block(
            "Deployment has no model end date",
            "Confirm the model has a successful refresh or add a documented model_end override if the bundle supports it",
        )
    return value


def clamp_start_date(start, deployment):
    floor = deployment.get("start_date") or deployment.get("history_start") or deployment.get("model_start_date")
    if not floor:
        return start
    start_d = date.fromisoformat(start)
    floor_d = date.fromisoformat(floor)
    return max(start_d, floor_d).isoformat()


def window_dates(end, days, deployment=None):
    end_d = date.fromisoformat(end)
    start = (end_d - timedelta(days=int(days))).isoformat()
    if deployment:
        start = clamp_start_date(start, deployment)
    if date.fromisoformat(start) > end_d:
        block("Requested report window starts after the deployment model date", "Choose a shorter window or a different KPI")
    return start, end


def preflight_check(client, config, template_path):
    validate_config(config, required=("client_slug", "kpi_name", "brand.name"))
    client_slug = config["client_slug"]
    kpi_name = config["kpi_name"]
    deployment_id = resolve_kpi(client, client_slug, kpi_name)
    deployment = get_deployment(client, client_slug, deployment_id)
    model_date = deployment_model_date(deployment)
    if not Path(template_path).exists():
        block("template.html is missing next to build.py", "Re-download the bundle")
    return {
        "client_slug": client_slug,
        "kpi_name": kpi_name,
        "deployment_id": deployment_id,
        "model_date": model_date,
        "channels": deployment.get("spend_channels_labels") or [],
    }


def _unique_in_order(values):
    seen = set()
    out = []
    for value in values:
        if value in seen:
            continue
        seen.add(value)
        out.append(value)
    return out


def _require_channels(report_type, channels):
    if not channels:
        block(
            f"Cannot probe report type '{report_type}' because the deployment returned no spend channels",
            "Choose a KPI with active spend channels or contact Recast support",
        )
    return channels


def minimal_probe_form(report_type, deployment_id, deployment, model_date):
    """Return a minimal write-capable report form for report-type activation probes."""
    start, end = window_dates(model_date, 1, deployment=deployment)
    channels = deployment.get("spend_channels_labels") or []
    lower = deployment.get("lower_funnel_channel_labels") or []
    upper = deployment.get("upper_funnel_channel_labels") or [ch for ch in channels if ch not in lower]
    form = {"report_type": report_type, "deployment_id": deployment_id}

    if report_type in {
        "compute_insights_overview",
        "compute_marketing_vs_baseline",
        "compute_spend_summary",
        "compute_context_variable_summary",
        "compute_lower_funnel_waterfall",
    }:
        form.update({"start_date": start, "end_date": end})
        return form

    if report_type == "compute_spend_response_curves":
        form.update({
            "date": end,
            "num_days": 1,
            "channels": _require_channels(report_type, channels),
        })
        return form

    if report_type == "compute_grouped_channel_summaries":
        probe_channels = _require_channels(report_type, channels)
        form.update({
            "start_date": start,
            "end_date": end,
            "channel_groups": [{"name": ch, "channels": [ch]} for ch in probe_channels],
            "include_lower_funnel_effects": "false",
        })
        return form

    if report_type == "compare_shift_curves":
        form["channels"] = _require_channels(report_type, upper or channels)
        return form

    if report_type in {"compute_spike_detail_summary", "compute_backtest_summaries"}:
        return form

    block(
        f"No probe form is defined for report type '{report_type}'",
        "Add a minimal form for this report type before using --probe-report-types",
    )


def probe_report_types(client, config, report_types, template_path=None):
    """Explicit write-capable report-type activation probe.

    Unlike preflight_check(), this creates hidden reports by design. Callers must
    expose it only behind an explicit --probe-report-types flag.
    """
    preflight = preflight_check(client, config, template_path=template_path or Path(__file__))
    client_slug = preflight["client_slug"]
    deployment_id = preflight["deployment_id"]
    deployment = get_deployment(
        client,
        client_slug,
        deployment_id,
        extra_fields="spend_channels_labels,upper_funnel_channel_labels,lower_funnel_channel_labels",
    )
    model_date = deployment_model_date(deployment)
    created = []
    for report_type in _unique_in_order(report_types):
        form = minimal_probe_form(report_type, deployment_id, deployment, model_date)
        try:
            report_id = create_report(client, client_slug, form)
        except RecastBlockError as exc:
            msg = str(exc)
            if "HTTP 422" in msg and "report_type" in msg:
                block(
                    f"Report type '{report_type}' is not activated for this client",
                    f"Open Recast, run {report_type} once in the UI, then rerun --probe-report-types",
                )
            raise
        created.append({"report_type": report_type, "report_id": report_id, "form": form})
    return {
        "client_slug": client_slug,
        "kpi_name": preflight["kpi_name"],
        "deployment_id": deployment_id,
        "created": created,
    }


def create_report(client, client_slug, form):
    resp = client.post_json(
        f"/clients/{client_slug}/reports",
        {"form": form, "show_in_ui": False},
    )
    if "id" not in resp:
        block("Report create response did not include an id", "The Recast API shape may have changed; contact Recast support")
    return str(resp["id"])


def poll_report(client, client_slug, report_id, timeout=600, interval=15):
    deadline = time.time() + timeout
    while time.time() < deadline:
        report = client.get_json(f"/clients/{client_slug}/reports/{report_id}")
        status = report.get("status")
        if status == "success":
            return report
        if status in {"error", "failed", "failure"}:
            block(f"Report {report_id} failed: {report.get('error') or status}", "Run the report type once in the Recast UI, then rerun with --rebuild")
        time.sleep(interval)
    block(f"Report {report_id} polling timed out after {timeout}s", "Rerun the build; if it repeats, contact Recast support")


def _download_key(item):
    return item.get("key") or item.get("name") or item.get("filename") or ""


def read_csv_text(text):
    return list(csv.DictReader(io.StringIO(text or "")))


def _sha256_file(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _resolve_local_path(value, base_dir):
    path = Path(value).expanduser()
    if not path.is_absolute():
        path = Path(base_dir) / path
    return path.resolve()


def _column_aliases(column_spec):
    if isinstance(column_spec, (list, tuple, set)):
        return tuple(str(item) for item in column_spec)
    return (str(column_spec),)


def validate_local_csvs(config, specs, base_dir):
    """Validate configured local CSV inputs and return provenance metadata.

    specs entries:
      {
        "config_key": "platform_cpa_csv",
        "label": "platform CPA",
        "required": True,
        "columns": ("channel", ("platform_roas", "platform_roi", "roas"))
      }
    """
    validated = {}
    base_dir = Path(base_dir)
    for spec in specs:
        key = spec["config_key"]
        label = spec.get("label") or key
        configured = config.get(key)
        required = bool(spec.get("required"))
        if not configured:
            if required:
                block(f"{label} CSV not found", f"Set '{key}' in your config JSON")
            continue
        path = _resolve_local_path(configured, base_dir)
        if not path.exists():
            block(f"{label} CSV not found: {path}", f"Create the CSV or update '{key}' in your config JSON")
        if not path.is_file():
            block(f"{label} CSV is not a file: {path}", f"Update '{key}' to point to a CSV file")
        text = path.read_text()
        rows = read_csv_text(text)
        headers = rows[0].keys() if rows else (csv.DictReader(io.StringIO(text)).fieldnames or [])
        folded_headers = {str(header).casefold(): header for header in headers if header}
        for column_spec in spec.get("columns") or ():
            aliases = _column_aliases(column_spec)
            if not any(alias.casefold() in folded_headers for alias in aliases):
                expected = " or ".join(aliases)
                block(
                    f"{label} CSV missing required column '{expected}'",
                    f"Add the column to {path.name} or update the configured CSV",
                )
        validated[key] = {
            "path": str(path),
            "row_count": len(rows),
            "sha256": _sha256_file(path),
        }
    return validated


def download_report_csvs(client, client_slug, report, out_dir):
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    report_id = str(report["id"])
    csvs = {}
    for item in ((report.get("results") or {}).get("downloads") or []):
        key = _download_key(item)
        if not key:
            continue
        path_key = urllib.parse.quote(key, safe="")
        text = client.get_csv(f"/clients/{client_slug}/reports/{report_id}/downloads/{path_key}")
        csvs[key] = text
        (out_dir / f"{key}.csv").write_text(text)
    return csvs


def _csv_metric_key(key):
    return key[:-4] if key.endswith(".csv") else key


def _find_csv(csvs, predicate):
    for key, text in csvs.items():
        if predicate(_csv_metric_key(key).lower()):
            return key, text
    return None, None


def _channel_record(out, channel):
    return out["channels"].setdefault(channel, {"channel": channel, "key": slugify_channel_name(channel)})


def _row_channel(row):
    return row.get("channel") or row.get("Channel") or row.get("name") or row.get("label")


def _baseline_from_highlights(highlights):
    current = (highlights.get("current_period") or {})
    outcome = current.get("outcome") or {}
    baseline = outcome.get("baseline")
    if isinstance(baseline, dict):
        value = num(baseline.get("point_estimate"))
        if value is not None:
            return value
    value = num(highlights.get("baseline") or highlights.get("baseline_total") or highlights.get("baseline_revenue"))
    return value


def _total_from_highlights(highlights):
    current = (highlights.get("current_period") or {})
    outcome = current.get("outcome") or {}
    return num(outcome.get("total"))


def parse_overview_downloads(csvs, report):
    highlights = ((report.get("results") or {}).get("highlights") or {})
    out = {
        "overall": {},
        "channels": {},
        "baseline": _baseline_from_highlights(highlights),
        "total": _total_from_highlights(highlights),
        "downloads": {},
        "report_id": str(report.get("id", "")),
    }
    for key, text in csvs.items():
        out["downloads"][_csv_metric_key(key)] = {"row_count": len(read_csv_text(text))}

    total_key, total_text = _find_csv(csvs, lambda key: "roi" in key and "mroi" not in key and "total" in key)
    if total_text is None:
        total_key, total_text = _find_csv(csvs, lambda key: "roi" in key and "mroi" not in key)
    if total_text:
        for row in read_csv_text(total_text):
            channel = _row_channel(row)
            if not channel:
                continue
            roi = num(row.get("mean") or row.get("roi") or row.get("total_roi"))
            spend = num(row.get("spend") or row.get("total_spend"))
            if normalize_channel_name(channel) == "overall":
                if roi is not None:
                    out["overall"]["roi"] = roi
                if spend is not None:
                    out["overall"]["spend"] = spend
                continue
            rec = _channel_record(out, channel)
            if roi is not None:
                rec["roi"] = roi
            if spend is not None:
                rec["spend"] = spend

    mroi_key, mroi_text = _find_csv(csvs, lambda key: "mroi" in key)
    if mroi_text:
        for row in read_csv_text(mroi_text):
            channel = _row_channel(row)
            if not channel:
                continue
            mroi = num(row.get("mean") or row.get("mroi") or row.get("direct_mroi"))
            spend = num(row.get("spend") or row.get("total_spend"))
            if normalize_channel_name(channel) == "overall":
                if mroi is not None:
                    out["overall"]["mroi"] = mroi
                if spend is not None:
                    out["overall"].setdefault("spend", spend)
                continue
            rec = _channel_record(out, channel)
            if mroi is not None:
                rec["mroi"] = mroi
            if spend is not None:
                rec.setdefault("spend", spend)

    impact_key, impact_text = _find_csv(csvs, lambda key: "impact" in key and "roi" not in key and "mroi" not in key)
    if impact_text:
        for row in read_csv_text(impact_text):
            channel = _row_channel(row)
            if not channel:
                continue
            normalized = normalize_channel_name(channel)
            impact = num(row.get("mean") or row.get("impact") or row.get("impact_total") or row.get("incremental_revenue"))
            p25 = num(row.get("25%") or row.get("p25") or row.get("impact_p25") or row.get("impact_lo"))
            p75 = num(row.get("75%") or row.get("p75") or row.get("impact_p75") or row.get("impact_hi"))
            spend = num(row.get("spend") or row.get("total_spend"))
            if normalized in {"intercept", "baseline"}:
                if out["baseline"] is None and impact is not None:
                    out["baseline"] = impact
                continue
            if normalized in {"spikes", "spike", "context", "contexts"}:
                continue
            if normalized == "overall":
                if impact is not None:
                    out["overall"]["impact"] = impact
                continue
            rec = _channel_record(out, channel)
            if impact is not None:
                rec["impact"] = impact
                rec.setdefault("mean_impact", impact)
            if p25 is not None:
                rec["impact_p25"] = p25
                rec.setdefault("p25", p25)
            if p75 is not None:
                rec["impact_p75"] = p75
                rec.setdefault("p75", p75)
            if spend is not None:
                rec.setdefault("spend", spend)

    if not out["channels"]:
        for key, text in csvs.items():
            for row in read_csv_text(text):
                channel = _row_channel(row)
                if not channel or normalize_channel_name(channel) in {"overall", "intercept", "spikes"}:
                    continue
                rec = _channel_record(out, channel)
                for field, aliases in {
                    "spend": ("spend", "total_spend"),
                    "roi": ("roi", "total_roi", "mean"),
                    "mroi": ("mroi", "direct_mroi", "marginal_roi"),
                    "impact": ("incremental_revenue", "impact_total", "impact"),
                }.items():
                    for alias in aliases:
                        value = num(row.get(alias))
                        if value is not None:
                            rec.setdefault(field, value)
                            break

    if out["baseline"] is None:
        out["baseline"] = 0
    if out["total"] is None:
        out["total"] = out["baseline"] + sum((ch.get("impact") or 0) for ch in out["channels"].values())
    return out


def overview_report_record(label, report, form, csvs):
    parsed = parse_overview_downloads(csvs, report)
    return {
        "label": label,
        "report_id": str(report.get("id", "")),
        "form": form,
        "downloads": parsed["downloads"],
        "overview": parsed,
    }


def build_cache_key(bundle_slug, config, deployment_id, forms, local_files=None):
    stable_config = {
        key: value for key, value in config.items()
        if key not in {"output_path", "data_dir"}
    }
    local_hashes = []
    for file_path in local_files or []:
        path = Path(file_path).expanduser()
        if not path.exists():
            block(f"Local file not found for cache key: {path}", "Create the file or update your config JSON")
        local_hashes.append({"path": str(path.resolve()), "sha256": _sha256_file(path)})
    raw = json.dumps(
        {
            "bundle_slug": bundle_slug,
            "config": stable_config,
            "deployment_id": str(deployment_id),
            "forms": forms,
            "local_files": local_hashes,
        },
        sort_keys=True,
        separators=(",", ":"),
    )
    return hashlib.sha256(raw.encode()).hexdigest()


def validate_cache_key(manifest, expected_cache_key):
    actual = manifest.get("cache_key")
    if actual != expected_cache_key:
        block(
            "Cached data does not match this config or report window",
            "Rerun with --rebuild so the bundle fetches fresh API data",
        )


def make_manifest(bundle_slug, config, deployment_id, cache_key, reports, data):
    return {
        "manifest_version": MANIFEST_VERSION,
        "bundle_slug": bundle_slug,
        "cache_key": cache_key,
        "output_path": config.get("output_path"),
        "config_identity": {
            "client_slug": config.get("client_slug"),
            "kpi_name": config.get("kpi_name"),
            "brand_name": (config.get("brand") or {}).get("name"),
        },
        "deployment_id": str(deployment_id),
        "reports": reports,
        "data": data,
    }


def read_manifest(path, expected_cache_key=None):
    path = Path(path)
    try:
        manifest = json.loads(path.read_text())
    except json.JSONDecodeError:
        block("Cached manifest is malformed", "Delete the data directory or rerun with --rebuild")
    validate_cache_key(manifest, expected_cache_key) if expected_cache_key else None
    return manifest


def write_manifest(path, manifest):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(manifest, indent=2, sort_keys=True))


def load_cached_data(path, expected_cache_key):
    manifest = read_manifest(path, expected_cache_key=expected_cache_key)
    return manifest["data"], manifest


def reconcile_output_html(html, checks):
    findings = []
    for match in re.finditer(r"\{\{[^{}]+}}", html):
        findings.append({"code": "unresolved_template", "marker": match.group(0)})
    for check in checks:
        selector = check.get("selector")
        if selector and check.get("required"):
            pattern = re.compile(
                r"<(?P<tag>[a-zA-Z0-9:-]+)[^>]*\bid=[\"']" + re.escape(selector) + r"[\"'][^>]*>(?P<body>.*?)</(?P=tag)>",
                re.DOTALL,
            )
            found = pattern.search(html)
            body = found.group("body") if found else ""
            body_text = re.sub(r"<[^>]+>", "", body).strip()
            if not body_text:
                findings.append({"code": "empty_required_panel", "selector": selector})
        for marker in check.get("mock_markers") or []:
            if marker in html:
                findings.append({"code": "mock_panel", "marker": marker})
    return findings


def reconcile_values(expected, actual, tolerance=1e-9, prefix=""):
    findings = []
    keys = set(expected) | set(actual)
    for key in sorted(keys):
        path = f"{prefix}.{key}" if prefix else str(key)
        if key not in expected or key not in actual:
            findings.append({"code": "value_mismatch", "path": path, "expected": expected.get(key), "actual": actual.get(key)})
            continue
        ev, av = expected[key], actual[key]
        if isinstance(ev, dict) and isinstance(av, dict):
            findings.extend(reconcile_values(ev, av, tolerance=tolerance, prefix=path))
        elif isinstance(ev, (int, float)) and isinstance(av, (int, float)):
            if abs(float(ev) - float(av)) > tolerance:
                findings.append({"code": "value_mismatch", "path": path, "expected": ev, "actual": av})
        elif ev != av:
            findings.append({"code": "value_mismatch", "path": path, "expected": ev, "actual": av})
    return findings


def extract_rendered_payload(html):
    marker = "window.REAL_DATA"
    start = html.find(marker)
    if start == -1:
        block("Rendered output is missing window.REAL_DATA", "Inspect template.html and the render step")
    equals = html.find("=", start)
    if equals == -1:
        block("Rendered output has malformed window.REAL_DATA", "Inspect template.html and the render step")
    json_start = html.find("{", equals)
    if json_start == -1:
        block("Rendered output has no REAL_DATA JSON object", "Inspect template.html and the render step")
    try:
        payload, _ = json.JSONDecoder().raw_decode(html[json_start:])
    except json.JSONDecodeError as exc:
        block(
            f"Rendered REAL_DATA JSON is malformed at character {json_start + exc.pos}",
            "Inspect the generated HTML and render serialization",
        )
    return payload


def _path_exists(data, dotted_path):
    cur = data
    for part in str(dotted_path).split("."):
        if isinstance(cur, dict) and part in cur:
            cur = cur[part]
            continue
        if isinstance(cur, list):
            try:
                cur = cur[int(part)]
                continue
            except (ValueError, IndexError):
                return False
        return False
    return True


def reconcile_rendered_payload(output_path, expected_payload, required_paths=(), disallowed_markers=()):
    output_path = Path(output_path)
    html = output_path.read_text()
    findings = reconcile_output_html(html, [])
    try:
        actual_payload = extract_rendered_payload(html)
    except RecastBlockError as exc:
        findings.append({"code": "missing_real_data", "detail": str(exc)})
        actual_payload = {}
    for path in required_paths or ():
        if not _path_exists(actual_payload, path):
            findings.append({"code": "missing_required_path", "path": path})
    for marker in disallowed_markers or ():
        if marker in html:
            findings.append({"code": "disallowed_marker", "marker": marker})
    if not findings:
        findings.extend(reconcile_values(expected_payload, actual_payload))
    if findings:
        first = findings[0]
        detail = first.get("path") or first.get("marker") or first.get("detail") or ""
        rr_detail = f"{first['code']}: {detail}".strip()
        block(f"Rendered output failed reconciliation ({rr_detail})", "Inspect template.html and rerun after fixing the placeholder or data issue")
    return actual_payload
