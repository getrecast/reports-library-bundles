# Recast API endpoints used by this bundle

## Official Recast API docs

This file covers only the endpoints used by this bundle. For current API contracts, auth/token setup, helper endpoints, and broader Recast APIs, consult:

- Recast API authentication and tokens: https://docs.getrecast.com/docs/the-recast-api
- Optimizer API: https://docs.getrecast.com/docs/the-optimizer-api
- Forecaster API: https://docs.getrecast.com/docs/the-forecaster-api
- Spend Forecasting API: https://docs.getrecast.com/docs/spend-forecasting-api
- Helper endpoints: https://docs.getrecast.com/docs/helper-endpoints
- Insights API: https://docs.getrecast.com/docs/the-insights-api
- API FAQ: https://docs.getrecast.com/docs/api-faq
- Client-facing API reference: https://app.getrecast.com/api-docs/index.html

## Base URL

Default: `https://api.getrecast.com/v1`. Override via `RECAST_API_BASE` in `.env`.

## Authentication

```
Authorization: Bearer gr_your_token_here
```

## 1. List KPIs

```
GET /clients/{client_slug}/kpis
```

Resolves the KPI name to a deployment_id.

## 2. Get deployment metadata

```
GET /clients/{client_slug}/deployments/{deployment_id}?extra_fields=spend_channels_labels
```

Returns the model end date (`end_date` in the current API; older responses use `model_date` or `model_end_date` — `build.py` tries all three) as the upper bound for the window, plus channel labels.

## 3. Fire `compute_insights_overview`

```
POST /clients/{client_slug}/reports
{
  "form": {
    "report_type": "compute_insights_overview",
    "deployment_id": <id>,
    "start_date": "<YYYY-MM-DD>",
    "end_date": "<YYYY-MM-DD>"
  },
  "show_in_ui": false
}
```

When the report succeeds, the completed report includes `results.downloads[]`.
The bundle downloads the overview CSVs and reads per-channel rows from:

- `summaries-total-roi.csv` for spend and ROI
- `summaries-direct-mroi.csv` when mROI is needed downstream
- `summaries-direct-impact_shifted.csv` for incremental impact and uncertainty bounds

Organic baseline comes from `results.highlights.current_period.outcome.baseline.point_estimate`.
If that field is absent, the bundle falls back to the `intercept` row in
`summaries-direct-impact_shifted.csv`.

## 4. Poll and download

```
GET /clients/{client_slug}/reports/{report_id}
GET /clients/{client_slug}/reports/{report_id}/downloads/{download_key}
```

Polled every 15 seconds. 10-minute timeout by default.

## Errors

| HTTP status | Meaning | Fix |
|---|---|---|
| 401 | Token rejected | Regenerate |
| 403 | No access to this client | Check account access |
| 404 | Slug/KPI not found | Verify spelling |
| 422 | Bad parameters | Check dates and deployment_id |
| 5xx | Backend issue | Retry |
