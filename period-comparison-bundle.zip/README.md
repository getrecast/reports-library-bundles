# Period-over-Period Comparison — Recast Reports Library

Side-by-side spend and ROI for every channel, current period vs the period before. Built for QBRs, board prep, and "what changed this period" reviews.

**Live preview:** [https://research.getrecast.com/report-template-library/period-comparison/](https://research.getrecast.com/report-template-library/period-comparison/)

## What it does

For your Recast model + chosen KPI:

1. Fires two `compute_insights_overview` reports — current N-day window and the N-day window immediately before it (default N = 30)
2. Extracts per-channel spend and ROI from each
3. Computes spend and ROI deltas per channel
4. Outputs a single self-contained HTML file with summary tiles, a grouped bar chart, and a detail table

## Prerequisites

- Recast API access + token (see [INSTALL.md](INSTALL.md))
- Python 3.10+ (stdlib only)

## Quick start

`.env` holds `API_PAT`; `my-config.json` holds `client_slug` and report settings.

```bash
cp .env.example .env
# Edit .env and paste your token.
cp config.example.json my-config.json
# Edit my-config.json: client_slug, kpi_name, brand colors, window_days (default 30)
python3 build.py my-config.json --check
python3 build.py my-config.json
# → outputs period-comparison.html
```

The `--check` preflight is read-only — it confirms your token works, your KPI name resolves, and the API
returns the shapes this bundle expects, with a plain-language error if anything
is off. It never prints your token. If the build later fails with a 422
mentioning `report_type`, run the report once from the Recast UI first (see
`INSTALL.md`).

## What's in this bundle

| File | Purpose |
|---|---|
| `README.md` | This file. |
| `INSTALL.md` | Setup + API key safety. |
| `build.py` | Hits the API, builds the report. |
| `template.html` | Report HTML with placeholders. |
| `config.example.json` | Generic config. |
| `.env.example` | Generic env. |
| `docs/api-reference.md` | API endpoints used. |
| `docs/customize.md` | Layout + data tweaks. |
| `docs/SKILL.md` | Canonical agent entrypoint for guided builds. |

## Support

Bundle issues: [recast-research-pages issues](https://github.com/getrecast/recast-research-pages/issues).
