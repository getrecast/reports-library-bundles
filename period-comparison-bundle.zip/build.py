#!/usr/bin/env python3
"""
Period-over-Period Comparison — build script.

Fires two compute_insights_overview reports (current 30d window + the
30d window before it) and renders side-by-side comparison.

Stdlib only. Python 3.10+.

Usage:
    python3 build.py my-config.json
    python3 build.py my-config.json --rebuild
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path


def import_shared_runner():
    here = Path(__file__).parent.resolve()
    for candidate in (here / "_shared", here.parent / "_shared"):
        if candidate.exists():
            sys.path.insert(0, str(candidate))
            import recast_runner
            return recast_runner
    print("[BLOCK] Shared runner is missing -> Re-download the bundle or run the package script before distributing", file=sys.stderr)
    sys.exit(1)


rr = import_shared_runner()
rr.require_python_version((3, 10))
REQUIRED_REPORT_TYPES = ["compute_insights_overview"]


def die(msg):
    print(f"ERROR: {msg}", file=sys.stderr)
    sys.exit(1)


def load_dotenv(path):
    if not path.exists():
        return
    for raw in path.read_text().splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, _, v = line.partition("=")
        k, v = k.strip(), v.strip().strip('"').strip("'")
        if k and k not in os.environ:
            os.environ[k] = v


def api(method, path, token, base, body=None):
    url = base.rstrip("/") + path
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Authorization", f"Bearer {token}")
    req.add_header("Accept", "application/json")
    if data is not None:
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            return json.loads(resp.read())
    except urllib.error.HTTPError as e:
        body_text = e.read().decode(errors="replace") if hasattr(e, "read") else str(e)
        die(f"API {method} {path} failed ({e.code}): {body_text}")


def num(v):
    if v is None or v == "":
        return None
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def resolve_kpi(client_slug, kpi_name, token, base):
    print(f"[1/5] Looking up KPI '{kpi_name}'...", flush=True)
    resp = api("GET", f"/clients/{client_slug}/kpis", token, base)
    items = resp if isinstance(resp, list) else resp.get("data") or resp.get("kpis") or []
    for k in items:
        if k.get("name") == kpi_name:
            # Legacy API shape: depvar_configurations[].deployment_id
            deps = k.get("depvar_configurations") or []
            if deps:
                return str(deps[0]["deployment_id"])
            # Current API shape: depvars[].slug — resolve the active deployment by slug
            depvars = k.get("depvars") or []
            if not depvars:
                die(f"KPI '{kpi_name}' has no depvars. Confirm the model is active.")
            depvar_slug = depvars[0]["slug"]
            all_deps = api("GET", f"/clients/{client_slug}/deployments", token, base)
            dep_items = all_deps if isinstance(all_deps, list) else all_deps.get("data") or all_deps.get("deployments") or []
            for d in dep_items:
                full = api("GET", f"/clients/{client_slug}/deployments/{d['id']}", token, base)
                if full.get("dashboard_slug") == depvar_slug and full.get("active"):
                    return str(full["id"])
            die(f"KPI '{kpi_name}': no active deployment found for its depvar slug. Confirm the model is active.")
    available = ", ".join(k.get("name", "?") for k in items)
    die(f"KPI '{kpi_name}' not found. Available: {available}")


def get_deployment(client_slug, deployment_id, token, base):
    print(f"[2/5] Fetching deployment {deployment_id}...", flush=True)
    return api("GET", f"/clients/{client_slug}/deployments/{deployment_id}?extra_fields=spend_channels_labels", token, base)


def fire_overview(client_slug, deployment_id, start, end, token, base):
    resp = api("POST", f"/clients/{client_slug}/reports", token, base, body={
        "form": {"report_type": "compute_insights_overview", "deployment_id": deployment_id, "start_date": start, "end_date": end},
        "show_in_ui": False,
    })
    return str(resp["id"])


def poll(client_slug, report_id, token, base, timeout=600):
    deadline = time.time() + timeout
    while time.time() < deadline:
        r = api("GET", f"/clients/{client_slug}/reports/{report_id}", token, base)
        status = r.get("status")
        if status == "success":
            return r
        if status == "error":
            die(f"Report {report_id} errored: {r.get('error', '(no detail)')}")
        time.sleep(15)
    die(f"Report {report_id} timed out.")


def build_payload(curr_ch, curr_tot, prev_ch, prev_tot):
    rows = []
    all_channels = sorted(set(curr_ch) | set(prev_ch), key=lambda c: -(curr_ch.get(c, {}).get("spend", 0)))
    for ch in all_channels:
        c = curr_ch.get(ch, {})
        p = prev_ch.get(ch, {})
        rows.append({
            "channel": ch,
            "prev_spend": p.get("spend", 0),
            "prev_roi": p.get("roi", 0),
            "curr_spend": c.get("spend", 0),
            "curr_roi": c.get("roi", 0),
        })
    return {
        "rows": rows,
        "totals": {
            "prev_spend": prev_tot["spend"],
            "curr_spend": curr_tot["spend"],
            "prev_incremental": prev_tot["incremental"],
            "curr_incremental": curr_tot["incremental"],
            "prev_baseline": prev_tot["baseline"],
            "curr_baseline": curr_tot["baseline"],
        },
    }


def render(template_path, output_path, payload, config, prev_period, curr_period):
    print(f"[5/5] Rendering → {output_path}", flush=True)
    html = template_path.read_text()
    replacements = {
        "{{BRAND_NAME}}": config["brand"]["name"],
        "{{PAGE_TITLE}}": config.get("page_title", "Period-over-Period Comparison"),
        "{{KPI_NAME}}": config["kpi_name"],
        "{{PRIMARY_COLOR}}": config["brand"].get("primary_color", "#E37C65"),
        "{{ACCENT_COLOR}}": config["brand"].get("accent_color", "#161614"),
        "{{PREV_PERIOD}}": prev_period,
        "{{CURR_PERIOD}}": curr_period,
        "{{REAL_DATA_JSON}}": json.dumps(payload),
    }
    for k, v in replacements.items():
        html = html.replace(k, v)
    output_path.write_text(html)


def channels_and_totals_from_overview_downloads(overview):
    channels = {}
    totals = {"spend": 0, "incremental": 0, "baseline": overview.get("baseline") or 0}
    for name, ch in overview["channels"].items():
        spend = ch.get("spend") or 0
        roi = ch.get("roi") or 0
        impact = ch.get("impact")
        channels[name] = {"spend": spend, "roi": roi}
        totals["spend"] += spend
        totals["incremental"] += impact if impact is not None else spend * roi
    if overview.get("overall", {}).get("spend") is not None:
        totals["spend"] = overview["overall"]["spend"]
    return channels, totals


def _overview_record(client, client_slug, label, form, out_dir):
    report_id = rr.create_report(client, client_slug, form)
    report = rr.poll_report(client, client_slug, report_id)
    csvs = rr.download_report_csvs(client, client_slug, report, out_dir / label)
    return rr.overview_report_record(label, report, form, csvs)


def build_with_client(config, client, bundle_dir=None, rebuild=False):
    rr.validate_config(config, required=("client_slug", "kpi_name", "brand.name"))
    here = Path(bundle_dir).resolve() if bundle_dir else Path(__file__).parent.resolve()
    client_slug = config["client_slug"]
    kpi_name = config["kpi_name"]
    window = int(config.get("window_days", 30))
    data_dir = Path(config.get("data_dir", "./data")).expanduser().resolve()
    output_path = Path(config.get("output_path", "./period-comparison.html")).expanduser().resolve()
    template_path = here / "template.html"
    cache = data_dir / "manifest.json"

    deployment_id = rr.resolve_kpi(client, client_slug, kpi_name)
    deployment = rr.get_deployment(client, client_slug, deployment_id)
    model_date = rr.deployment_model_date(deployment)
    curr_end = dt.date.fromisoformat(model_date)
    curr_start = curr_end - dt.timedelta(days=window)
    prev_end = curr_start
    prev_start = prev_end - dt.timedelta(days=window)
    curr_period = f"{rr.clamp_start_date(curr_start.isoformat(), deployment)} -> {curr_end.isoformat()}"
    prev_period = f"{rr.clamp_start_date(prev_start.isoformat(), deployment)} -> {prev_end.isoformat()}"
    forms = [
        {
            "report_type": "compute_insights_overview",
            "deployment_id": deployment_id,
            "start_date": rr.clamp_start_date(curr_start.isoformat(), deployment),
            "end_date": curr_end.isoformat(),
        },
        {
            "report_type": "compute_insights_overview",
            "deployment_id": deployment_id,
            "start_date": rr.clamp_start_date(prev_start.isoformat(), deployment),
            "end_date": prev_end.isoformat(),
        },
    ]
    cache_key = rr.build_cache_key("period-comparison", config, deployment_id, forms)

    if cache.exists() and not rebuild:
        print("Using cached data (pass --rebuild to refresh).", flush=True)
        data, manifest = rr.load_cached_data(cache, cache_key)
        curr_ch = data["curr_ch"]
        curr_tot = data["curr_tot"]
        prev_ch = data["prev_ch"]
        prev_tot = data["prev_tot"]
        curr_period = data["curr_period"]
        prev_period = data["prev_period"]
    else:
        print(f"[3/5] Firing 2 compute_insights_overview reports...", flush=True)
        labels = ["current", "previous"]
        reports = [_overview_record(client, client_slug, label, form, data_dir / "reports") for label, form in zip(labels, forms)]
        print("[4/5] Downloaded overview CSVs.", flush=True)
        curr_ch, curr_tot = channels_and_totals_from_overview_downloads(reports[0]["overview"])
        prev_ch, prev_tot = channels_and_totals_from_overview_downloads(reports[1]["overview"])
        manifest = rr.make_manifest(
            "period-comparison",
            config,
            deployment_id,
            cache_key,
            reports,
            {
                "curr_ch": curr_ch,
                "curr_tot": curr_tot,
                "prev_ch": prev_ch,
                "prev_tot": prev_tot,
                "curr_period": curr_period,
                "prev_period": prev_period,
            },
        )
        rr.write_manifest(cache, manifest)

    if not curr_ch and not prev_ch:
        rr.block("No channel data returned from overview CSV downloads", "Confirm the model has active channels with spend")
    payload = build_payload(curr_ch, curr_tot, prev_ch, prev_tot)
    render(template_path, output_path, payload, config, prev_period, curr_period)
    rr.reconcile_rendered_payload(
        output_path,
        payload,
        required_paths=("rows", "totals.curr_spend", "totals.prev_spend"),
        disallowed_markers=("Math.random", "mock fallback", "Synthetic"),
    )
    print(f"✓ Done. Open: {output_path}", flush=True)
    return {"output_path": str(output_path), "manifest": manifest, "payload": payload}


def probe_report_types(config, client, bundle_dir=None):
    here = Path(bundle_dir).resolve() if bundle_dir else Path(__file__).parent.resolve()
    return rr.probe_report_types(client, config, REQUIRED_REPORT_TYPES, template_path=here / "template.html")


def run_check(config, token):
    """Preflight (--check): validate token, API access, KPI, and deployment shape.

    Read-only — fires no report, writes nothing, never prints the token.
    """
    base = os.environ.get("RECAST_API_BASE", "https://api.getrecast.com/v1")
    client_slug = config["client_slug"]
    kpi_name = config["kpi_name"]
    print(f"Preflight check — client '{client_slug}', KPI '{kpi_name}'", flush=True)
    resp = api("GET", f"/clients/{client_slug}/kpis", token, base)
    items = resp if isinstance(resp, list) else resp.get("data") or resp.get("kpis") or []
    print(f"  OK   API token accepted; {len(items)} KPI(s) visible on this client")
    deployment_id = resolve_kpi(client_slug, kpi_name, token, base)
    print(f"  OK   KPI resolved to active deployment {deployment_id}")
    deployment = api(
        "GET",
        f"/clients/{client_slug}/deployments/{deployment_id}?extra_fields=spend_channels_labels",
        token, base,
    )
    model_date = deployment.get("model_date") or deployment.get("model_end_date") or deployment.get("end_date") or ""
    if not model_date:
        die("Deployment has no model end date (checked model_date, model_end_date, end_date). "
            "The API shape may have changed — see docs/api-reference.md.")
    print(f"  OK   Model end date: {model_date}")
    channels = deployment.get("spend_channels_labels") or []
    if channels:
        print(f"  OK   {len(channels)} spend channel(s) on the deployment")
    else:
        print("  WARN No spend_channels_labels returned — the build may fail at the report step")
    if not (Path(__file__).parent / "template.html").exists():
        die("template.html missing next to build.py — re-download the bundle.")
    print("  OK   template.html present")
    print()
    print("Note: this check cannot verify report-type activation. If the build later fails")
    print("with 'is not a supported report_type', run this report once from the Recast UI")
    print("first (see INSTALL.md troubleshooting), then re-run build.py.")
    print()
    print("Preflight passed. Next: python3 build.py <your-config.json>")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("config")
    parser.add_argument("--check", action="store_true", help="validate setup and API access without building the report")
    parser.add_argument("--probe-report-types", action="store_true", help="create minimal hidden reports to verify report-type activation")
    parser.add_argument("--rebuild", action="store_true")
    args = parser.parse_args()

    here = Path(__file__).parent.resolve()
    rr.load_dotenv(here / ".env")
    token = rr.validate_token(os.environ.get("API_PAT", ""))
    config = rr.load_config(Path(args.config).resolve(), required=("client_slug", "kpi_name", "brand.name"))
    client = rr.RecastClient(token)

    if args.check and args.probe_report_types:
        rr.block("Choose either --check or --probe-report-types, not both", "--check is read-only; --probe-report-types creates reports")
    if args.check:
        result = rr.preflight_check(client, config, template_path=here / "template.html")
        print(f"Preflight check — client '{result['client_slug']}', KPI '{result['kpi_name']}'")
        print(f"  OK   KPI resolved to active deployment {result['deployment_id']}")
        print(f"  OK   Model end date: {result['model_date']}")
        print(f"  OK   {len(result['channels'])} spend channel(s) on the deployment")
        print("  OK   template.html present")
        print("Preflight passed. Next: python3 build.py <your-config.json>")
        return
    if args.probe_report_types:
        result = probe_report_types(config, client, bundle_dir=here)
        print(f"Probe created {len(result['created'])} hidden report(s).")
        return
    build_with_client(config, client, bundle_dir=here, rebuild=args.rebuild)


if __name__ == "__main__":
    rr.exit_block(main)
