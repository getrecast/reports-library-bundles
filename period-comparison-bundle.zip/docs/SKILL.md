---
name: recast-period-comparison
description: Build a Period-over-Period Comparison report from a Recast model. Wraps the local build.py runner.
---

# Recast Period-over-Period Comparison Skill

Canonical agent entrypoint that runs the local `build.py` against a Recast model and produces the report HTML.

**This is the canonical agent entrypoint for guided builds.** The CLI command `python3 build.py my-config.json` does the same thing. Use the skill if you want a guided, interactive flow.

## Official Recast API docs

If API behavior is unclear, consult the official docs before changing endpoint paths, authentication, polling, or response parsing:

- Recast API authentication and tokens: https://docs.getrecast.com/docs/the-recast-api
- Optimizer API: https://docs.getrecast.com/docs/the-optimizer-api
- Forecaster API: https://docs.getrecast.com/docs/the-forecaster-api
- Spend Forecasting API: https://docs.getrecast.com/docs/spend-forecasting-api
- Helper endpoints: https://docs.getrecast.com/docs/helper-endpoints
- Insights API: https://docs.getrecast.com/docs/the-insights-api
- API FAQ: https://docs.getrecast.com/docs/api-faq
- Client-facing API reference: https://app.getrecast.com/api-docs/index.html

## When to invoke

User says any of:
- "Build the Period-over-Period Comparison for [client]"
- "Run the Period-over-Period Comparison on my Recast model"

## Setup (only required once)

1. Bundle unpacked at a known path
2. `.env` file exists with `API_PAT=gr_...`

If `.env` does not exist or contains the placeholder token, tell the user:

> Before I can run this, you need to put your Recast API token in `.env`. Copy `.env.example` to `.env` and paste your token after `API_PAT=`. Do NOT paste the token in this chat — I never need to see it.

## API token rules — non-negotiable

- **NEVER ask the user to paste the token into chat.**
- **NEVER save the token to memory or any persistent store.**
- **NEVER echo the token back in any message.**
- **NEVER write the token to `config.json` or any tracked file.**
- **NEVER create, edit, or print `.env` contents; the user owns that file.**
- If the user accidentally pastes the token in chat: tell them to regenerate it immediately, put the new one in `.env`, and proceed.

`build.py` reads `.env` directly. You never need to see or handle the token yourself.

## Intake

Use AskUserQuestion. Group when possible.

Do not ask for the API token. Tell the user to keep the token in `.env` and never paste it into chat. Create or edit only the user-owned config JSON, never `.env` contents or tracked files containing the token.

1. **Client slug** — "Which Recast client are we building this for? Use the slug from the Recast URL between `/clients/` and `/dashboards/`."
2. **KPI** — "Which KPI? Exact case-sensitive name as in the Recast app."
3. **Brand name + primary color (hex)** — "Brand name and primary hex color for the report."

## Preflight check (run this first)

Before the full build, validate the setup:

```bash
python3 build.py <their-config.json> --check
```

Read-only: confirms the token, KPI, deployment, and template, and prints a
plain-language error if anything is off. The check never prints the token. If
it passes, proceed to the build.

## Build step

Write the config to a user-owned JSON file (e.g., `their-client.json`), then run:

```bash
python3 build.py <their-client.json>
```

Report progress to the user as each stage completes. When done, tell them where the output is and that it's a single self-contained file.

## Failure modes

| Symptom | Response |
|---|---|
| `API_PAT not set` | User hasn't put the token in `.env`. Tell them to copy `.env.example` and edit. Never ask for the token in chat. |
| `401 Unauthorized` | Token rejected. Ask them to regenerate it in the Recast app and update `.env`. |
| `KPI '...' not found` | Echo the available KPIs from the error message. Ask them to confirm exact, case-sensitive spelling. |
| `KPI '...' has no depvars` | Model inactive or KPI has no deployment. Ask the user to confirm the model is active in the Recast app. |
| 422 `is not a supported report_type` | This report type has never been run for this client. Tell the user to run an Insights Overview report once from the Recast UI, then re-run the build. |
| `Report polling timed out` | Re-run. The Recast backend occasionally drops queued jobs. |

## What this skill does NOT do

- Modify the bundle source files
- Cache anything outside the bundle's local `./data/` directory
- Touch any file outside the bundle directory

Stay scoped to running the build.
