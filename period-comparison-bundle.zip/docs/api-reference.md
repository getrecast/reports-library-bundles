# Recast API endpoints used by this bundle

## Official Recast API docs

This file covers only the endpoints used by this bundle. For current API contracts, auth/token setup, helper endpoints, and broader Recast APIs, consult:

- Recast API authentication and tokens: https://docs.getrecast.com/docs/the-recast-api
- Optimizer API: https://docs.getrecast.com/docs/the-optimizer-api
- Forecaster API: https://docs.getrecast.com/docs/the-forecaster-api
- Spend Forecasting API: https://docs.getrecast.com/docs/spend-forecasting-api
- Helper endpoints: https://docs.getrecast.com/docs/helper-endpoints
- Insights API: https://docs.getrecast.com/docs/the-insights-api
- API FAQ: https://docs.getrecast.com/docs/api-faq
- Client-facing API reference: https://app.getrecast.com/api-docs/index.html

## Base URL

Default: `https://api.getrecast.com/v1`. Override via `RECAST_API_BASE`.

## Endpoints

### 1. `GET /clients/{client_slug}/kpis` — resolve KPI to its active deployment. Handles both the legacy `depvar_configurations[].deployment_id` shape and the current `depvars[].slug` shape (resolved via `GET /clients/{client_slug}/deployments`).

### 2. `GET /clients/{client_slug}/deployments/{deployment_id}?extra_fields=spend_channels_labels` — get the model end date (`end_date` in the current API; older responses use `model_date` or `model_end_date` — `build.py` tries all three) and channels.

### 3. Two `POST /clients/{client_slug}/reports` calls firing `compute_insights_overview`

One for the current window (`[model_date - window_days, model_date]`), one for the prior window (`[model_date - 2×window_days, model_date - window_days]`). Each completed report includes `results.downloads[]`; the bundle downloads the overview CSVs and reads spend, ROI, baseline, and impact from those CSVs.

### 4. `GET /clients/{client_slug}/reports/{report_id}` — poll for completion.

### 5. `GET /clients/{client_slug}/reports/{report_id}/downloads/{download_key}` — download CSVs listed in `results.downloads[]`.

## Errors

Standard HTTP. 401 = bad token, 403 = no access, 404 = bad slug/KPI, 422 = bad params, 5xx = retry.
