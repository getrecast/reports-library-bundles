# Incrementality-Adjusted CPA — Recast Reports Library

Combines your in-platform ROAS with Recast incrementality factors to surface what each channel *actually* costs per incremental customer. The truer cost basis for budget decisions.

**Live preview:** [https://research.getrecast.com/report-template-library/incrementality-cpa/](https://research.getrecast.com/report-template-library/incrementality-cpa/)

## What it does

For your Recast model + chosen KPI:

1. Fires `compute_insights_overview` for the configured window — pulls each channel's Recast (incremental) ROI
2. Reads platform-attributed ROAS from a CSV you provide
3. Computes the incrementality factor per channel (recast ÷ platform)
4. Computes incremental ROI you can multiply against daily platform numbers
5. Outputs a single self-contained HTML file

## Prerequisites

- Recast API access + token (see [INSTALL.md](INSTALL.md))
- Python 3.10+ (stdlib only)
- A CSV of your platform-attributed ROAS per channel — see below

## Platform ROAS CSV

This bundle expects a CSV with at least these columns:

```csv
channel,platform_roas
Meta Prospecting,4.5
Linear TV,7.5
...
```

See `platform-cpa.example.csv` in the bundle for the full format.

Channel name matching is case- and whitespace-insensitive — `Meta Prospecting` matches `meta prospecting` matches `Meta Prospecting `. Channels in either source that don't match the other are flagged in the build log.

## Quick start

`.env` holds `API_PAT`; `my-config.json` holds `client_slug` and report settings.

```bash
cp .env.example .env
cp config.example.json my-config.json
cp platform-cpa.example.csv platform-cpa.csv
# Edit platform-cpa.csv with your actual platform numbers
# Edit my-config.json: client_slug, kpi_name, brand colors
python3 build.py my-config.json --check
python3 build.py my-config.json
# → outputs incrementality-cpa.html
```

The `--check` preflight is read-only — it confirms your token works, your KPI name resolves, and the API
returns the shapes this bundle expects, with a plain-language error if anything
is off. It never prints your token. If the build later fails with a 422
mentioning `report_type`, run the report once from the Recast UI first (see
`INSTALL.md`).

## What's in this bundle

| File | Purpose |
|---|---|
| `README.md`, `INSTALL.md` | Docs. |
| `build.py` | Hits the API, merges with your CSV, fills the template. |
| `template.html` | Report HTML with placeholders. |
| `config.example.json` | Generic config. |
| `platform-cpa.example.csv` | Sample CSV with the expected columns. |
| `.env.example`, `.gitignore` | Setup. |
| `docs/api-reference.md` | API endpoints used. |
| `docs/customize.md` | Layout + data tweaks. |
| `docs/SKILL.md` | Canonical agent entrypoint for guided builds. |

## Support

Bundle issues: [recast-research-pages issues](https://github.com/getrecast/recast-research-pages/issues).
