# Customizing the Incrementality-Adjusted CPA

The bundle is intentionally small. Plain HTML + vanilla JS + stdlib Python. No frameworks, no build step.

## Branding

Edit `config.example.json` (or your copy of it):

```json
{
  "brand": {
    "name": "Your Brand",
    "primary_color": "#E37C65",
    "accent_color": "#161614"
  }
}
```

- `primary_color` — accents, highlight strokes, eyebrow text
- `accent_color` — primary text color, table header background, frame border

Re-run `python3 build.py your-config.json` and the colors update in the output.

For deeper visual changes (typography, layout, spacing), edit the `<style>` block in `template.html` directly.

## Change the data shape

If you want different windows, different metrics, or different channels, edit `build.py`. The functions you'll most likely touch:

- The report-firing block (top of `main()`) — change which API endpoints fire and which params
- `build_payload(...)` — change what gets passed to the template as `window.REAL_DATA`

Then update `template.html` to use the new fields.

## Embed in a dashboard

Output HTML is self-contained. Host it anywhere:
- Drop into your own static site
- Embed in an iframe inside another dashboard
- Host on S3 / Cloudflare Pages with auth (Cloudflare Access works well)

## Schedule refreshes

Add a cron job:

```cron
0 9 * * 1  cd /path/to/bundle && python3 build.py my-config.json --rebuild
```

Every Monday at 9 AM, re-run with a fresh API pull. Output overwrites the previous file.
